# Proidea standalone sector repos

Generated from the latest uploaded Proidea base with 20 standalone sector repos.

## Sector-by-sector mode

This pack is explicitly organized so each sector remains standalone for go-live, tests, maintenance, and feature delivery. Run each lane from the sector repo itself, not from a shared portfolio runtime.
