# proidea-agents.md

This file is the human-readable operating board for Platform Base. Use it together with `AGENTS.md` and `proidea-agent-team.md`.

## Golden rule
No task is complete until shared memory and the task ledger are updated.

## Mandatory task ledger fields
Every completed task must log all of the following:
- date
- sector
- task
- agent
- model
- started_at
- ended_at
- duration_min
- tokens_in
- tokens_out
- tokens_total
- result
- status
- files_changed
- next_owner
- next_step
- notes

## Completion checklist
1. Append a concise fact-only entry to `memory/shared/CHANGELOG.md`.
2. Update `memory/shared/DECISIONS.md` if a real product or architecture decision was made.
3. Update `memory/shared/HANDOFFS.md` if another agent must take over.
4. Update `memory/shared/CURRENT_STATE.md` if project status changed.
5. Append a row to `proidea-agent-team.md`.
6. Append a short entry to the ledger below.

## Active team and role ownership
| Agent | Tool | Main role |
|---|---|---|
| Orchestrator | Claude | reads the repo state, routes work, closes waves |
| Architect | Claude | protects auth, billing, tenant isolation, contracts |
| Product Manager | Claude | writes the business outcome, scope, and acceptance criteria |
| Feature Planner | Claude | breaks work into waves and testable batches |
| Backend Builder | Codex | implements APIs, services, middleware, tests |
| DB Implementer | Codex | owns migrations, indexes, RLS, and data safety changes |
| Automation Builder | Codex | owns n8n, webhook, and channel integration work |
| Mobile Builder | Codex | owns React Native implementation |
| Deploy Builder | Codex | owns deploy scripts, Docker, rollback, publish-online steps |
| Frontend Builder | Codex | owns dashboard and app feature implementation |
| Design Lead | Antigravity | owns visual system, motion, and public-facing polish |
| UI/UX Designer | Antigravity | owns usability, onboarding, friction reduction |
| QA Lead | Claude | verifies coverage and release readiness |
| Security Reviewer | Claude | audits auth, secrets, tenant isolation, uploads, webhooks |
| Performance Reviewer | Claude | reviews bundle size, latency, N+1, caching, rendering |
| Release Manager | Claude | final go/no-go gate |

## Task ledger
| date | sector | task | agent | model | started_at | ended_at | duration_min | tokens_in | tokens_out | tokens_total | result | status | files_changed | next_owner | next_step | notes |
|---|---|---|---|---|---|---|---:|---:|---:|---:|---|---|---|---|---|---|
| 2026-04-08 | Platform Base | operating-system-upgrade | Claude-Orchestrator | claude | 2026-04-08T00:00 | 2026-04-08T00:30 | 30 | 0 | 0 | 0 | upgraded docs, prompts, ledgers, and market scenarios | done | AGENTS.md, proidea-agents.md, proidea-agent-team.md, docs/* | Human | choose Wave 1 slice | Bootstrap row created as the baseline for future handoffs |
