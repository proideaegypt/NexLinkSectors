# Decisions

## ADR-001 — Use Spec Kit + GSD together
Date: 2026-04-08
Status: decided
Context: Large SaaS project with many modules needs both strong specifications and high-throughput execution.
Decision: Use Spec Kit for specs/plans/tasks and GSD-style wave execution for implementation.
Consequences: Every major feature starts with spec first, then execution is delegated to specialized agents.
