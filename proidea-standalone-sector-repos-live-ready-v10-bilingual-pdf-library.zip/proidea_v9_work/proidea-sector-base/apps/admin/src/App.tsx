import React from 'react'
export default function App() { return <div><h1>Proidea Admin</h1></div> }
