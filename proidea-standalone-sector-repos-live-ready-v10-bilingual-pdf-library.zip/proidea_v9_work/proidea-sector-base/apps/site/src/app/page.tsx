export default function Home() { return <main><h1>Proidea</h1></main> }
