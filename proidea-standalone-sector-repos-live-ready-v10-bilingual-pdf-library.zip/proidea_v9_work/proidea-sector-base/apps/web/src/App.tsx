import React from 'react'
export default function App() { return <div><h1>Proidea Web</h1></div> }
