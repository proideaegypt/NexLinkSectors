import Fastify from 'fastify'
import cors from '@fastify/cors'
import { apiConfig } from './config.js'
const app = Fastify({ logger: true })
app.register(cors, { origin: true })
app.get('/health', async () => ({ ok: true, service: 'api', timestamp: new Date().toISOString() }))
app.listen({ port: apiConfig.PORT, host: apiConfig.HOST }, (err) => { if (err) { app.log.error(err); process.exit(1) } })
