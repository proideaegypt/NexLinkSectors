# Sector Separation Operating Mode

Future generated repos should ship with:
- independent go-live runbook
- independent certification scripts
- independent maintenance runbook
- independent feature start command
- independent Playwright harness and smoke fixtures

This keeps generated sectors standalone while still benefiting from a common base template.
