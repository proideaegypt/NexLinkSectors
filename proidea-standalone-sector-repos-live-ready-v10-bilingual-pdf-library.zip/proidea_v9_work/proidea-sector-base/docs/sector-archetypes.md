# Sector archetypes

Reference generated from `sectors/sector-definitions.json`.

## appointment-service

- Sectors: Salons, Wellness
- Typical capabilities: dashboard.read, records.read, records.write, automation.manage
- Typical entity shape: Client (`clients`), Stylist (`stylists`), Service (`services`), Appointment (`appointments`)

## care-appointment

- Sectors: Aesthetics, Home Care, Medical, Veterinary
- Typical capabilities: dashboard.read, records.read, records.write, automation.manage
- Typical entity shape: Client (`clients`), Consultation (`consultations`), Session (`sessions`), Treatment Plan (`treatment_plans`)

## job-workorder

- Sectors: Auto Repair, Contractors
- Typical capabilities: dashboard.read, records.read, records.write, automation.manage
- Typical entity shape: Customer (`customers`), Vehicle (`vehicles`), Work Order (`work_orders`), Technician (`technicians`)

## membership-schedule

- Sectors: Coaching, Education, Gym Fitness, Nurseries
- Typical capabilities: dashboard.read, records.read, records.write, automation.manage
- Typical entity shape: Client (`clients`), Program (`programs`), Session (`sessions`), Goal (`goals`)

## order-fulfillment

- Sectors: Pharmacy
- Typical capabilities: dashboard.read, records.read, records.write, automation.manage
- Typical entity shape: Customer (`customers`), Product (`products`), Prescription (`prescriptions`), Order (`orders`)

## pipeline-delivery

- Sectors: Consulting, Photography, Real Estate, Travel
- Typical capabilities: dashboard.read, records.read, records.write, automation.manage
- Typical entity shape: Client (`clients`), Opportunity (`opportunities`), Engagement (`engagements`), Milestone (`milestones`)

## reservation-inventory

- Sectors: Car Rental, Hotels
- Typical capabilities: dashboard.read, records.read, records.write, automation.manage
- Typical entity shape: Customer (`customers`), Fleet Vehicle (`fleet_vehicles`), Rental (`rentals`), Return Check (`return_checks`)

## reservation-ordering

- Sectors: Restaurants
- Typical capabilities: dashboard.read, records.read, records.write, ordering.manage, delivery.manage, automation.manage
- Typical entity shape: Guest (`guests`), Reservation (`reservations`), Menu Item (`menu_items`), Order (`orders`)

