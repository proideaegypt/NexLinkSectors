# Certification Status

This repo was upgraded with a repeatable certification harness for API, web, admin, and site typecheck. Mobile remains sandbox-blocked when React Native tarballs require registry auth in this environment.

## Commands

```bash
bash scripts/certify-sector.sh
```

## Common fixes applied

- API test now closes Fastify cleanly after injection.
- Web and admin Vitest configs now use jsdom.
- Docker compose now points to `apps/api`.
- API Dockerfile added.
- Migration script now reads `database/migrations`.
- Deployment script no longer hardcodes `~/Proidea-Kick-Start`.
