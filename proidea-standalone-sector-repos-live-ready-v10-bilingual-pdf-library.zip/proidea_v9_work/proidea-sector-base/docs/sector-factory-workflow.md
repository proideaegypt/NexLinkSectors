# Sector factory workflow

1. Update `sectors/sector-catalog.json` for lightweight catalog metadata.
2. Update `sectors/sector-definitions.json` when a sector needs entity, capability, or runtime changes.
3. Generate one repo with:
   ```bash
   node scripts/generate-sector-repo.mjs medical
   ```
4. Generate every standalone sector repo with:
   ```bash
   node scripts/generate-all-sectors.mjs
   ```
5. Review the generated `sector.config.json`, database migrations, RBAC matrix, dashboard shell, mobile shell, and site messaging.
6. Run repo-level validation and smoke checks before shipping the pack.

The generator creates standalone sibling repos next to `proidea-sector-base`.
