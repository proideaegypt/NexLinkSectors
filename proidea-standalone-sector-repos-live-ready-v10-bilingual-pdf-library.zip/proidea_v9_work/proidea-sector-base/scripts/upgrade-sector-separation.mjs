#!/usr/bin/env node
console.log('Apply sector separation templates from the base repo before generating or refreshing standalone sector repos.')
