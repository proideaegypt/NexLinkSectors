import path from 'node:path'
import { generateSectorRepo } from './sector-factory-lib.mjs'

const sectorArg = process.argv[2]
if (!sectorArg) {
  console.error('Usage: node scripts/generate-sector-repo.mjs <sector-slug> [target-dir]')
  process.exit(1)
}

const targetArg = process.argv[3]
const result = await generateSectorRepo(sectorArg, targetArg ? { targetDir: path.resolve(process.cwd(), targetArg) } : {})
console.log(`Generated ${result.sector.displayName} -> ${result.targetDir}`)
