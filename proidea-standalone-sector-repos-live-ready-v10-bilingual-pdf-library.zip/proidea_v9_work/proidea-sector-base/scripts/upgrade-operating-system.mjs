import fs from 'node:fs/promises'
import path from 'node:path'

const packRoot = process.argv[2] ? path.resolve(process.argv[2]) : path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', '..')

const genericAgentsMd = `# AGENTS.md - Proidea SaaS Agent Team Contract

## Prime rules
1. Read \`AGENTS.md\`, \`proidea-agents.md\`, \`memory/shared/CURRENT_STATE.md\`, and \`sector.config.json\` before starting any task.
2. Read the role file that matches your task in \`.agents/\` or \`.claude/agents/\` before doing work.
3. No implementation starts before scope, acceptance criteria, tests, and rollback path are clear.
4. Spec Kit is the source of truth. GSD is the execution layer.
5. Claude owns planning, architecture, review, QA, security review, release gates, and decisions.
6. Codex owns backend, database, mobile, n8n, automation code, deployment, and focused implementation.
7. Antigravity owns public site, app shell UI, motion, onboarding, design system, and visual polish.
8. After every meaningful task, update shared memory and the agent ledgers before declaring completion.
9. Stop immediately on tenant-isolation, billing, security, data-loss, or compliance risk.
10. Never hardcode secrets or bypass env contracts.

## Mandatory read order
1. \`AGENTS.md\`
2. \`proidea-agents.md\`
3. \`memory/shared/CURRENT_STATE.md\`
4. \`memory/shared/OPEN_QUESTIONS.md\`
5. \`sector.config.json\`
6. \`docs/sector/BUSINESS-MODEL.md\`
7. \`docs/sector/REAL-MARKET-SCENARIOS.md\`
8. \`docs/sector/SECTOR-FIRST-PROMPTS.md\`

## Tool ownership

| Situation | Owner |
|---|---|
| PRD, scope, architecture, sequencing, code review, QA strategy, security review, release decision | Claude |
| Routes, services, migrations, tests, mobile, n8n, deploy scripts, focused fixes | Codex |
| Site, UI system, motion, onboarding, app shell visuals, sales pages | Antigravity |

## Agent roster

| Agent | Primary owner | Scope |
|---|---|---|
| orchestrator | Claude | phase control, handoffs, final decision |
| architect | Claude | auth, tenancy, billing, system boundaries |
| product-manager | Claude | PRD, stories, acceptance criteria |
| feature-planner | Claude | wave design, dependencies, task slicing |
| backend-builder | Codex | API, middleware, services, workers |
| db-implementer | Codex | migrations, indexes, data repair |
| automation-builder | Codex | n8n, webhooks, integrations |
| mobile-builder | Codex | Expo/React Native implementation |
| deploy-builder | Codex | Docker, CI/CD, VPS, rollback |
| frontend-builder | Codex | dashboard/app feature implementation |
| design-lead | Antigravity | design system, visual language |
| ui-ux-designer | Antigravity | journeys, flows, empty states |
| marketing-site-designer | Antigravity | landing pages, conversion sections |
| qa-lead | Claude | test strategy, release verification |
| unit-tester | Codex | unit and integration tests |
| e2e-tester | Antigravity | visual flows, screenshots, Playwright |
| security-reviewer | Claude | auth, tenant isolation, secrets, uploads, webhooks |
| security-fixer | Codex | patch findings and add regression tests |
| code-reviewer | Claude | diff review, maintainability, consistency |
| performance-reviewer | Claude | Lighthouse, bundle, query, latency review |
| performance-fixer | Codex | optimization and retesting |
| release-manager | Claude | go/no-go, rollback path |
| growth-strategist | Claude | activation, conversion, retention |
| billing-strategist | Claude | pricing, usage, entitlements |
| analytics-planner | Claude | events, dashboards, KPIs |
| docs-writer | Claude | README, runbooks, manuals |
| compliance-planner | Claude | audit trail, privacy, retention |

## Memory contract
Shared memory files:
- \`memory/shared/CURRENT_STATE.md\`
- \`memory/shared/CHANGELOG.md\`
- \`memory/shared/DECISIONS.md\`
- \`memory/shared/HANDOFFS.md\`
- \`memory/shared/OPEN_QUESTIONS.md\`
- \`memory/shared/RELEASE_STATUS.md\`

Every meaningful task must append to:
- \`memory/shared/CHANGELOG.md\`
- \`proidea-agent-team.md\`
- \`proidea-agents.md\` task ledger

Update \`DECISIONS.md\` for non-obvious decisions and \`HANDOFFS.md\` when ownership changes.
`

const genericProideaAgents = (sectorName = 'this sector') => `# proidea-agents.md

This file is the human-readable operating board for ${sectorName}. Use it together with \`AGENTS.md\` and \`proidea-agent-team.md\`.

## Golden rule
No task is complete until shared memory and the task ledger are updated.

## Mandatory task ledger fields
Every completed task must log all of the following:
- date
- sector
- task
- agent
- model
- started_at
- ended_at
- duration_min
- tokens_in
- tokens_out
- tokens_total
- result
- status
- files_changed
- next_owner
- next_step
- notes

## Completion checklist
1. Append a concise fact-only entry to \`memory/shared/CHANGELOG.md\`.
2. Update \`memory/shared/DECISIONS.md\` if a real product or architecture decision was made.
3. Update \`memory/shared/HANDOFFS.md\` if another agent must take over.
4. Update \`memory/shared/CURRENT_STATE.md\` if project status changed.
5. Append a row to \`proidea-agent-team.md\`.
6. Append a short entry to the ledger below.

## Active team and role ownership
| Agent | Tool | Main role |
|---|---|---|
| Orchestrator | Claude | reads the repo state, routes work, closes waves |
| Architect | Claude | protects auth, billing, tenant isolation, contracts |
| Product Manager | Claude | writes the business outcome, scope, and acceptance criteria |
| Feature Planner | Claude | breaks work into waves and testable batches |
| Backend Builder | Codex | implements APIs, services, middleware, tests |
| DB Implementer | Codex | owns migrations, indexes, RLS, and data safety changes |
| Automation Builder | Codex | owns n8n, webhook, and channel integration work |
| Mobile Builder | Codex | owns React Native implementation |
| Deploy Builder | Codex | owns deploy scripts, Docker, rollback, publish-online steps |
| Frontend Builder | Codex | owns dashboard and app feature implementation |
| Design Lead | Antigravity | owns visual system, motion, and public-facing polish |
| UI/UX Designer | Antigravity | owns usability, onboarding, friction reduction |
| QA Lead | Claude | verifies coverage and release readiness |
| Security Reviewer | Claude | audits auth, secrets, tenant isolation, uploads, webhooks |
| Performance Reviewer | Claude | reviews bundle size, latency, N+1, caching, rendering |
| Release Manager | Claude | final go/no-go gate |

## Task ledger
| date | sector | task | agent | model | started_at | ended_at | duration_min | tokens_in | tokens_out | tokens_total | result | status | files_changed | next_owner | next_step | notes |
|---|---|---|---|---|---|---|---:|---:|---:|---:|---|---|---|---|---|---|
| 2026-04-08 | ${sectorName} | operating-system-upgrade | Claude-Orchestrator | claude | 2026-04-08T00:00 | 2026-04-08T00:30 | 30 | 0 | 0 | 0 | upgraded docs, prompts, ledgers, and market scenarios | done | AGENTS.md, proidea-agents.md, proidea-agent-team.md, docs/* | Human | choose Wave 1 slice | Bootstrap row created as the baseline for future handoffs |
`

const genericAgentTeam = (sectorSlug = 'sector') => `| date | sector | task | agent | model | started_at | ended_at | duration_min | tokens_in | tokens_out | tokens_total | result | status | files_changed | next_owner | next_step | notes |
|---|---|---|---|---|---|---|---:|---:|---:|---:|---|---|---|---|---|---|
| 2026-04-08 | ${sectorSlug} | repo-init | Claude-Orchestrator | claude | 2026-04-08T00:00 | 2026-04-08T00:15 | 15 | 0 | 0 | 0 | initial repo baseline verified | done | bootstrap, env, memory | Human | run bootstrap | Carry-forward baseline from generated starter |
| 2026-04-08 | ${sectorSlug} | operating-system-upgrade | Claude-Orchestrator | claude | 2026-04-08T00:15 | 2026-04-08T00:45 | 30 | 0 | 0 | 0 | prompts, ledgers, memory rules, market scenarios added | done | AGENTS.md, proidea-agents.md, docs/* | Human | choose Wave 1 slice | Start logging real tokens from the next task onward |
`

const genericClaudeMd = `# CLAUDE.md

Before any action:
1. Read \`AGENTS.md\`.
2. Read \`proidea-agents.md\`.
3. Read \`memory/shared/CURRENT_STATE.md\` and \`memory/shared/OPEN_QUESTIONS.md\`.
4. Read \`sector.config.json\` and the two files under \`docs/sector/\` that define the business model and real market scenarios.

## Working style
- Think like the planning, review, and release brain of the project.
- Do not implement large changes until the wave, acceptance criteria, and rollback note are explicit.
- Route implementation to Codex and visual work to Antigravity.
- Keep outputs compact, concrete, and testable.

## Mandatory write-back
Before you say a task is complete, update:
- \`memory/shared/CHANGELOG.md\`
- \`memory/shared/DECISIONS.md\` if needed
- \`memory/shared/HANDOFFS.md\` if needed
- \`memory/shared/CURRENT_STATE.md\` if status changed
- \`proidea-agent-team.md\`
- \`proidea-agents.md\`
`

const genericVibeManual = `# VIBE-CODE-MANUAL

This repo is designed for a three-tool operating model:
- Claude = planning, architecture, security review, QA review, release gates
- Codex = backend, DB, mobile, n8n, deploy, focused implementation
- Antigravity = marketing site, app shell UI, motion, design polish

## Step-by-step way to use the repo
### 1. Prepare the repo
\`\`\`bash
corepack enable
corepack prepare pnpm@10.33.0 --activate
pnpm install
bash bootstrap.sh
bash scripts/check-env-sync.sh
\`\`\`

### 2. Read the operating files in this order
1. \`AGENTS.md\`
2. \`proidea-agents.md\`
3. \`memory/shared/CURRENT_STATE.md\`
4. \`sector.config.json\`
5. \`docs/sector/BUSINESS-MODEL.md\`
6. \`docs/sector/REAL-MARKET-SCENARIOS.md\`
7. \`docs/sector/SECTOR-FIRST-PROMPTS.md\`

### 3. Start the wave in Claude
Paste the Sector Kickoff prompt from \`docs/sector/SECTOR-FIRST-PROMPTS.md\` into Claude Code.
Expected result:
- clear business outcome
- wave scope
- acceptance criteria
- tests
- rollback note
- next owner

### 4. Execute the approved slice in Codex
Use the Codex execution prompt from \`docs/sector/SECTOR-FIRST-PROMPTS.md\`.
Keep the task narrow. One wave. One outcome. No side quests.

### 5. Build or polish UI in Antigravity
Use the Antigravity prompt from \`docs/sector/SECTOR-FIRST-PROMPTS.md\` when the backend contract is clear.
Ask for real states: loading, empty, success, failure, permission denied, stale data.

### 6. Run verification locally
\`\`\`bash
pnpm test
pnpm typecheck
bash scripts/qa-smoke.sh
bash scripts/test-security.sh
bash scripts/test-performance.sh
\`\`\`

### 7. Ask Claude for the release gate
Run the release prompt after implementation and tests.
Claude should decide: go / no-go.

### 8. Update memory and ledgers after every meaningful task
Required updates:
- \`memory/shared/CHANGELOG.md\`
- \`memory/shared/DECISIONS.md\` when needed
- \`memory/shared/HANDOFFS.md\` when owner changes
- \`memory/shared/CURRENT_STATE.md\` when status changes
- \`proidea-agent-team.md\`
- \`proidea-agents.md\`

## Command cheatsheet
\`\`\`bash
pnpm dev:api
pnpm dev:web
pnpm dev:admin
pnpm dev:site
pnpm test
pnpm typecheck
bash scripts/review-local.sh
bash scripts/test-security.sh
bash scripts/test-performance.sh
bash scripts/deploy-staging.sh
bash scripts/deploy-prod.sh
bash scripts/rollback.sh
node scripts/update-agent-ledger.mjs --task "wave-name" --agent "Codex-Backend" --model "codex" --result "implemented and tested" --status done --duration 28 --tokens-in 12000 --tokens-out 3800 --files "apps/api/src/*"
\`\`\`

## Non-negotiables
- Arabic-first and multi-tenant safe.
- No public medical or sensitive artifacts.
- No direct production deploy without a rollback path.
- No feature is considered sellable until onboarding, support, security, QA, and pricing impact are clear.
`

const genericReadyToSell = `# READY-TO-SELL-ACTION-PLAN

## What makes a sector repo sellable
1. It solves one painful workflow end-to-end.
2. It has a clear buyer, operator, and daily user.
3. It has a measurable KPI improvement.
4. It has pricing, onboarding, and proof points.
5. It passes security, QA, and performance gates.

## Required go-to-market layers
- Core workflow: one daily operational loop that the buyer immediately feels.
- Control plane: tenant auth, roles, billing, dashboard.
- Channel layer: WhatsApp / voice / forms / web leads where relevant.
- Review mesh: QA, security, performance, release gate.
- Sales story: buyer pain, ROI, fast implementation, low-risk rollout.

## Wave order
### Now
- Freeze the first live buyer workflow.
- Ship the first vertical slice end-to-end.
- Add onboarding, dashboard proof, and task logging.

### Next
- Add the add-on that directly improves retention or ARPU.
- Add automation and reporting.
- Add better analytics and operator alerts.

### Later
- Expand to deeper intelligence, AI copilots, and advanced role packs.
- Add partner channels, integrations, and package upgrades.

## Quality gates
- Security: auth, RBAC, secrets, uploads, webhooks, tenant isolation.
- Performance: bundle size, route latency, N+1 prevention, index review.
- QA: happy path, validation, permissions, cross-tenant leakage, rollback.
- Product: PRD alignment, ICP fit, pricing fit, onboarding clarity.
`

const genericQualityGates = `# QUALITY-GATES

## Release gate checklist
- [ ] Scope matches PRD and current wave.
- [ ] Happy path tested.
- [ ] Failure path tested.
- [ ] Permission checks tested.
- [ ] Tenant isolation tested.
- [ ] Security reviewer signed off.
- [ ] Performance reviewer signed off.
- [ ] Rollback path written.
- [ ] Shared memory updated.
- [ ] proidea-agent-team.md updated.
- [ ] proidea-agents.md updated.
`

const genericPromptsGuide = `# PROMPTS-GUIDE

## Read-first rule
Every prompt starts by reading:
- \`AGENTS.md\`
- \`proidea-agents.md\`
- \`memory/shared/CURRENT_STATE.md\`
- \`sector.config.json\`
- \`docs/sector/BUSINESS-MODEL.md\`
- \`docs/sector/REAL-MARKET-SCENARIOS.md\`

## Tool labels
- Claude = planning, architecture, product, QA, security, review, release
- Codex = backend, DB, mobile, n8n, deploy, focused implementation
- Antigravity = site, UI/UX, motion, design polish

## Phase prompts
### P0 - baseline verification (Claude)
Review current repo state, blockers, env gaps, and first production-risk areas. Do not code.

### P1 - first live workflow plan (Claude)
Plan the smallest sellable workflow for this sector. Output buyer, user, scope, KPI, acceptance criteria, tests, rollback, next owner.

### P2 - implementation wave (Codex)
Implement only the approved wave. Return changed files, tests, open risks, rollback note.

### P3 - UI and onboarding polish (Antigravity)
Build or refine the public-facing page and operator UI states using the approved contracts only.

### P4 - review mesh (Claude)
Run QA, security, performance, and release review on the diff and test outputs.

## Role prompts
### PM-01
Act as Product Manager. Write the feature brief for <feature-name> with: problem, persona, scope, KPI, risks, dependencies, next owner.

### PLAN-01
Act as Feature Planner. Break <feature-name> into waves with owners, changed areas, required tests, security checks, rollback.

### ARCH-01
Act as Architect. Review data model, contracts, auth boundaries, infra impact, and rollout risk.

### BE-01
Act as Backend Builder. Implement the approved slice only. Include tests and rollback note.

### AUTO-01
Act as Automation Builder. Implement n8n/webhook work with retries, failure handling, and tenant mapping.

### FE-01
Act as Frontend Builder. Implement the approved dashboard or app slice with loading, empty, success, and error states.

### DESIGN-01
Act as Design Lead. Improve the design system, visual hierarchy, and conversion path without changing backend contracts.

### QA-01
Act as QA Lead. Build a release-grade test matrix for the selected slice.

### SEC-01
Act as Security Reviewer. Audit auth, tenant isolation, secrets, uploads, webhooks, and rate limits.

### PERF-01
Act as Performance Reviewer. Review route latency, bundle size, query plans, and rendering bottlenecks.

### RELEASE-01
Act as Release Manager. Decide go / no-go using current state, changelog, QA, security, and performance outputs.
`

const claudeCommands = {
  'start-sector.md': `Read AGENTS.md, proidea-agents.md, memory/shared/CURRENT_STATE.md, sector.config.json, docs/sector/BUSINESS-MODEL.md, and docs/sector/REAL-MARKET-SCENARIOS.md. Then produce the smallest sellable Wave 1 for this sector with buyer, workflow, acceptance criteria, test plan, rollback note, and next owner. Update memory files and the ledgers before finishing.`,
  'plan-wave.md': `Read the current state and latest handoffs. Break the selected sector feature into execution waves. For each wave output goal, owner, touched areas, required tests, security checks, performance checks, and rollback note. Do not code. Update CHANGELOG.md and HANDOFFS.md.`,
  'review-wave.md': `Review the diff and test outputs for the last wave. Return approve or reject, must-fix items, security issues, performance issues, and exact next owner. Update CHANGELOG.md, HANDOFFS.md, and RELEASE_STATUS.md if this was a gate review.`
}

const codexPrompts = {
  'execute-wave.md': `Read AGENTS.md, proidea-agents.md, memory/shared/CURRENT_STATE.md, sector.config.json, and the approved Claude wave output. Implement one wave only. Run relevant tests. Return changed files, commands run, rollback note, open risks, and exact ledger values for duration and tokens. Update memory/shared/CHANGELOG.md, proidea-agent-team.md, and proidea-agents.md before stopping.`,
  'build-n8n.md': `Read AGENTS.md, CURRENT_STATE.md, and the approved automation contract. Build or update one workflow only. Prefer stable normalization, retries, idempotency, tenant mapping, and failure visibility. Do not change business scope. Update the memory files and ledgers at the end.`,
  'deploy.md': `Read AGENTS.md, RELEASE_STATUS.md, CURRENT_STATE.md, and the rollback scripts before any deploy. Verify tests, env completeness, smoke readiness, migration order, and rollback path. Only then execute the smallest safe deploy step. Write back exact results and timestamps to memory and ledgers.`
}

const antigravityPrompts = {
  'site-and-ui.md': `Read AGENTS.md, proidea-agents.md, CURRENT_STATE.md, sector.config.json, docs/sector/BUSINESS-MODEL.md, and docs/sector/REAL-MARKET-SCENARIOS.md. Create or refine the site/app-shell UI for this sector. Focus on professional hierarchy, Arabic-first layouts where needed, loading/empty/error states, conversion clarity, and motion that supports comprehension. Do not change backend contracts. Update shared memory and ledgers when done.`
}

const agentRoleTemplate = (name, summary) => `# ${name}\n\nRole: ${summary}\n\nAlways read AGENTS.md, proidea-agents.md, CURRENT_STATE.md, and sector.config.json first.\nAlways append outcomes to shared memory and both task ledgers before completion.\n`

const agents = {
  'orchestrator.md': agentRoleTemplate('Orchestrator', 'routes work, closes waves, owns final handoff quality'),
  'architect.md': agentRoleTemplate('Architect', 'protects auth, billing, tenancy, and system boundaries'),
  'product-manager.md': agentRoleTemplate('Product Manager', 'writes the business problem, scope, and acceptance criteria'),
  'feature-planner.md': agentRoleTemplate('Feature Planner', 'breaks work into waves and dependencies'),
  'backend-builder.md': agentRoleTemplate('Backend Builder', 'implements APIs, services, middleware, and tests'),
  'db-implementer.md': agentRoleTemplate('DB Implementer', 'owns migrations, RLS, indexes, and data safety'),
  'automation-builder.md': agentRoleTemplate('Automation Builder', 'owns n8n, webhooks, and automation contracts'),
  'mobile-builder.md': agentRoleTemplate('Mobile Builder', 'implements React Native / Expo work'),
  'deploy-builder.md': agentRoleTemplate('Deploy Builder', 'owns Docker, deploy scripts, smoke, and rollback'),
  'frontend-builder.md': agentRoleTemplate('Frontend Builder', 'implements dashboard and app features'),
  'design-lead.md': agentRoleTemplate('Design Lead', 'owns design system, visual language, and site polish'),
  'ui-ux-designer.md': agentRoleTemplate('UI UX Designer', 'owns user journeys, onboarding, and operator flow polish'),
  'qa-lead.md': agentRoleTemplate('QA Lead', 'owns release-grade verification strategy'),
  'security-reviewer.md': agentRoleTemplate('Security Reviewer', 'audits auth, tenant isolation, secrets, uploads, and webhooks'),
  'code-reviewer.md': agentRoleTemplate('Code Reviewer', 'reviews diff quality, maintainability, and rollout risk'),
  'performance-reviewer.md': agentRoleTemplate('Performance Reviewer', 'reviews latency, bundle size, caching, and bottlenecks'),
  'release-manager.md': agentRoleTemplate('Release Manager', 'owns go / no-go and rollback clarity')
}

function slugToTitle(slug) {
  return String(slug).split('-').map((x) => x.charAt(0).toUpperCase() + x.slice(1)).join(' ')
}

const sectorPlaybooks = {
  aesthetics: {
    buyer: 'multi-practitioner aesthetics clinic',
    offer: 'consultation-to-session operations with treatment plans, before/after workflow, deposits, and aftercare reminders',
    kpis: ['consultation-to-treatment conversion', 'session utilization', 'repeat package revenue'],
    scenarios: ['A Cairo aesthetics center wants WhatsApp booking, consultation follow-up, and treatment package tracking.', 'A Dubai injectables clinic needs front-desk to coordinate consultations, deposits, and aftercare tasks without spreadsheet chaos.', 'A med-spa group wants management visibility over practitioner utilization, no-shows, and repeat package sales.'],
    addOns: ['AI receptionist for consult qualification', 'VIP package upsell engine', 'aftercare automation']
  },
  'auto-repair': {
    buyer: 'garage or service center with multiple technicians',
    offer: 'vehicle intake, work orders, approvals, parts status, and WhatsApp updates in one control plane',
    kpis: ['work order turnaround time', 'average ticket value', 'approval response time'],
    scenarios: ['A busy workshop wants digital intake, technician assignment, and customer approval for extra repair items.', 'A chain garage wants branch-level dashboards for jobs, delays, and outstanding approvals.', 'A premium service center wants automated status updates so advisors stop manually calling every customer.'],
    addOns: ['inspection photo workflow', 'parts ETA tracking', 'fleet service contracts']
  },
  'car-rental': {
    buyer: 'car rental operator with a small or medium fleet',
    offer: 'fleet availability, reservation intake, delivery handoff, deposits, and return status tracking',
    kpis: ['fleet utilization', 'booking conversion', 'late return rate'],
    scenarios: ['A local rental company wants WhatsApp-first reservation intake and availability confirmation.', 'An airport rental operator needs real-time vehicle status, pickup notes, and return inspection tracking.', 'A premium chauffeur-lite fleet wants branch dashboards for utilization, disputes, and high-value customers.'],
    addOns: ['damage photo evidence', 'dynamic pricing rules', 'long-term corporate rental pack']
  },
  coaching: {
    buyer: 'coaching business selling sessions or programs',
    offer: 'lead capture, program enrollment, session scheduling, reminders, and renewal visibility',
    kpis: ['lead-to-enrollment conversion', 'session attendance', 'renewal rate'],
    scenarios: ['An executive coach wants discovery-call booking and paid program onboarding without manual follow-up.', 'A coaching academy wants cohorts, mentors, and client progress checkpoints managed from one workspace.', 'A wellness coach wants reminders, rescheduling, and package renewal nudges over WhatsApp.'],
    addOns: ['progress journaling', 'AI recap and action plans', 'community membership tier']
  },
  consulting: {
    buyer: 'consulting firm or solo consultant managing pipeline and delivery',
    offer: 'lead qualification, proposal follow-up, project delivery checkpoints, and account health visibility',
    kpis: ['qualified pipeline value', 'proposal win rate', 'delivery margin'],
    scenarios: ['A strategy boutique wants lead, proposal, and project handoff visibility in one system.', 'A solo consultant wants to stop losing follow-ups between calls, proposals, and kickoff tasks.', 'A retained advisory team needs dashboard visibility over accounts at risk, renewals, and pending decisions.'],
    addOns: ['proposal automation', 'account health scoring', 'renewal reminder engine']
  },
  contractors: {
    buyer: 'field-service contractor or home-project operator',
    offer: 'lead intake, site visits, job stages, crew dispatch, and payment collection visibility',
    kpis: ['quote-to-job conversion', 'job completion time', 'cash collection speed'],
    scenarios: ['A contractor wants web and WhatsApp leads turned into site visits and job cards.', 'A finishing company needs crew scheduling and payment milestone tracking.', 'A home-maintenance operator wants technician dispatch, job photos, and customer follow-up in one place.'],
    addOns: ['crew mobile app', 'before/after proof workflow', 'recurring maintenance contracts']
  },
  education: {
    buyer: 'training center or academy selling classes',
    offer: 'student leads, enrollment, schedule, attendance, and parent/student reminders',
    kpis: ['enrollment conversion', 'attendance rate', 'renewal rate'],
    scenarios: ['A language center wants inquiry-to-enrollment workflow and class seat tracking.', 'A coding academy needs timetable, attendance, and payment reminder automation.', 'A tutoring center wants branch dashboards for lead conversion, teacher load, and renewal risk.'],
    addOns: ['parent portal', 'AI attendance alerts', 'certificate generation']
  },
  'gym-fitness': {
    buyer: 'gym, boutique studio, or fitness operator',
    offer: 'membership sales, attendance, trainer schedule, renewals, and churn rescue automation',
    kpis: ['trial-to-member conversion', 'renewal rate', 'class occupancy'],
    scenarios: ['A boutique studio wants class booking, waitlist, and renewal nudges.', 'A multi-trainer gym wants lead funnel, membership packs, and attendance dashboards.', 'A fitness chain wants branch-level retention and trainer utilization visibility.'],
    addOns: ['trainer app', 'body measurement tracking', 'membership freeze workflow']
  },
  'home-care': {
    buyer: 'home-care provider coordinating visits and caregivers',
    offer: 'patient intake, visit scheduling, caregiver assignment, follow-up, and family communication',
    kpis: ['scheduled visit completion', 'caregiver utilization', 'family response time'],
    scenarios: ['A home-care operator wants intake, visit planning, and family updates via WhatsApp.', 'A nursing-at-home team needs caregiver assignment and shift change visibility.', 'A premium elder-care provider wants service quality follow-up and recurring care plan management.'],
    addOns: ['visit notes mobile workflow', 'incident escalation pack', 'family portal']
  },
  hotels: {
    buyer: 'small hotel, serviced apartments, or boutique operator',
    offer: 'reservation pipeline, room status, guest communication, and upsell visibility',
    kpis: ['occupancy rate', 'direct booking share', 'guest response speed'],
    scenarios: ['A boutique hotel wants direct-booking lead capture and reservation follow-up.', 'A serviced apartment operator needs room availability, check-in coordination, and guest support tickets.', 'A hospitality group wants repeat-guest visibility and add-on upsell flow.'],
    addOns: ['guest self-check-in', 'housekeeping dispatch', 'upsell automation']
  },
  medical: {
    buyer: 'clinic, specialty center, or multi-doctor practice',
    offer: 'patient intake, appointment operations, reminders, payment links, and secure follow-up workflow',
    kpis: ['no-show rate', 'booked capacity', 'collection rate'],
    scenarios: ['A specialty clinic wants WhatsApp booking, reminder automation, and front-desk dashboard control.', 'A multi-doctor center needs role-safe patient flow, clinician schedules, and payment tracking.', 'A diagnostic or outpatient practice wants Arabic-first intake and AI-assisted operator workflows without losing tenant isolation.'],
    addOns: ['AI receptionist', 'tenant-safe RAG knowledge base', 'clinical intelligence add-on']
  },
  nurseries: {
    buyer: 'nursery or daycare operator',
    offer: 'parent inquiries, enrollment, attendance, pickup notes, and recurring payment follow-up',
    kpis: ['enrollment conversion', 'attendance consistency', 'payment collection rate'],
    scenarios: ['A nursery wants parent inquiry handling and enrollment follow-up from one dashboard.', 'A daycare operator needs attendance, pickup notes, and parent communications in Arabic.', 'A growing childcare brand wants branch visibility over capacity, renewals, and delayed payments.'],
    addOns: ['parent daily report', 'pickup authorization workflow', 'staff ratio alerts']
  },
  pharmacy: {
    buyer: 'pharmacy or health retail operator',
    offer: 'order intake, fulfillment, refill reminders, and customer support visibility',
    kpis: ['order fulfillment time', 'repeat order rate', 'stockout-related lost orders'],
    scenarios: ['A delivery-first pharmacy wants online and WhatsApp orders normalized into one fulfillment queue.', 'A neighborhood pharmacy needs refill reminders and staff dashboards for pending orders.', 'A pharmacy chain wants branch dashboards for fulfillment speed, repeat buyers, and escalation handling.'],
    addOns: ['refill engine', 'stock alert integration', 'regulated-order review queue']
  },
  photography: {
    buyer: 'studio or photography business selling shoots and packages',
    offer: 'lead capture, booking, package selection, shoot planning, and delivery follow-up',
    kpis: ['inquiry-to-booking conversion', 'package upsell rate', 'delivery turnaround time'],
    scenarios: ['A wedding studio wants lead tracking, consultation booking, and package follow-up.', 'A portrait studio needs calendar coordination, deposits, and gallery delivery reminders.', 'A corporate photography team wants pipeline and production visibility for event bookings.'],
    addOns: ['proofing workflow', 'upsell album engine', 'team assignment board']
  },
  'real-estate': {
    buyer: 'brokerage, developer sales team, or real-estate operator',
    offer: 'lead pipeline, property registry, viewing scheduling, broker follow-up, and deal-stage visibility',
    kpis: ['lead-to-viewing conversion', 'viewing-to-offer conversion', 'broker response time'],
    scenarios: ['A brokerage wants WhatsApp leads converted into viewings, broker tasks, and deal stages.', 'A developer sales team needs inventory, inquiry routing, and follow-up dashboards.', 'A premium property advisor wants viewing history, hot lead prioritization, and team accountability.'],
    addOns: ['AI lead qualification', 'broker mobile app', 'inventory sync connectors']
  },
  restaurants: {
    buyer: 'restaurant, cafe, or hospitality operator',
    offer: 'reservations, tables, guest history, repeat signals, and order/ops follow-up in one system',
    kpis: ['reservation conversion', 'table turn efficiency', 'repeat guest rate'],
    scenarios: ['A fine-dining restaurant wants reservations, VIP guest notes, and table assignment visibility.', 'A cafe chain needs guest registry, waitlist, and repeat-visit signals.', 'A delivery-aware restaurant wants WhatsApp guest flows tied to reservations and order status.'],
    addOns: ['delivery location capture', 'loyalty signals', 'table floor planner']
  },
  salons: {
    buyer: 'salon or beauty operator with stylists and front desk',
    offer: 'appointments, services, stylist schedules, reminders, and repeat-client operations',
    kpis: ['booked chair utilization', 'repeat client rate', 'no-show rate'],
    scenarios: ['A salon wants front-desk booking and stylist assignment without chat chaos.', 'A beauty lounge needs service combos, repeat reminders, and manager visibility over utilization.', 'A multi-branch salon wants branch dashboards for stylists, top services, and revenue mix.'],
    addOns: ['package memberships', 'stylist performance board', 'beauty follow-up automation']
  },
  travel: {
    buyer: 'travel agency or packaged-travel operator',
    offer: 'lead qualification, quote follow-up, booking pipeline, document collection, and traveler support',
    kpis: ['inquiry-to-booking conversion', 'quote response time', 'repeat traveler rate'],
    scenarios: ['A travel agency wants inquiry intake, package proposals, and traveler follow-up in one place.', 'A visa-and-travel operator needs document collection tracking and sales visibility.', 'A premium travel consultant wants high-ticket traveler pipeline, payment stages, and support handoff control.'],
    addOns: ['document reminder engine', 'traveler support bot', 'partner supplier tracking']
  },
  veterinary: {
    buyer: 'veterinary clinic or pet care center',
    offer: 'pet records, appointments, vaccination follow-up, and owner communication in one stack',
    kpis: ['appointment utilization', 'vaccination reminder completion', 'repeat owner rate'],
    scenarios: ['A vet clinic wants pet intake, follow-up reminders, and front-desk dashboard control.', 'A pet hospital needs doctor schedules, visit history, and owner communication without spreadsheet gaps.', 'A grooming-and-vet hybrid business wants pet profile, recurring care reminders, and upsell visibility.'],
    addOns: ['vaccination protocol automation', 'pet owner portal', 'grooming cross-sell workflow']
  },
  wellness: {
    buyer: 'wellness studio, spa, or therapy center',
    offer: 'appointments, service packages, therapist schedules, and recovery follow-up workflow',
    kpis: ['session utilization', 'repeat package sales', 'client retention'],
    scenarios: ['A wellness studio wants session booking, package tracking, and therapist utilization dashboards.', 'A spa operator needs service bundles, reminder automation, and front-desk control.', 'A therapy center wants recurring-client flow and better follow-up on missed or delayed sessions.'],
    addOns: ['package wallet', 'therapist app', 'post-session care automation']
  }
}

function sectorPack(sector) {
  return sectorPlaybooks[sector.sector] || {
    buyer: `${sector.displayName} operator`,
    offer: sector.headline,
    kpis: ['conversion rate', 'utilization', 'repeat revenue'],
    scenarios: [`A ${sector.displayName.toLowerCase()} operator wants to run the full workflow from one control plane.`],
    addOns: ['AI receptionist', 'automation pack', 'analytics pack']
  }
}

function sectorPromptDoc(sector) {
  const pack = sectorPack(sector)
  return `# ${sector.displayName} - Sector First Prompts\n\n## 1) Claude kickoff prompt\n\n\`\`\`text\nRead AGENTS.md, proidea-agents.md, memory/shared/CURRENT_STATE.md, sector.config.json, docs/sector/BUSINESS-MODEL.md, and docs/sector/REAL-MARKET-SCENARIOS.md.\nAct as Claude-Orchestrator + Product Manager.\nFor ${sector.displayName}, choose the smallest sellable Wave 1 that solves one painful workflow for a ${pack.buyer}.\nOutput only:\n1. buyer and user\n2. workflow to ship first\n3. scope and out-of-scope\n4. acceptance criteria\n5. API + DB areas to touch\n6. UI states required\n7. automation/n8n needs\n8. test plan\n9. rollback note\n10. next owner\nThen update CHANGELOG.md, CURRENT_STATE.md, HANDOFFS.md, proidea-agent-team.md, and proidea-agents.md.\n\`\`\`\n\n## 2) Codex execution prompt\n\n\`\`\`text\nRead AGENTS.md, proidea-agents.md, memory/shared/CURRENT_STATE.md, sector.config.json, and the approved Claude wave output.\nAct as Codex-${sector.displayName}.\nImplement only the approved Wave 1 slice for ${sector.displayName}.\nRequirements:\n- protect tenant boundaries\n- keep scope narrow\n- add tests for happy path, validation, permission failure, and tenant isolation\n- do not redesign architecture\nReturn:\n- changed files\n- commands run\n- tests run\n- open risks\n- rollback note\n- exact ledger row values including duration and tokens\nBefore finishing, update CHANGELOG.md, proidea-agent-team.md, and proidea-agents.md.\n\`\`\`\n\n## 3) Antigravity UI prompt\n\n\`\`\`text\nRead AGENTS.md, proidea-agents.md, sector.config.json, docs/sector/BUSINESS-MODEL.md, and docs/sector/REAL-MARKET-SCENARIOS.md.\nAct as Antigravity Design Lead for ${sector.displayName}.\nDesign a premium but realistic UI for the first operator workflow and the public-facing landing page.\nRequirements:\n- Arabic-friendly hierarchy\n- clear CTA tied to ${pack.offer}\n- loading, empty, success, error, and permission-denied states\n- motion only where it improves comprehension\n- no backend contract changes\nReturn the components and pages changed plus any frontend tasks that still need Codex.\nThen update CHANGELOG.md, proidea-agent-team.md, and proidea-agents.md.\n\`\`\`\n\n## 4) Claude release gate prompt\n\n\`\`\`text\nRead CURRENT_STATE.md, CHANGELOG.md, HANDOFFS.md, QA outputs, security outputs, performance outputs, and the latest diff summary.\nAct as Release Manager.\nDecide go / no-go for staging.\nReturn blockers, mitigation, rollback path, migration risk, and next exact command sequence.\nUpdate RELEASE_STATUS.md and both ledgers.\n\`\`\`\n`
}

function sectorMarketDoc(sector) {
  const pack = sectorPack(sector)
  return `# ${sector.displayName} - Real Market Scenarios\n\n## Ideal buyer\n${slugToTitle(sector.sector)} works best first for a ${pack.buyer}.\n\n## Core offer\n${pack.offer}\n\n## Three real client scenarios\n${pack.scenarios.map((s, i) => `${i + 1}. ${s}`).join('\n')}\n\n## KPIs the buyer will pay for\n${pack.kpis.map((k) => `- ${k}`).join('\n')}\n\n## First sellable package\n- Setup + onboarding\n- Role-safe operator dashboard\n- Core workflow for ${sector.entities.slice(0, 2).map((e) => e.label.toLowerCase()).join(' + ')}\n- WhatsApp or automation touchpoints where relevant\n- Reporting and follow-up visibility\n\n## Best add-ons after the core package\n${pack.addOns.map((x) => `- ${x}`).join('\n')}\n\n## Buyer language\nSell this sector by promising:\n- faster operations\n- fewer dropped follow-ups\n- clearer staff accountability\n- a dashboard the owner can actually read\n- a setup path that does not require enterprise complexity on day one\n`
}

function sectorSalesDoc(sector) {
  const pack = sectorPack(sector)
  return `# ${sector.displayName} - Sellable Package Blueprint\n\n## Who buys\n- Business owner or operations manager in ${pack.buyer}\n\n## What they buy first\n- A first live workflow that feels operational in less than 30 days\n- A dashboard for owners and operators\n- A channel layer for inbound leads, bookings, or service requests\n- Shared memory and agent-led implementation discipline\n\n## Sales promise\n\"We make ${sector.displayName.toLowerCase()} operations easier to run, easier to track, and easier to grow without needing a giant ERP.\"\n\n## Delivery milestones\n1. Discovery + process map\n2. First live workflow\n3. Dashboard + operator training\n4. Automation and reporting\n5. Add-on upsell\n\n## Upsell direction\n${pack.addOns.map((x) => `- ${x}`).join('\n')}\n`
}

function sectorStartHere(sector) {
  return `# ${sector.displayName} - Start Here\n\n1. Read \`AGENTS.md\`, \`proidea-agents.md\`, and \`memory/shared/CURRENT_STATE.md\`.\n2. Read \`sector.config.json\`, \`docs/sector/BUSINESS-MODEL.md\`, and \`docs/sector/REAL-MARKET-SCENARIOS.md\`.\n3. Open \`docs/sector/SECTOR-FIRST-PROMPTS.md\` and choose the first Claude kickoff prompt.\n4. Run:\n\`\`\`bash\ncorepack enable\ncorepack prepare pnpm@10.33.0 --activate\npnpm install\nbash bootstrap.sh\n\`\`\`\n5. Configure \`.env.local\` from \`.env.example\`.\n6. Apply \`database/migrations/*.sql\` to your Supabase/Postgres project.\n7. Start with one sellable workflow only. Do not build the whole sector at once.\n8. After every meaningful task, update shared memory and both agent ledgers.\n\nThis repo is sector-specific. Do not assume the same database model as any other sector.\n`
}

function businessModelDoc(sector) {
  const pack = sectorPack(sector)
  return `# ${sector.displayName} business model\n\nHeadline: ${sector.headline}\n\n## Primary buyer\n${pack.buyer}\n\n## Primary entities\n${sector.entities.map((entity) => `- ${entity.label} (\`${entity.table}\`)`).join('\n')}\n\n## Primary roles\n${sector.roles.map((role) => `- ${role}`).join('\n')}\n\n## Commercial promise\n${pack.offer}\n`
}

function firstSliceDoc(sector) {
  const pack = sectorPack(sector)
  return `# First implementation slice - ${sector.displayName}\n\nShip this in order:\n1. Auth login + staff membership verification\n2. Dashboard summary counts for the owner/operator\n3. CRUD for the first two sector entities\n4. One automation ingestion webhook or WhatsApp capture path\n5. One operator workflow screen that proves the daily loop\n6. One public-facing landing page section that sells the offer\n\n## First KPI targets\n${pack.kpis.map((k) => `- ${k}`).join('\n')}\n`
}

const updateLedgerScript = "#!/usr/bin/env node\nimport fs from 'node:fs/promises'\nimport path from 'node:path'\n\nconst args = process.argv.slice(2)\nconst get = (flag, fallback = '') => {\n  const index = args.indexOf(flag)\n  return index >= 0 ? (args[index + 1] ?? fallback) : fallback\n}\n\nconst cwd = process.cwd()\nconst sector = get('--sector', path.basename(cwd).replace(/^proidea-/, ''))\nconst date = get('--date', new Date().toISOString().slice(0, 10))\nconst started = get('--started', new Date().toISOString())\nconst ended = get('--ended', new Date().toISOString())\nconst duration = get('--duration', '')\nconst tokensIn = get('--tokens-in', '')\nconst tokensOut = get('--tokens-out', '')\nconst tokensTotal = get('--tokens-total', String((Number(tokensIn || 0) + Number(tokensOut || 0)) || ''))\nconst row = `| ${date} | ${sector} | ${get('--task', 'task')} | ${get('--agent', 'agent')} | ${get('--model', 'model')} | ${started} | ${ended} | ${duration} | ${tokensIn} | ${tokensOut} | ${tokensTotal} | ${get('--result', 'completed')} | ${get('--status', 'done')} | ${get('--files', '-')} | ${get('--next-owner', '-')} | ${get('--next-step', '-')} | ${get('--notes', '-')} |\\n`\n\nfor (const file of ['proidea-agent-team.md', 'proidea-agents.md']) {\n  const target = path.join(cwd, file)\n  let current = await fs.readFile(target, 'utf8')\n  current += current.endsWith('\\n') ? row : `\\n${row}`\n  await fs.writeFile(target, current)\n}\n"

async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true })
}

async function write(file, content) {
  await ensureDir(path.dirname(file))
  await fs.writeFile(file, content)
}

async function exists(file) {
  try { await fs.access(file); return true } catch { return false }
}

async function copyRoleAgents(repoDir) {
  const src = path.join(repoDir, '.agents')
  const dst = path.join(repoDir, '.claude', 'agents')
  if (!(await exists(src))) return
  await ensureDir(dst)
  const files = await fs.readdir(src)
  for (const name of files) {
    const content = await fs.readFile(path.join(src, name), 'utf8')
    await fs.writeFile(path.join(dst, name), content)
  }
}

async function syncRepo(repoDir) {
  const sectorConfigPath = path.join(repoDir, 'sector.config.json')
  const hasSector = await exists(sectorConfigPath)
  const sector = hasSector ? JSON.parse(await fs.readFile(sectorConfigPath, 'utf8')) : null
  const sectorName = sector?.displayName ?? 'Platform Base'
  const sectorSlug = sector?.sector ?? 'platform-base'

  await write(path.join(repoDir, 'AGENTS.md'), genericAgentsMd)
  await write(path.join(repoDir, 'proidea-agents.md'), genericProideaAgents(sectorName))
  await write(path.join(repoDir, 'proidea-agent-team.md'), genericAgentTeam(sectorSlug))
  await write(path.join(repoDir, 'CLAUDE.md'), genericClaudeMd)
  await write(path.join(repoDir, 'docs', 'PROMPTS-GUIDE.md'), genericPromptsGuide)
  await write(path.join(repoDir, 'docs', 'VIBE-CODE-MANUAL.md'), genericVibeManual)
  await write(path.join(repoDir, 'docs', 'READY-TO-SELL-ACTION-PLAN.md'), genericReadyToSell)
  await write(path.join(repoDir, 'docs', 'qa', 'QUALITY-GATES.md'), genericQualityGates)
  await write(path.join(repoDir, 'scripts', 'update-agent-ledger.mjs'), updateLedgerScript)
  await fs.chmod(path.join(repoDir, 'scripts', 'update-agent-ledger.mjs'), 0o755)

  await ensureDir(path.join(repoDir, '.claude', 'commands'))
  for (const [name, content] of Object.entries(claudeCommands)) {
    await write(path.join(repoDir, '.claude', 'commands', name), content + '\n')
  }
  await ensureDir(path.join(repoDir, '.codex', 'prompts'))
  for (const [name, content] of Object.entries(codexPrompts)) {
    await write(path.join(repoDir, '.codex', 'prompts', name), content + '\n')
  }
  await ensureDir(path.join(repoDir, '.antigravity', 'prompts'))
  for (const [name, content] of Object.entries(antigravityPrompts)) {
    await write(path.join(repoDir, '.antigravity', 'prompts', name), content + '\n')
  }
  await ensureDir(path.join(repoDir, '.claude', 'agents'))
  for (const [name, content] of Object.entries(agents)) {
    await write(path.join(repoDir, '.claude', 'agents', name), content)
  }
  await copyRoleAgents(repoDir)

  if (sector) {
    await write(path.join(repoDir, 'SECTOR-START-HERE.md'), sectorStartHere(sector))
    await write(path.join(repoDir, 'docs', 'sector', 'BUSINESS-MODEL.md'), businessModelDoc(sector))
    await write(path.join(repoDir, 'docs', 'sector', 'FIRST-IMPLEMENTATION-SLICE.md'), firstSliceDoc(sector))
    await write(path.join(repoDir, 'docs', 'sector', 'REAL-MARKET-SCENARIOS.md'), sectorMarketDoc(sector))
    await write(path.join(repoDir, 'docs', 'sector', 'SECTOR-FIRST-PROMPTS.md'), sectorPromptDoc(sector))
    await write(path.join(repoDir, 'docs', 'sector', 'SELLABLE-PACKAGE.md'), sectorSalesDoc(sector))
    const currentStatePath = path.join(repoDir, 'memory', 'shared', 'CURRENT_STATE.md')
    if (await exists(currentStatePath)) {
      await write(currentStatePath, `# Current State\n\nStatus: operating-system-upgraded\nPhase: ready-for-sector-wave-planning\nBlockers: none added by this upgrade; implementation risk still depends on actual wave execution\nLast action: docs, prompts, ledgers, and real-market scenarios added for ${sector.displayName}\nNext step: run the Claude kickoff prompt in docs/sector/SECTOR-FIRST-PROMPTS.md and choose one Wave 1 workflow only\n\n## Sectorization\nThis repo is the standalone ${sector.displayName} build generated from the Proidea base and upgraded with shared memory, ledgers, prompt packs, and sellable-market scenarios.\n`)
    }
  }
}

async function main() {
  const entries = await fs.readdir(packRoot, { withFileTypes: true })
  for (const entry of entries) {
    if (!entry.isDirectory()) continue
    if (!entry.name.startsWith('proidea-')) continue
    await syncRepo(path.join(packRoot, entry.name))
  }
}

await main()
