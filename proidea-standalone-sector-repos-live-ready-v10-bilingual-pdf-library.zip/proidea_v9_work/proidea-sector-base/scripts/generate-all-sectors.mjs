import { loadDefinitions, generateSectorRepo } from './sector-factory-lib.mjs'

const definitions = await loadDefinitions()
for (const sector of definitions) {
  const result = await generateSectorRepo(sector)
  console.log(`Generated ${result.sector.displayName} -> ${result.targetDir}`)
}
