import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
export const ROOT_DIR = path.resolve(__dirname, '..')

const FACTORY_ONLY = new Set([
  'scripts/generate-sector-repo.mjs',
  'scripts/generate-all-sectors.mjs',
  'scripts/sector-factory-lib.mjs',
  'docs/sector-archetypes.md',
  'docs/sector-factory-workflow.md',
  'sectors/sector-catalog.json',
  'sectors/sector-definitions.json',
])

const DEFAULT_RUNTIME = {
  site: 'nextjs',
  web: 'vite-react',
  admin: 'vite-react',
  api: 'fastify',
  mobile: 'expo-react-native',
  db: 'supabase-postgres',
}

function toPosix(input) {
  return input.split(path.sep).join('/')
}

function title(input) {
  return String(input)
    .split('-')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ')
}

function slugPrefix(table) {
  return String(table).replace(/s$/, '').slice(0, 3).padEnd(3, 'x')
}

function json(value) {
  return `${JSON.stringify(value, null, 2)}\n`
}

async function exists(filePath) {
  try {
    await fs.access(filePath)
    return true
  } catch {
    return false
  }
}

async function copyDir(sourceDir, targetDir, rootSource = sourceDir) {
  await fs.mkdir(targetDir, { recursive: true })
  const entries = await fs.readdir(sourceDir, { withFileTypes: true })
  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name)
    const relativePath = toPosix(path.relative(rootSource, sourcePath))
    if (!relativePath) continue
    if (entry.name === '.git' || entry.name === 'node_modules') continue
    if (FACTORY_ONLY.has(relativePath)) continue
    const targetPath = path.join(targetDir, entry.name)
    if (entry.isDirectory()) {
      await copyDir(sourcePath, targetPath, rootSource)
    } else {
      await fs.copyFile(sourcePath, targetPath)
    }
  }
}

export async function loadDefinitions() {
  const filePath = path.join(ROOT_DIR, 'sectors', 'sector-definitions.json')
  return JSON.parse(await fs.readFile(filePath, 'utf8'))
}

export async function resolveSector(input) {
  const definitions = await loadDefinitions()
  const normalized = String(input).trim().toLowerCase()
  const sector = definitions.find((item) =>
    [item.sector, item.displayName, item.displayNameAr, item.resourceBase]
      .filter(Boolean)
      .map((value) => String(value).trim().toLowerCase())
      .includes(normalized)
  )
  if (!sector) {
    throw new Error(`Unknown sector: ${input}`)
  }
  return sector
}

function sectorConfig(sector) {
  return {
    sector: sector.sector,
    displayName: sector.displayName,
    displayNameAr: sector.displayNameAr,
    resourceBase: sector.resourceBase,
    archetype: sector.archetype,
    headline: sector.headline,
    roles: sector.roles,
    entities: sector.entities,
    capabilities: sector.capabilities,
    runtime: sector.runtime ?? DEFAULT_RUNTIME,
  }
}

function renderSectorTs(sector) {
  const payload = {
    slug: sector.sector,
    displayName: sector.displayName,
    resourceBase: sector.resourceBase,
    headline: sector.headline,
    roles: sector.roles,
    entities: sector.entities,
    capabilities: sector.capabilities,
  }
  return `export const sector = ${JSON.stringify(payload, null, 2)} as const\n`
}

function renderReadme(sector) {
  return `# Proidea ${sector.displayName}\n\nStandalone sector repo generated from \`proidea-sector-base\` and prepared for vibe coding.\n\n## Stack\n- Site: Next.js\n- Web/Admin: Vite React\n- API: Fastify\n- Mobile: Expo React Native\n- Database: Supabase / Postgres\n- Deploy: VPS Docker + Portainer\n\n## Sector model\n- Archetype: \`${sector.archetype}\`\n- Resource base: \`${sector.resourceBase}\`\n- Roles: ${sector.roles.join(', ')}\n\n## Quick start\n\`\`\`bash\ncorepack enable\ncorepack prepare pnpm@10.33.0 --activate\npnpm install\nbash bootstrap.sh\n\`\`\`\n\n## What is already included\n- live Supabase/Postgres adapter scaffolds\n- staff auth + tenant RBAC scaffolds\n- live dashboard summary route\n- mobile dashboard shell\n- animated marketing site scaffold\n- automation webhook connector scaffold\n\n## First implementation slice\nSee \`SECTOR-START-HERE.md\` and \`docs/sector/FIRST-IMPLEMENTATION-SLICE.md\`.\n`
}

function renderSectorStartHere(sector) {
  return `# ${sector.displayName} — Start Here\n\n1. Read \`AGENTS.md\` and \`memory/shared/CURRENT_STATE.md\`.\n2. Read \`sector.config.json\`.\n3. Run \`bash bootstrap.sh\`.\n4. Apply \`database/migrations/*.sql\` to your Supabase/Postgres project.\n5. Configure \`.env.local\` from \`.env.example\`.\n6. Start with the API + dashboard summary for this sector.\n\nThis repo is sector-specific. Do not assume the same database model as any other sector.\n`
}

function renderBusinessModel(sector) {
  return `# ${sector.displayName} business model\n\nHeadline: ${sector.headline}\n\nPrimary entities:\n${sector.entities.map((entity) => `- ${entity.label} (\`${entity.table}\`)`).join('\n')}\n\nPrimary roles:\n${sector.roles.map((role) => `- ${role}`).join('\n')}\n`
}

function renderFirstSlice(sector) {
  return `# First implementation slice — ${sector.displayName}\n\nShip this in order:\n1. Auth login + staff membership verification\n2. Dashboard summary counts\n3. CRUD for first two sector entities\n4. Automation ingestion webhook\n5. Mobile dashboard read-only view\n6. Marketing site content polish\n`
}

function renderRbacMatrix(sector) {
  return `# RBAC matrix\n\n${sector.roles.map((role) => `- ${role}: ${sector.capabilities.join(', ')}`).join('\n')}\n`
}

function renderPersistenceAdapters(sector) {
  return `# Persistence adapters\n\nThis repo uses Supabase/Postgres as the live persistence adapter for ${sector.displayName}.\n`
}

function renderAutomationConnectors() {
  return `# Automation connectors\n\nUse \`/api/internal/automation/ingest\` to normalize inbound WhatsApp, voice, or workflow payloads into sector records.\n`
}

function renderDashboardLiveData() {
  return `# Dashboard live data\n\nThe web, admin, and mobile shells read from \`/api/dashboard/summary\` using live database counts.\n`
}

function renderReviewAndImprovements(sector) {
  return `# Review and improvements\n\nThis repo was generated for ${sector.displayName}. Continue by replacing scaffolds with real business logic one slice at a time.\n`
}

function renderCurrentState(sector) {
  return `# Current State\n\nStatus: api-verified\nPhase: Phase 0 complete\nBlockers: none\nLast action: GET /health verified returns ok true on port 4000\nFix applied: killed stale tsx process after EADDRINUSE, no code change required\nNext step: Phase 1 implement Supabase schema and auth layer\n\n\n## Sectorization\nThis repo is the standalone ${sector.displayName} build generated from the latest Proidea base.\n`
}

function renderOpenQuestions(sector) {
  return `# Open Questions\n\n- Add project-specific open questions here.\n\n\n- Which first live tenant should use \`${sector.sector}\`?\n`
}

function renderDecisions(sector) {
  return `# Decisions\n\n- Keep the monorepo starter structure across API, web, admin, site, and mobile so teams can ship in parallel.\n- Use shared memory files as the source of truth for state, blockers, and handoffs.\n- Gate production-critical changes behind review, QA, security, and rollback readiness.\n- Use Spec Kit for specs/plans/tasks and GSD-style wave execution for implementation.\n\nContext: Large SaaS project with many modules needs both strong specifications and high-throughput execution.\nDecision: Use Spec Kit for specs/plans/tasks and GSD-style wave execution for implementation.\nConsequences: Every major feature starts with spec first, then execution is delegated to specialized agents.\n\n\n- Sector repo locked to \`${sector.sector}\` with its own database model, routes, dashboard, mobile shell, and marketing site.\n`
}

function renderApiApp(sector) {
  return `import Fastify from 'fastify'\nimport cors from '@fastify/cors'\nimport { registerSectorRoutes } from './modules/${sector.sector}/routes.js'\nimport { sector } from './sector.js'\n\nexport function buildApp() {\n  const app = Fastify({ logger: true })\n  app.register(cors, { origin: true })\n  app.get('/health', async () => ({ ok: true, service: 'api', sector: sector.slug, timestamp: new Date().toISOString() }))\n  app.register(registerSectorRoutes)\n  return app\n}\n`
}

function renderServerTs() {
  return `import { buildApp } from './app.js'\nimport { apiConfig } from './config.js'\n\nconst app = buildApp()\napp.listen({ port: apiConfig.PORT, host: apiConfig.HOST }, (err) => {\n  if (err) {\n    app.log.error(err)\n    process.exit(1)\n  }\n})\n`
}

function renderServerTest(sector) {
  return `import { describe, expect, it } from 'vitest'\nimport { buildApp } from './app.js'\n\ndescribe('${sector.displayName} api', () => {\n  it('builds the app', async () => {\n    const app = buildApp()\n    const response = await app.inject({ method: 'GET', url: '/health' })\n    expect(response.statusCode).toBe(200)\n  })\n})\n`
}

function renderHttpTs() {
  return `import type { FastifyReply } from 'fastify'\n\nexport function ok(reply: FastifyReply, payload: unknown) {\n  return reply.code(200).send({ ok: true, ...((payload ?? {}) as Record<string, unknown>) })\n}\n\nexport function fail(reply: FastifyReply, status: number, error: string, code?: string) {\n  return reply.code(status).send({ ok: false, error, code: code ?? 'request_failed' })\n}\n`
}

function renderSupabaseTs() {
  return `import { createClient } from '@supabase/supabase-js'\n\nconst url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL || ''\nconst anonKey = process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''\nconst serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ''\n\nif (!url || !anonKey) {\n  console.warn('Supabase env is not fully configured yet.')\n}\n\nexport const supabaseAuth = createClient(url, anonKey, {\n  auth: { persistSession: false, autoRefreshToken: false },\n})\n\nexport const supabaseAdmin = serviceRoleKey\n  ? createClient(url, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } })\n  : supabaseAuth\n`
}

function renderAuthTs() {
  return `import type { FastifyRequest } from 'fastify'\nimport { supabaseAdmin, supabaseAuth } from './supabase.js'\n\nexport async function loginWithPassword(email: string, password: string) {\n  const { data, error } = await supabaseAuth.auth.signInWithPassword({ email, password })\n  if (error || !data.session) {\n    throw new Error(error?.message || 'Login failed')\n  }\n  return data.session\n}\n\nexport async function requireUser(request: FastifyRequest) {\n  const authHeader = request.headers.authorization || ''\n  if (!authHeader.toLowerCase().startsWith('bearer ')) {\n    throw new Error('Missing bearer token')\n  }\n  const token = authHeader.slice(7).trim()\n  const { data, error } = await supabaseAuth.auth.getUser(token)\n  if (error || !data.user) {\n    throw new Error(error?.message || 'Invalid session token')\n  }\n  return { token, user: data.user }\n}\n\nexport async function resolveMembership(userId: string, tenantId?: string | null) {\n  const { data: profile, error: profileError } = await supabaseAdmin\n    .from('staff_profiles')\n    .select('id, user_id, email, full_name, is_active')\n    .eq('user_id', userId)\n    .maybeSingle()\n  if (profileError || !profile || profile.is_active === false) {\n    throw new Error('Staff profile missing or inactive')\n  }\n\n  let query = supabaseAdmin\n    .from('staff_tenant_memberships')\n    .select('id, tenant_id, role, capabilities, is_active')\n    .eq('staff_profile_id', profile.id)\n    .eq('is_active', true)\n    .limit(1)\n  if (tenantId) query = query.eq('tenant_id', tenantId)\n  const { data: membership, error: membershipError } = await query.maybeSingle()\n  if (membershipError || !membership) {\n    throw new Error('Staff membership missing for this tenant')\n  }\n\n  const { data: tenant, error: tenantError } = await supabaseAdmin\n    .from('tenants')\n    .select('id, slug, name, plan_code, locale, status')\n    .eq('id', membership.tenant_id)\n    .maybeSingle()\n  if (tenantError || !tenant) {\n    throw new Error('Tenant record missing')\n  }\n\n  return { profile, membership, tenant }\n}\n`
}

function renderRbacTs() {
  return `export function hasCapability(input: { role: string; capabilities: string[] | unknown; required: string }) {\n  if (input.role === 'owner' || input.role === 'admin') return true\n  const caps = Array.isArray(input.capabilities) ? input.capabilities.map(String) : []\n  return caps.includes(input.required)\n}\n`
}

function renderRepositoryTs(sector) {
  const defs = sector.entities.map((entity) => ({ table: entity.table, label: entity.label }))
  return `import { supabaseAdmin } from '../../lib/supabase.js'\nimport { sector } from '../../sector.js'\n\nexport async function listEntity(table: string, tenantId: string) {\n  const { data, error } = await supabaseAdmin\n    .from(table)\n    .select('*')\n    .eq('tenant_id', tenantId)\n    .order('created_at', { ascending: false })\n    .limit(50)\n  if (error) throw error\n  return data ?? []\n}\n\nexport async function listScopedTable(table: string, tenantId: string) {\n  const { data, error } = await supabaseAdmin\n    .from(table)\n    .select('*')\n    .eq('tenant_id', tenantId)\n    .order('updated_at', { ascending: false })\n    .limit(50)\n  if (error) throw error\n  return data ?? []\n}\n\nexport async function createEntity(table: string, tenantId: string, payload: Record<string, unknown>, actorId?: string | null) {\n  const { data, error } = await supabaseAdmin\n    .from(table)\n    .insert({ tenant_id: tenantId, ...payload, created_by: actorId ?? null, updated_by: actorId ?? null })\n    .select('*')\n    .single()\n  if (error) throw error\n  return data\n}\n\nexport async function updateEntityStatus(table: string, tenantId: string, id: string, status: string, actorId?: string | null) {\n  const { data, error } = await supabaseAdmin\n    .from(table)\n    .update({ status, updated_by: actorId ?? null, updated_at: new Date().toISOString() })\n    .eq('tenant_id', tenantId)\n    .eq('id', id)\n    .select('*')\n    .single()\n  if (error) throw error\n  return data\n}\n\nexport async function dashboardSummary(tenantId: string) {\n  const defs = ${JSON.stringify(defs, null, 2)} as Array<{ table: string; label: string }>\n  const counts = [] as Array<{ table: string; label: string; count: number }>\n  for (const def of defs) {\n    const { count, error } = await supabaseAdmin\n      .from(def.table)\n      .select('id', { count: 'exact', head: true })\n      .eq('tenant_id', tenantId)\n    if (error) throw error\n    counts.push({ table: def.table, label: def.label, count: count ?? 0 })\n  }\n  return { sector: sector.slug, displayName: sector.displayName, counts }\n}\n`
}

function renderServiceTs(sector) {
  const menuCategoryHelper = sector.sector === 'restaurants'
    ? `\nexport async function getMenuCategories(tenantId: string) {\n  return listScopedTable('menu_categories', tenantId)\n}\n`
    : ''
  return `import { createEntity, dashboardSummary, listEntity, listScopedTable, updateEntityStatus } from './repository.js'\nimport { sector } from '../../sector.js'\n\nexport async function getDashboardSummary(tenantId: string) {\n  return dashboardSummary(tenantId)\n}\n\nexport async function getEntityList(entityKey: string, tenantId: string) {\n  const entity = sector.entities.find((item) => item.table === entityKey)\n  if (!entity) throw new Error(\`Unknown entity: ${'${entityKey}'}\`)\n  return listEntity(entity.table, tenantId)\n}\n\nexport async function createEntityRecord(entityKey: string, tenantId: string, payload: Record<string, unknown>, actorId?: string | null) {\n  const entity = sector.entities.find((item) => item.table === entityKey)\n  if (!entity) throw new Error(\`Unknown entity: ${'${entityKey}'}\`)\n  return createEntity(entity.table, tenantId, payload, actorId)\n}\n\nexport async function changeEntityStatus(entityKey: string, tenantId: string, id: string, status: string, actorId?: string | null) {\n  const entity = sector.entities.find((item) => item.table === entityKey)\n  if (!entity) throw new Error(\`Unknown entity: ${'${entityKey}'}\`)\n  return updateEntityStatus(entity.table, tenantId, id, status, actorId)\n}\n${menuCategoryHelper}`
}

function renderAutomationTs(sector) {
  if (sector.sector === 'restaurants') {
    return `import { createEntityRecord } from './service.js'\n\nexport async function ingestAutomationEvent(tenantId: string, payload: Record<string, unknown>, actorId?: string | null) {\n  if (payload?.messageType === 'location' && payload?.orderId) {\n    const orderId = String(payload.orderId)\n    const deliveryLat = Number(payload.latitude ?? (payload.location as Record<string, unknown> | undefined)?.latitude ?? 0)\n    const deliveryLng = Number(payload.longitude ?? (payload.location as Record<string, unknown> | undefined)?.longitude ?? 0)\n    const deliveryAddress = String(payload.addressLabel ?? (payload.location as Record<string, unknown> | undefined)?.address ?? '')\n    await createEntityRecord('orders', tenantId, {\n      title: 'WhatsApp delivery location received',\n      status: 'out_for_delivery',\n      summary: deliveryAddress,\n      metadata: { orderId, deliveryLat, deliveryLng, source: 'whatsapp-location', raw: payload },\n    }, actorId)\n    return { handled: true, channel: 'whatsapp-location', orderId, deliveryLat, deliveryLng }\n  }\n\n  return createEntityRecord('guests', tenantId, {\n    title: String(payload.title ?? payload.message ?? payload.summary ?? 'Automation event'),\n    status: String(payload.status ?? 'active'),\n    summary: String(payload.summary ?? payload.message ?? ''),\n    phone: typeof payload.phone === 'string' ? payload.phone : null,\n    email: typeof payload.email === 'string' ? payload.email : null,\n    metadata: payload,\n  }, actorId)\n}\n`
  }

  const defaultEntity = sector.entities[0]?.table ?? 'records'
  return `import { createEntityRecord } from './service.js'\n\nexport async function ingestAutomationEvent(tenantId: string, payload: Record<string, unknown>, actorId?: string | null) {\n  return createEntityRecord('${defaultEntity}', tenantId, {\n    title: String(payload.title ?? payload.message ?? payload.summary ?? 'Automation event'),\n    status: String(payload.status ?? 'active'),\n    summary: String(payload.summary ?? payload.message ?? ''),\n    phone: typeof payload.phone === 'string' ? payload.phone : null,\n    email: typeof payload.email === 'string' ? payload.email : null,\n    metadata: payload,\n  }, actorId)\n}\n`
}

function renderRoutesTs(sector) {
  const extraRoutes = sector.sector === 'restaurants'
    ? `
  app.get('/api/${sector.resourceBase}/menu-categories', async (request, reply) => {
    try {
      const { user } = await requireUser(request)
      const query = (request.query ?? {}) as Record<string, unknown>
      const context = await resolveMembership(user.id, typeof query.tenantId === 'string' ? query.tenantId : null)
      if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'records.read' })) {
        return fail(reply, 403, 'Permission denied', 'rbac_denied')
      }
      const items = await getMenuCategories(context.tenant.id)
      return ok(reply, { items, tenant: context.tenant })
    } catch (error) {
      return fail(reply, 500, error instanceof Error ? error.message : 'Request failed')
    }
  })

  app.post('/api/${sector.resourceBase}/orders/location', async (request, reply) => {
    try {
      const { user } = await requireUser(request)
      const body = (request.body ?? {}) as Record<string, unknown>
      const location = (body.location ?? {}) as Record<string, unknown>
      const context = await resolveMembership(user.id, typeof body.tenantId === 'string' ? body.tenantId : null)
      if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'delivery.manage' })) {
        return fail(reply, 403, 'Permission denied', 'delivery_denied')
      }
      const result = await ingestAutomationEvent(context.tenant.id, {
        ...body,
        messageType: 'location',
        latitude: body.latitude ?? location.latitude,
        longitude: body.longitude ?? location.longitude,
        addressLabel: body.addressLabel ?? location.address,
      }, context.profile.id)
      return ok(reply, { result, tenant: context.tenant })
    } catch (error) {
      return fail(reply, 500, error instanceof Error ? error.message : 'Request failed')
    }
  })
`
    : ''

  const serviceImports = sector.sector === 'restaurants'
    ? `import { changeEntityStatus, createEntityRecord, getDashboardSummary, getEntityList, getMenuCategories } from './service.js'`
    : `import { changeEntityStatus, createEntityRecord, getDashboardSummary, getEntityList } from './service.js'`

  return `import type { FastifyInstance } from 'fastify'
import { requireUser, resolveMembership, loginWithPassword } from '../../lib/auth.js'
import { fail, ok } from '../../lib/http.js'
import { hasCapability } from '../../lib/rbac.js'
${serviceImports}
import { ingestAutomationEvent } from './automation.js'
import { sector } from '../../sector.js'

export async function registerSectorRoutes(app: FastifyInstance) {
  app.post('/auth/login', async (request, reply) => {
    try {
      const body = (request.body ?? {}) as Record<string, unknown>
      const email = typeof body.email === 'string' ? body.email : ''
      const password = typeof body.password === 'string' ? body.password : ''
      const session = await loginWithPassword(email, password)
      const membership = await resolveMembership(session.user.id, typeof body.tenantId === 'string' ? body.tenantId : null)
      return ok(reply, {
        accessToken: session.access_token,
        refreshToken: session.refresh_token,
        user: membership.profile,
        membership: membership.membership,
        tenant: membership.tenant,
      })
    } catch (error) {
      return fail(reply, 401, error instanceof Error ? error.message : 'Login failed', 'login_failed')
    }
  })

  app.get('/auth/me', async (request, reply) => {
    try {
      const { user } = await requireUser(request)
      const query = (request.query ?? {}) as Record<string, unknown>
      const membership = await resolveMembership(user.id, typeof query.tenantId === 'string' ? query.tenantId : null)
      return ok(reply, { user: membership.profile, membership: membership.membership, tenant: membership.tenant })
    } catch (error) {
      return fail(reply, 401, error instanceof Error ? error.message : 'Unauthorized', 'unauthorized')
    }
  })

  app.get('/api/dashboard/summary', async (request, reply) => {
    try {
      const { user } = await requireUser(request)
      const query = (request.query ?? {}) as Record<string, unknown>
      const context = await resolveMembership(user.id, typeof query.tenantId === 'string' ? query.tenantId : null)
      if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'dashboard.read' })) {
        return fail(reply, 403, 'Permission denied', 'rbac_denied')
      }
      const summary = await getDashboardSummary(context.tenant.id)
      return ok(reply, { summary, tenant: context.tenant, user: context.profile })
    } catch (error) {
      return fail(reply, 500, error instanceof Error ? error.message : 'Dashboard summary failed')
    }
  })

  app.post('/api/internal/automation/ingest', async (request, reply) => {
    try {
      const body = (request.body ?? {}) as Record<string, unknown>
      const tenantId = typeof body.tenantId === 'string' ? body.tenantId : ''
      if (!tenantId) return fail(reply, 400, 'tenantId is required', 'tenant_required')
      const result = await ingestAutomationEvent(tenantId, body)
      return ok(reply, { result })
    } catch (error) {
      return fail(reply, 500, error instanceof Error ? error.message : 'Automation ingest failed')
    }
  })
${extraRoutes}
  for (const entity of sector.entities) {
    app.get('/api/' + sector.resourceBase + '/' + entity.table, async (request, reply) => {
      try {
        const { user } = await requireUser(request)
        const query = (request.query ?? {}) as Record<string, unknown>
        const context = await resolveMembership(user.id, typeof query.tenantId === 'string' ? query.tenantId : null)
        if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'records.read' })) {
          return fail(reply, 403, 'Permission denied', 'rbac_denied')
        }
        const items = await getEntityList(entity.table, context.tenant.id)
        return ok(reply, { items, tenant: context.tenant })
      } catch (error) {
        return fail(reply, 500, error instanceof Error ? error.message : 'Request failed')
      }
    })

    app.post('/api/' + sector.resourceBase + '/' + entity.table, async (request, reply) => {
      try {
        const { user } = await requireUser(request)
        const body = (request.body ?? {}) as Record<string, unknown>
        const context = await resolveMembership(user.id, typeof body.tenantId === 'string' ? body.tenantId : null)
        if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'records.write' })) {
          return fail(reply, 403, 'Permission denied', 'rbac_denied')
        }
        const record = await createEntityRecord(entity.table, context.tenant.id, body, context.profile.id)
        return ok(reply, { record, tenant: context.tenant })
      } catch (error) {
        return fail(reply, 500, error instanceof Error ? error.message : 'Create failed')
      }
    })

    app.patch('/api/' + sector.resourceBase + '/' + entity.table + '/:id/status', async (request, reply) => {
      try {
        const { user } = await requireUser(request)
        const body = (request.body ?? {}) as Record<string, unknown>
        const params = request.params as { id: string }
        const context = await resolveMembership(user.id, typeof body.tenantId === 'string' ? body.tenantId : null)
        if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'records.write' })) {
          return fail(reply, 403, 'Permission denied', 'rbac_denied')
        }
        const record = await changeEntityStatus(entity.table, context.tenant.id, params.id, String(body.status ?? 'active'), context.profile.id)
        return ok(reply, { record, tenant: context.tenant })
      } catch (error) {
        return fail(reply, 500, error instanceof Error ? error.message : 'Status update failed')
      }
    })
  }
}
`
}

function renderRoutesTest(sector) {
  return `import { describe, expect, it } from 'vitest'\nimport { sector } from '../../sector.js'\n\ndescribe('${sector.displayName} sector config', () => {\n  it('has four primary entities', () => {\n    expect(sector.entities).toHaveLength(4)\n  })\n})\n`
}

function renderWebApp(sector, titleSuffix) {
  return `import React, { useMemo, useState } from 'react'

type SummaryCard = { table: string; label: string; count: number }
type SummaryResponse = {
  ok: boolean
  summary?: { sector: string; displayName: string; counts: SummaryCard[] }
  tenant?: { name?: string }
  error?: string
}

export default function App() {
  const [apiUrl, setApiUrl] = useState('http://localhost:4000')
  const [tenantId, setTenantId] = useState('')
  const [token, setToken] = useState('')
  const [result, setResult] = useState<SummaryResponse | null>(null)
  const [loading, setLoading] = useState(false)

  const cards = useMemo(() => result?.summary?.counts ?? [], [result])

  const load = async () => {
    setLoading(true)
    const res = await fetch(apiUrl + '/api/dashboard/summary?tenantId=' + encodeURIComponent(tenantId), {
      headers: token ? { Authorization: 'Bearer ' + token } : {},
    })
    const data = (await res.json()) as SummaryResponse
    setResult(data)
    setLoading(false)
  }

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', padding: 32, color: '#fff', background: '#0b1020', minHeight: '100vh' }}>
      <h1>Proidea ${sector.displayName} ${titleSuffix}</h1>
      <p>${sector.headline}</p>
      <div style={{ display: 'grid', gap: 12, maxWidth: 680, marginBottom: 24 }}>
        <input placeholder="API URL" value={apiUrl} onChange={(event) => setApiUrl(event.target.value)} />
        <input placeholder="Tenant ID" value={tenantId} onChange={(event) => setTenantId(event.target.value)} />
        <input placeholder="Bearer token" value={token} onChange={(event) => setToken(event.target.value)} />
        <button onClick={load} disabled={loading}>{loading ? 'Loading…' : 'Load live dashboard'}</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16 }}>
        {cards.map((card) => (
          <div key={card.table} style={{ background: '#121a33', border: '1px solid #253155', borderRadius: 16, padding: 16 }}>
            <strong>{card.label}</strong>
            <div style={{ fontSize: 30, marginTop: 10 }}>{card.count}</div>
          </div>
        ))}
      </div>
      {result?.error ? <p style={{ color: '#ff8080' }}>{result.error}</p> : null}
    </div>
  )
}
`
}

function renderSitePage(sector) {
  const cards = sector.entities.slice(0, 3)
  return `export default function HomePage() {\n  return (\n    <main className=\"hero\">\n      <div className=\"hero-inner\">\n        <section>\n          <div className=\"eyebrow\">Proidea ${sector.displayName}</div>\n          <h1 className=\"headline\">${sector.headline}</h1>\n          <p className=\"copy\">\n            Launch a tenant-aware ${sector.displayName.toLowerCase()} platform with live dashboards, role-based access, mobile control,\n            automation connectors, and a database designed specifically for this business model.\n          </p>\n          <div className=\"cta-row\">\n            <a className=\"btn btn-primary\" href=\"#get-started\">Go live this week</a>\n            <a className=\"btn btn-secondary\" href=\"/docs\">Read the implementation plan</a>\n          </div>\n        </section>\n        <section className=\"stage\" aria-label=\"3D marketing showcase\">\n          <div className=\"glow\" />\n          <div className=\"orbital\">\n            ${cards.map((entity) => `<div className=\"card3d\"><strong>${entity.label}</strong><p style={{color:'#dce7ff'}}>Live operations</p></div>`).join('\\n            ')}\n          </div>\n        </section>\n      </div>\n    </main>\n  )\n}\n`
}

function renderSiteLayout(sector) {
  return `import './globals.css'\nimport type { ReactNode } from 'react'\n\nexport const metadata = { title: 'Proidea ${sector.displayName}' }\n\nexport default function RootLayout({ children }: { children: ReactNode }) {\n  return (\n    <html lang=\"en\">\n      <body>{children}</body>\n    </html>\n  )\n}\n`
}

function renderSiteCss() {
  return `:root { color-scheme: dark; }\n* { box-sizing: border-box; }\nbody { margin: 0; font-family: Inter, Arial, sans-serif; background: radial-gradient(circle at top, #132445 0%, #08101d 55%, #04070d 100%); color: #fff; }\n.hero { min-height: 100vh; display: grid; place-items: center; padding: 48px 24px; overflow: hidden; }\n.hero-inner { width: min(1120px, 100%); display: grid; grid-template-columns: 1.1fr 0.9fr; gap: 48px; align-items: center; }\n.eyebrow { color: #8fb5ff; text-transform: uppercase; letter-spacing: .12em; font-size: 12px; }\n.headline { font-size: clamp(2.5rem, 5vw, 4.8rem); line-height: 1.05; margin: 16px 0; }\n.copy { color: #b8c7e6; font-size: 1.05rem; max-width: 680px; }\n.cta-row { display: flex; gap: 14px; flex-wrap: wrap; margin-top: 28px; }\n.btn { padding: 14px 18px; border-radius: 999px; text-decoration: none; font-weight: 700; border: 1px solid rgba(255,255,255,.12); }\n.btn-primary { background: linear-gradient(135deg, #3b82f6, #8b5cf6); color: white; }\n.btn-secondary { background: rgba(255,255,255,.04); color: white; }\n.stage { perspective: 1400px; width: 100%; min-height: 420px; display: grid; place-items: center; position: relative; }\n.orbital { position: relative; width: 320px; height: 320px; transform-style: preserve-3d; animation: spin 18s linear infinite; }\n.card3d { position: absolute; inset: 0; margin: auto; width: 220px; height: 140px; padding: 18px; border-radius: 24px; background: linear-gradient(180deg, rgba(255,255,255,.16), rgba(255,255,255,.05)); backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,.1); box-shadow: 0 16px 60px rgba(0,0,0,.35); }\n.card3d:nth-child(1) { transform: rotateY(0deg) translateZ(140px); }\n.card3d:nth-child(2) { transform: rotateY(120deg) translateZ(140px); }\n.card3d:nth-child(3) { transform: rotateY(240deg) translateZ(140px); }\n.glow { position: absolute; width: 420px; height: 420px; background: radial-gradient(circle, rgba(59,130,246,.25), transparent 60%); filter: blur(20px); }\n@keyframes spin { from { transform: rotateX(-18deg) rotateY(0deg); } to { transform: rotateX(-18deg) rotateY(360deg); } }\n@media (max-width: 900px) { .hero-inner { grid-template-columns: 1fr; } .stage { min-height: 340px; } }\n`
}

function renderMobileApp(sector) {
  return `import React, { useState } from 'react'
import { SafeAreaView, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native'

type SummaryCard = { table: string; label: string; count: number }
type SummaryPayload = { counts?: SummaryCard[] }

export default function Index() {
  const [apiUrl, setApiUrl] = useState('http://localhost:4000')
  const [tenantId, setTenantId] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [token, setToken] = useState('')
  const [summary, setSummary] = useState<SummaryPayload | null>(null)
  const [error, setError] = useState('')

  const login = async () => {
    setError('')
    const res = await fetch(apiUrl + '/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, tenantId }),
    })
    const data = (await res.json()) as { error?: string; accessToken?: string }
    if (!res.ok) {
      setError(data.error || 'Login failed')
      return
    }
    setToken(data.accessToken || '')
  }

  const loadDashboard = async () => {
    setError('')
    const res = await fetch(apiUrl + '/api/dashboard/summary?tenantId=' + encodeURIComponent(tenantId), {
      headers: token ? { Authorization: 'Bearer ' + token } : {},
    })
    const data = (await res.json()) as { error?: string; summary?: SummaryPayload }
    if (!res.ok) {
      setError(data.error || 'Dashboard load failed')
      return
    }
    setSummary(data.summary || null)
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#08101d' }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
        <Text style={{ color: 'white', fontSize: 28, fontWeight: '700' }}>Proidea ${sector.displayName}</Text>
        <Text style={{ color: '#a9b4d0' }}>${sector.headline}</Text>
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="API URL" placeholderTextColor="#8a97b8" value={apiUrl} onChangeText={setApiUrl} />
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="Tenant ID" placeholderTextColor="#8a97b8" value={tenantId} onChangeText={setTenantId} />
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="Email" placeholderTextColor="#8a97b8" value={email} onChangeText={setEmail} />
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="Password" secureTextEntry placeholderTextColor="#8a97b8" value={password} onChangeText={setPassword} />
        <TouchableOpacity style={{ backgroundColor: '#3b82f6', padding: 14, borderRadius: 12 }} onPress={login}><Text style={{ color: 'white', textAlign: 'center', fontWeight: '700' }}>Login</Text></TouchableOpacity>
        <TouchableOpacity style={{ backgroundColor: '#10b981', padding: 14, borderRadius: 12 }} onPress={loadDashboard}><Text style={{ color: 'white', textAlign: 'center', fontWeight: '700' }}>Load dashboard</Text></TouchableOpacity>
        {error ? <Text style={{ color: '#fda4af' }}>{error}</Text> : null}
        {summary?.counts?.map((card) => (
          <View key={card.table} style={{ backgroundColor: '#111a2b', padding: 16, borderRadius: 14 }}>
            <Text style={{ color: 'white', fontWeight: '700' }}>{card.label}</Text>
            <Text style={{ color: '#93c5fd', fontSize: 24, marginTop: 6 }}>{card.count}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  )
}
`
}

function renderDatabaseReadme(sector) {
  return `# Database\n\nThis database is specific to the ${sector.displayName} sector. Apply migrations in order.\n`
}

function renderSchemaOverview() {
  return `# Schema overview\n\nPlatform core tables + sector domain tables.\n`
}

function renderErd(sector) {
  const entityLines = sector.entities.map((entity) => `tenants -> ${entity.table}`)
  if (sector.sector === 'restaurants') {
    entityLines.push('tenants -> menu_categories', 'tenants -> order_items', 'tenants -> delivery_settings')
  }
  return `# ERD\n\n\`\`\`\ntenants -> staff_profiles -> staff_tenant_memberships\n${entityLines.join('\n')}\n\`\`\`\n`
}

function renderPlatformCoreMigration() {
  return `create extension if not exists pgcrypto;\n\ncreate table if not exists tenants (\n  id uuid primary key default gen_random_uuid(),\n  slug text unique not null,\n  name text not null,\n  status text not null default 'active',\n  plan_code text not null default 'base',\n  locale text not null default 'en',\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists staff_profiles (\n  id uuid primary key default gen_random_uuid(),\n  user_id uuid unique not null,\n  email text unique,\n  full_name text,\n  is_active boolean not null default true,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists staff_tenant_memberships (\n  id uuid primary key default gen_random_uuid(),\n  tenant_id uuid not null references tenants(id) on delete cascade,\n  staff_profile_id uuid not null references staff_profiles(id) on delete cascade,\n  role text not null,\n  capabilities jsonb not null default '[]'::jsonb,\n  is_active boolean not null default true,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now(),\n  unique (tenant_id, staff_profile_id)\n);\n\ncreate table if not exists automation_events (\n  id uuid primary key default gen_random_uuid(),\n  tenant_id uuid not null references tenants(id) on delete cascade,\n  channel text not null,\n  event_type text not null,\n  status text not null default 'received',\n  external_id text,\n  payload jsonb not null default '{}'::jsonb,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists audit_events (\n  id uuid primary key default gen_random_uuid(),\n  tenant_id uuid not null references tenants(id) on delete cascade,\n  actor_profile_id uuid references staff_profiles(id),\n  event_type text not null,\n  entity_type text,\n  entity_id uuid,\n  reason text,\n  metadata jsonb,\n  created_at timestamptz not null default now()\n);\n`
}

function renderGenericEntityTable(entity) {
  return `create table if not exists ${entity.table} (\n  id uuid primary key default gen_random_uuid(),\n  tenant_id uuid not null references tenants(id) on delete cascade,\n  code text,\n  title text not null,\n  status text not null default 'active',\n  summary text,\n  phone text,\n  email text,\n  scheduled_at timestamptz,\n  amount numeric(12,2),\n  metadata jsonb not null default '{}'::jsonb,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now(),\n  created_by uuid references staff_profiles(id),\n  updated_by uuid references staff_profiles(id)\n);\ncreate index if not exists idx_${entity.table}_tenant_status on ${entity.table}(tenant_id, status, created_at desc);\n`
}

function renderDomainMigration(sector) {
  let output = `-- ${sector.displayName} domain\n\n`
  for (const entity of sector.entities) {
    output += renderGenericEntityTable(entity) + '\n'
  }
  if (sector.sector === 'restaurants') {
    output += `create table if not exists menu_categories (\n  id uuid primary key default gen_random_uuid(),\n  tenant_id uuid not null references tenants(id) on delete cascade,\n  title text not null,\n  sort_order int not null default 0,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists order_items (\n  id uuid primary key default gen_random_uuid(),\n  tenant_id uuid not null references tenants(id) on delete cascade,\n  order_id uuid not null references orders(id) on delete cascade,\n  menu_item_id uuid references menu_items(id) on delete set null,\n  item_name text,\n  unit_price numeric(12,2),\n  quantity int not null default 1,\n  notes text,\n  source text not null default 'manual',\n  metadata jsonb not null default '{}'::jsonb,\n  created_at timestamptz not null default now(),\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists delivery_settings (\n  id uuid primary key default gen_random_uuid(),\n  tenant_id uuid unique not null references tenants(id) on delete cascade,\n  base_fee numeric(12,2) not null default 0,\n  free_delivery_threshold numeric(12,2),\n  radius_km numeric(10,2),\n  currency text not null default 'USD',\n  updated_at timestamptz not null default now()\n);\n`
  }
  return output
}

function rlsBlock(table) {
  return `alter table ${table} enable row level security;\ndrop policy if exists ${table}_tenant_select on ${table};\ncreate policy ${table}_tenant_select on ${table}\n  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));\ndrop policy if exists ${table}_tenant_write on ${table};\ncreate policy ${table}_tenant_write on ${table}\n  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))\n  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));\n`
}

function renderRlsMigration(sector) {
  const tables = sector.entities.map((entity) => entity.table)
  if (sector.sector === 'restaurants') {
    tables.push('menu_categories', 'order_items', 'delivery_settings')
  }
  return `alter table tenants enable row level security;\n\n${tables.map(rlsBlock).join('\n')}\n`
}

function renderSeedMigration(sector) {
  let output = `insert into tenants (id, slug, name, plan_code) values ('00000000-0000-0000-0000-000000000001', '${sector.sector}-demo', 'Demo ${sector.displayName}', 'pro') on conflict (slug) do nothing;\n`
  output += `insert into staff_profiles (id, user_id, email, full_name) values ('00000000-0000-0000-0000-000000000101', '00000000-0000-0000-0000-000000000111', 'owner@example.com', 'Owner Demo') on conflict (email) do nothing;\n`
  output += `insert into staff_tenant_memberships (id, tenant_id, staff_profile_id, role, capabilities) values ('00000000-0000-0000-0000-000000000201', '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000101', 'owner', '${JSON.stringify(sector.capabilities)}'::jsonb) on conflict do nothing;\n`
  sector.entities.forEach((entity, index) => {
    const idNum = 1001 + index
    output += `insert into ${entity.table} (id, tenant_id, code, title, status, summary) values ('00000000-0000-0000-0000-00000000${String(idNum).padStart(4,'0')}', '00000000-0000-0000-0000-000000000001', '${slugPrefix(entity.table)}-${String(index + 1).padStart(3, '0')}', 'Demo ${entity.label} ${index + 1}', 'active', 'Generated seed row') on conflict do nothing;\n`
  })
  if (sector.sector === 'restaurants') {
    output += `insert into menu_categories (id, tenant_id, title, sort_order) values ('00000000-0000-0000-0000-000000009001', '00000000-0000-0000-0000-000000000001', 'Mains', 1) on conflict do nothing;\n`
    output += `insert into delivery_settings (id, tenant_id, base_fee, free_delivery_threshold, radius_km, currency) values ('00000000-0000-0000-0000-000000009201', '00000000-0000-0000-0000-000000000001', 3.50, 25, 7, 'USD') on conflict (tenant_id) do nothing;\n`
  }
  return output
}

async function updateJsonFile(filePath, transform) {
  const data = JSON.parse(await fs.readFile(filePath, 'utf8'))
  transform(data)
  await fs.writeFile(filePath, `${JSON.stringify(data, null, 2)}\n`)
}

async function writeFile(filePath, content) {
  await fs.mkdir(path.dirname(filePath), { recursive: true })
  await fs.writeFile(filePath, content)
}

async function removeIfExists(filePath) {
  if (await exists(filePath)) {
    await fs.rm(filePath, { recursive: true, force: true })
  }
}

export async function generateSectorRepo(input, options = {}) {
  const sector = typeof input === 'string' ? await resolveSector(input) : input
  const targetDir = options.targetDir ?? path.resolve(ROOT_DIR, '..', `proidea-${sector.sector}`)

  await fs.rm(targetDir, { recursive: true, force: true })
  await copyDir(ROOT_DIR, targetDir)

  await removeIfExists(path.join(targetDir, 'docs', 'sector-archetypes.md'))
  await removeIfExists(path.join(targetDir, 'docs', 'sector-factory-workflow.md'))
  await removeIfExists(path.join(targetDir, 'sectors'))
  await removeIfExists(path.join(targetDir, 'scripts', 'generate-sector-repo.mjs'))
  await removeIfExists(path.join(targetDir, 'scripts', 'generate-all-sectors.mjs'))
  await removeIfExists(path.join(targetDir, 'scripts', 'sector-factory-lib.mjs'))

  await updateJsonFile(path.join(targetDir, 'package.json'), (data) => {
    data.name = `proidea-${sector.sector}`
  })
  await updateJsonFile(path.join(targetDir, 'apps', 'api', 'package.json'), (data) => {
    data.name = `@proidea/${sector.sector}-api`
    data.dependencies = data.dependencies || {}
    data.dependencies['@supabase/supabase-js'] = '^2.49.8'
    data.dependencies['fastify-plugin'] = '^5.0.1'
  })
  await updateJsonFile(path.join(targetDir, 'apps', 'web', 'package.json'), (data) => {
    data.name = `@proidea/${sector.sector}-web`
  })
  await updateJsonFile(path.join(targetDir, 'apps', 'admin', 'package.json'), (data) => {
    data.name = `@proidea/${sector.sector}-admin`
  })
  await updateJsonFile(path.join(targetDir, 'apps', 'site', 'package.json'), (data) => {
    data.name = `@proidea/${sector.sector}-site`
  })
  await updateJsonFile(path.join(targetDir, 'apps', 'mobile', 'package.json'), (data) => {
    data.name = `@proidea/${sector.sector}-mobile`
    data.dependencies = data.dependencies || {}
    data.dependencies['@react-native-async-storage/async-storage'] = '^1.24.0'
  })

  await writeFile(path.join(targetDir, 'README.md'), renderReadme(sector))
  await writeFile(path.join(targetDir, 'SECTOR-START-HERE.md'), renderSectorStartHere(sector))
  await writeFile(path.join(targetDir, 'RBAC-MATRIX.md'), renderRbacMatrix(sector))
  await writeFile(path.join(targetDir, 'AUTOMATION-CONNECTORS.md'), renderAutomationConnectors())
  await writeFile(path.join(targetDir, 'PERSISTENCE-ADAPTERS.md'), renderPersistenceAdapters(sector))
  await writeFile(path.join(targetDir, 'DASHBOARD-LIVE-DATA.md'), renderDashboardLiveData())
  await writeFile(path.join(targetDir, 'REVIEW-AND-IMPROVEMENTS.md'), renderReviewAndImprovements(sector))
  await writeFile(path.join(targetDir, 'sector.config.json'), json(sectorConfig(sector)))

  await writeFile(path.join(targetDir, 'memory', 'shared', 'CURRENT_STATE.md'), renderCurrentState(sector))
  await writeFile(path.join(targetDir, 'memory', 'shared', 'OPEN_QUESTIONS.md'), renderOpenQuestions(sector))
  await writeFile(path.join(targetDir, 'memory', 'shared', 'DECISIONS.md'), renderDecisions(sector))

  await writeFile(path.join(targetDir, 'docs', 'sector', 'BUSINESS-MODEL.md'), renderBusinessModel(sector))
  await writeFile(path.join(targetDir, 'docs', 'sector', 'FIRST-IMPLEMENTATION-SLICE.md'), renderFirstSlice(sector))

  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'sector.ts'), renderSectorTs(sector))
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'app.ts'), renderApiApp(sector))
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'server.ts'), renderServerTs())
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'server.test.ts'), renderServerTest(sector))
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'lib', 'http.ts'), renderHttpTs())
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'lib', 'supabase.ts'), renderSupabaseTs())
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'lib', 'auth.ts'), renderAuthTs())
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'lib', 'rbac.ts'), renderRbacTs())
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'modules', sector.sector, 'repository.ts'), renderRepositoryTs(sector))
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'modules', sector.sector, 'service.ts'), renderServiceTs(sector))
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'modules', sector.sector, 'automation.ts'), renderAutomationTs(sector))
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'modules', sector.sector, 'routes.ts'), renderRoutesTs(sector))
  await writeFile(path.join(targetDir, 'apps', 'api', 'src', 'modules', sector.sector, 'routes.test.ts'), renderRoutesTest(sector))

  await writeFile(path.join(targetDir, 'apps', 'web', 'src', 'App.tsx'), renderWebApp(sector, 'Dashboard'))
  await writeFile(path.join(targetDir, 'apps', 'admin', 'src', 'App.tsx'), renderWebApp(sector, 'Admin'))
  await writeFile(path.join(targetDir, 'apps', 'site', 'src', 'app', 'page.tsx'), renderSitePage(sector))
  await writeFile(path.join(targetDir, 'apps', 'site', 'src', 'app', 'layout.tsx'), renderSiteLayout(sector))
  await writeFile(path.join(targetDir, 'apps', 'site', 'src', 'app', 'globals.css'), renderSiteCss())
  await writeFile(path.join(targetDir, 'apps', 'mobile', 'app', 'index.tsx'), renderMobileApp(sector))

  await writeFile(path.join(targetDir, 'database', 'README.md'), renderDatabaseReadme(sector))
  await writeFile(path.join(targetDir, 'database', 'SCHEMA-OVERVIEW.md'), renderSchemaOverview())
  await writeFile(path.join(targetDir, 'database', 'ERD.md'), renderErd(sector))
  await writeFile(path.join(targetDir, 'database', 'migrations', '0001_platform_core.sql'), renderPlatformCoreMigration())
  await writeFile(path.join(targetDir, 'database', 'migrations', '0002_rls.sql'), renderRlsMigration(sector))
  await writeFile(path.join(targetDir, 'database', 'migrations', `0010_${sector.sector}_domain.sql`), renderDomainMigration(sector))
  await writeFile(path.join(targetDir, 'database', 'seeds', '001_demo.sql'), renderSeedMigration(sector))

  return { sector, targetDir }
}
