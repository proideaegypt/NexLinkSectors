# Proidea Kick-Start Final

A production-oriented multi-agent SaaS monorepo starter built from the full thread decisions, fixes, and operating rules across bootstrap, health verification, prompt strategy, agent teams, QA, security, review, and deployment workflows.

## What is included

| Area | Included |
|---|---|
| Monorepo apps | API, web app, admin app, marketing site, mobile app |
| Operating system | AGENTS contract, shared memory, handoff rules, review gates |
| Agent teams | Architecture, backend, frontend, product, DB, QA, security, perf, docs, release, growth |
| Prompt system | Phase prompts plus role prompts for Claude, Codex, and Antigravity |
| Ops | Bootstrap, smoke, migrate, deploy, rollback, security, performance scripts |
| Docs | Prompt guide, workflows, fixes log, QA plan, release-oriented structure |

## Reviewed thread outcomes applied

- Bootstrap issues were consolidated into the final pack: pnpm version alignment, ignored build script handling, React Native peer version alignment, Next.js update, Vitest type fixes, and shell script fixes.
- API health verification logic and the `EADDRINUSE` stale-process handling pattern were reflected in prompts and operational notes.
- Prompt ownership was expanded beyond phases into full agent-team prompts.
- The operating model now treats Claude as orchestrator/reviewer, Codex as implementation engine, and Antigravity as design/UI/shell execution depending on task type.
- The repo is shaped to be reused as a base starter for future SaaS builds, not just for one project.

## Quick start

```bash
corepack enable
corepack prepare pnpm@10.33.0 --activate
pnpm install
bash bootstrap.sh
```

## Suggested first execution order

1. Read `AGENTS.md`.
2. Read `memory/shared/CURRENT_STATE.md`.
3. Read `docs/PROMPTS-GUIDE.md`.
4. Run `bash bootstrap.sh`.
5. Use the Phase 0 prompt before any feature work.
6. Use role prompts after phase planning is approved.

## Repo conventions

- Do not start implementation before reading shared memory.
- Do not merge without QA + security + review gates for critical changes.
- Use Claude for architecture and review, Codex for implementation, Antigravity for shell/deploy/design execution.
- Every meaningful task must update memory and the task ledger.
