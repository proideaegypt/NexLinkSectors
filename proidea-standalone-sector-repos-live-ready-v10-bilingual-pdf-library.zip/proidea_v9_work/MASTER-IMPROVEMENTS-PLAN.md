# Improvements plan

1. install deps
2. run migrations
3. wire tenant login
4. replace scaffolds with sector business logic
