import { test, expect } from '@playwright/test'

const baseURL = process.env.ADMIN_BASE_URL

test('admin shell renders for Auto Repair', async ({ page }) => {
  test.skip(!baseURL, 'Set ADMIN_BASE_URL to run sector admin e2e.')
  await page.goto(baseURL!)
  await expect(page.locator('h1')).toContainText('Proidea Auto Repair')
})
