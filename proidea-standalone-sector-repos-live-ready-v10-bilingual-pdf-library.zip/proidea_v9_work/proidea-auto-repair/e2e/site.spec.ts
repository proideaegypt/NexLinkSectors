import { test, expect } from '@playwright/test'

const baseURL = process.env.SITE_BASE_URL

test('site marketing shell renders for Auto Repair', async ({ page }) => {
  test.skip(!baseURL, 'Set SITE_BASE_URL to run sector site e2e.')
  await page.goto(baseURL!)
  await expect(page.locator('h1')).toContainText('Auto Repair')
})
