export default function HomePage() {
  return (
    <main className="hero">
      <div className="hero-inner">
        <section>
          <div className="eyebrow">Proidea Auto Repair</div>
          <h1 className="headline">Manage vehicles, work orders, technicians, approvals, and service delivery from one garage platform.</h1>
          <p className="copy">
            Launch a tenant-aware auto repair platform with live dashboards, role-based access, mobile control,
            automation connectors, and a database designed specifically for this business model.
          </p>
          <div className="cta-row">
            <a className="btn btn-primary" href="#get-started">Go live this week</a>
            <a className="btn btn-secondary" href="/docs">Read the implementation plan</a>
          </div>
        </section>
        <section className="stage" aria-label="3D marketing showcase">
          <div className="glow" />
          <div className="orbital">
            <div className="card3d"><strong>Customer</strong><p style={{color:'#dce7ff'}}>Live operations</p></div>\n            <div className="card3d"><strong>Vehicle</strong><p style={{color:'#dce7ff'}}>Live operations</p></div>\n            <div className="card3d"><strong>Work Order</strong><p style={{color:'#dce7ff'}}>Live operations</p></div>
          </div>
        </section>
      </div>
    </main>
  )
}
