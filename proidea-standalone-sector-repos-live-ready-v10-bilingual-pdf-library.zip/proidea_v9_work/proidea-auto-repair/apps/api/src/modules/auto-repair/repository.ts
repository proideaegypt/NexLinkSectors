import { supabaseAdmin } from '../../lib/supabase.js'
import { sector } from '../../sector.js'

export async function listEntity(table: string, tenantId: string) {
  const { data, error } = await supabaseAdmin
    .from(table)
    .select('*')
    .eq('tenant_id', tenantId)
    .order('created_at', { ascending: false })
    .limit(50)
  if (error) throw error
  return data ?? []
}

export async function listScopedTable(table: string, tenantId: string) {
  const { data, error } = await supabaseAdmin
    .from(table)
    .select('*')
    .eq('tenant_id', tenantId)
    .order('updated_at', { ascending: false })
    .limit(50)
  if (error) throw error
  return data ?? []
}

export async function createEntity(table: string, tenantId: string, payload: Record<string, unknown>, actorId?: string | null) {
  const { data, error } = await supabaseAdmin
    .from(table)
    .insert({ tenant_id: tenantId, ...payload, created_by: actorId ?? null, updated_by: actorId ?? null })
    .select('*')
    .single()
  if (error) throw error
  return data
}

export async function updateEntityStatus(table: string, tenantId: string, id: string, status: string, actorId?: string | null) {
  const { data, error } = await supabaseAdmin
    .from(table)
    .update({ status, updated_by: actorId ?? null, updated_at: new Date().toISOString() })
    .eq('tenant_id', tenantId)
    .eq('id', id)
    .select('*')
    .single()
  if (error) throw error
  return data
}

export async function dashboardSummary(tenantId: string) {
  const defs = [
  {
    "table": "customers",
    "label": "Customer"
  },
  {
    "table": "vehicles",
    "label": "Vehicle"
  },
  {
    "table": "work_orders",
    "label": "Work Order"
  },
  {
    "table": "technicians",
    "label": "Technician"
  }
] as Array<{ table: string; label: string }>
  const counts = [] as Array<{ table: string; label: string; count: number }>
  for (const def of defs) {
    const { count, error } = await supabaseAdmin
      .from(def.table)
      .select('id', { count: 'exact', head: true })
      .eq('tenant_id', tenantId)
    if (error) throw error
    counts.push({ table: def.table, label: def.label, count: count ?? 0 })
  }
  return { sector: sector.slug, displayName: sector.displayName, counts }
}
