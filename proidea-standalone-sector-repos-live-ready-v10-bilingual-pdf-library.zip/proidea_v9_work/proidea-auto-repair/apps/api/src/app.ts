import Fastify from 'fastify'
import cors from '@fastify/cors'
import { registerSectorRoutes } from './modules/auto-repair/routes.js'
import { sector } from './sector.js'

export function buildApp() {
  const app = Fastify({ logger: true })
  app.register(cors, { origin: true })
  app.get('/health', async () => ({ ok: true, service: 'api', sector: sector.slug, timestamp: new Date().toISOString() }))
  app.register(registerSectorRoutes)
  return app
}
