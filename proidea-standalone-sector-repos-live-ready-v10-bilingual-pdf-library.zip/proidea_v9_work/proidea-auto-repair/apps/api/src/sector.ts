export const sector = {
  "slug": "auto-repair",
  "displayName": "Auto Repair",
  "resourceBase": "auto-repair",
  "headline": "Manage vehicles, work orders, technicians, approvals, and service delivery from one garage platform.",
  "roles": [
    "owner",
    "admin",
    "service-manager",
    "technician",
    "front-desk",
    "viewer"
  ],
  "entities": [
    {
      "table": "customers",
      "label": "Customer",
      "labelAr": "العملاء"
    },
    {
      "table": "vehicles",
      "label": "Vehicle",
      "labelAr": "المركبات"
    },
    {
      "table": "work_orders",
      "label": "Work Order",
      "labelAr": "أوامر العمل"
    },
    {
      "table": "technicians",
      "label": "Technician",
      "labelAr": "الفنيون"
    }
  ],
  "capabilities": [
    "dashboard.read",
    "records.read",
    "records.write",
    "automation.manage"
  ]
} as const
