import React, { useMemo, useState } from 'react'

type SummaryCard = { table: string; label: string; count: number }
type SummaryResponse = {
  ok: boolean
  summary?: { sector: string; displayName: string; counts: SummaryCard[] }
  tenant?: { name?: string }
  error?: string
}

export default function App() {
  const [apiUrl, setApiUrl] = useState('http://localhost:4000')
  const [tenantId, setTenantId] = useState('')
  const [token, setToken] = useState('')
  const [result, setResult] = useState<SummaryResponse | null>(null)
  const [loading, setLoading] = useState(false)

  const cards = useMemo(() => result?.summary?.counts ?? [], [result])

  const load = async () => {
    setLoading(true)
    const res = await fetch(apiUrl + '/api/dashboard/summary?tenantId=' + encodeURIComponent(tenantId), {
      headers: token ? { Authorization: 'Bearer ' + token } : {},
    })
    const data = (await res.json()) as SummaryResponse
    setResult(data)
    setLoading(false)
  }

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', padding: 32, color: '#fff', background: '#0b1020', minHeight: '100vh' }}>
      <h1>Proidea Auto Repair Admin</h1>
      <p>Manage vehicles, work orders, technicians, approvals, and service delivery from one garage platform.</p>
      <div style={{ display: 'grid', gap: 12, maxWidth: 680, marginBottom: 24 }}>
        <input placeholder="API URL" value={apiUrl} onChange={(event) => setApiUrl(event.target.value)} />
        <input placeholder="Tenant ID" value={tenantId} onChange={(event) => setTenantId(event.target.value)} />
        <input placeholder="Bearer token" value={token} onChange={(event) => setToken(event.target.value)} />
        <button onClick={load} disabled={loading}>{loading ? 'Loading…' : 'Load live dashboard'}</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16 }}>
        {cards.map((card) => (
          <div key={card.table} style={{ background: '#121a33', border: '1px solid #253155', borderRadius: 16, padding: 16 }}>
            <strong>{card.label}</strong>
            <div style={{ fontSize: 30, marginTop: 10 }}>{card.count}</div>
          </div>
        ))}
      </div>
      {result?.error ? <p style={{ color: '#ff8080' }}>{result.error}</p> : null}
    </div>
  )
}
