#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"
echo "==> Independent go-live check for proidea-auto-repair"
[[ -f sector.config.json ]]
[[ -f docs/SECTOR-INDEPENDENCE.md ]]
[[ -f docs/GO-LIVE-RUNBOOK.md ]]
[[ -f scripts/certify-full.sh ]]
bash scripts/check-env-sync.sh
bash scripts/migrate.sh --dry-run
echo "✓ proidea-auto-repair stays standalone for go-live. No cross-sector dependency is required."
