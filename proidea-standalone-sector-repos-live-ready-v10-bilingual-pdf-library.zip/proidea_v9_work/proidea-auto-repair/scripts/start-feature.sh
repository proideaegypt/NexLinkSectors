#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"
FEATURE_NAME="${1:-feature}"
BRANCH_NAME="feature/auto-repair-$(echo "${FEATURE_NAME}" | tr ' ' '-' | tr '[:upper:]' '[:lower:]')"
echo "==> Starting isolated sector feature on proidea-auto-repair: ${BRANCH_NAME}"
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git checkout -b "${BRANCH_NAME}"
fi
echo "Remember: implement only inside proidea-auto-repair. Do not couple this feature to any other sector repo."
