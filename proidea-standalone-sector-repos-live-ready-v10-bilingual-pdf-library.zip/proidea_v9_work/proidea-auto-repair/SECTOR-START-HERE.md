# Auto Repair - Start Here

1. Read `AGENTS.md`, `proidea-agents.md`, and `memory/shared/CURRENT_STATE.md`.
2. Read `sector.config.json`, `docs/sector/BUSINESS-MODEL.md`, and `docs/sector/REAL-MARKET-SCENARIOS.md`.
3. Open `docs/sector/SECTOR-FIRST-PROMPTS.md` and choose the first Claude kickoff prompt.
4. Run:
```bash
corepack enable
corepack prepare pnpm@10.33.0 --activate
pnpm install
bash bootstrap.sh
```
5. Configure `.env.local` from `.env.example`.
6. Apply `database/migrations/*.sql` to your Supabase/Postgres project.
7. Start with one sellable workflow only. Do not build the whole sector at once.
8. After every meaningful task, update shared memory and both agent ledgers.

This repo is sector-specific. Do not assume the same database model as any other sector.

## Sector-by-sector operating mode

Treat Auto Repair as its own ship unit.

- Go live from this repo only.
- Run tests from this repo only.
- Maintain this repo without editing unrelated sectors.
- Add features on branches scoped to this sector only.

Run `bash scripts/certify-full.sh` before any sector release candidate.
