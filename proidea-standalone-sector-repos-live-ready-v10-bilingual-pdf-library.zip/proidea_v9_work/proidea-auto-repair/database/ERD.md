# ERD

```
tenants -> staff_profiles -> staff_tenant_memberships
tenants -> customers
tenants -> vehicles
tenants -> work_orders
tenants -> technicians
```
