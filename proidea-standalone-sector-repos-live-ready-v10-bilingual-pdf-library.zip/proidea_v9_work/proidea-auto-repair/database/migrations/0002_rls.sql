alter table tenants enable row level security;

alter table customers enable row level security;
drop policy if exists customers_tenant_select on customers;
create policy customers_tenant_select on customers
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists customers_tenant_write on customers;
create policy customers_tenant_write on customers
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

alter table vehicles enable row level security;
drop policy if exists vehicles_tenant_select on vehicles;
create policy vehicles_tenant_select on vehicles
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists vehicles_tenant_write on vehicles;
create policy vehicles_tenant_write on vehicles
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

alter table work_orders enable row level security;
drop policy if exists work_orders_tenant_select on work_orders;
create policy work_orders_tenant_select on work_orders
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists work_orders_tenant_write on work_orders;
create policy work_orders_tenant_write on work_orders
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

alter table technicians enable row level security;
drop policy if exists technicians_tenant_select on technicians;
create policy technicians_tenant_select on technicians
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists technicians_tenant_write on technicians;
create policy technicians_tenant_write on technicians
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

