-- Auto Repair domain

create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_customers_tenant_status on customers(tenant_id, status, created_at desc);

create table if not exists vehicles (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_vehicles_tenant_status on vehicles(tenant_id, status, created_at desc);

create table if not exists work_orders (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_work_orders_tenant_status on work_orders(tenant_id, status, created_at desc);

create table if not exists technicians (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_technicians_tenant_status on technicians(tenant_id, status, created_at desc);

