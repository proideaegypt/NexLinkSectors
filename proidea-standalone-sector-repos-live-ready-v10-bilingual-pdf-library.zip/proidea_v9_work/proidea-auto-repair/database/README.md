# Database

This database is specific to the Auto Repair sector. Apply migrations in order.
