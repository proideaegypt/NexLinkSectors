# Auto Repair - Real Market Scenarios

## Ideal buyer
Auto Repair works best first for a garage or service center with multiple technicians.

## Core offer
vehicle intake, work orders, approvals, parts status, and WhatsApp updates in one control plane

## Three real client scenarios
1. A busy workshop wants digital intake, technician assignment, and customer approval for extra repair items.
2. A chain garage wants branch-level dashboards for jobs, delays, and outstanding approvals.
3. A premium service center wants automated status updates so advisors stop manually calling every customer.

## KPIs the buyer will pay for
- work order turnaround time
- average ticket value
- approval response time

## First sellable package
- Setup + onboarding
- Role-safe operator dashboard
- Core workflow for customer + vehicle
- WhatsApp or automation touchpoints where relevant
- Reporting and follow-up visibility

## Best add-ons after the core package
- inspection photo workflow
- parts ETA tracking
- fleet service contracts

## Buyer language
Sell this sector by promising:
- faster operations
- fewer dropped follow-ups
- clearer staff accountability
- a dashboard the owner can actually read
- a setup path that does not require enterprise complexity on day one
