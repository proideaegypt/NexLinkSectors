# Auto Repair business model

Headline: Manage vehicles, work orders, technicians, approvals, and service delivery from one garage platform.

## Primary buyer
garage or service center with multiple technicians

## Primary entities
- Customer (`customers`)
- Vehicle (`vehicles`)
- Work Order (`work_orders`)
- Technician (`technicians`)

## Primary roles
- owner
- admin
- service-manager
- technician
- front-desk
- viewer

## Commercial promise
vehicle intake, work orders, approvals, parts status, and WhatsApp updates in one control plane
