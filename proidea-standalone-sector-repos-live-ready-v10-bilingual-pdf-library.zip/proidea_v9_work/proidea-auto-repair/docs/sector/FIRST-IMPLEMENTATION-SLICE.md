# First implementation slice - Auto Repair

Ship this in order:
1. Auth login + staff membership verification
2. Dashboard summary counts for the owner/operator
3. CRUD for the first two sector entities
4. One automation ingestion webhook or WhatsApp capture path
5. One operator workflow screen that proves the daily loop
6. One public-facing landing page section that sells the offer

## First KPI targets
- work order turnaround time
- average ticket value
- approval response time
