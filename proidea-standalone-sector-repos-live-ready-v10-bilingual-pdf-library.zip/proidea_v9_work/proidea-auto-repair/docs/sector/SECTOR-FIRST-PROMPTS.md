# Auto Repair - Sector First Prompts

## 1) Claude kickoff prompt

```text
Read AGENTS.md, proidea-agents.md, memory/shared/CURRENT_STATE.md, sector.config.json, docs/sector/BUSINESS-MODEL.md, and docs/sector/REAL-MARKET-SCENARIOS.md.
Act as Claude-Orchestrator + Product Manager.
For Auto Repair, choose the smallest sellable Wave 1 that solves one painful workflow for a garage or service center with multiple technicians.
Output only:
1. buyer and user
2. workflow to ship first
3. scope and out-of-scope
4. acceptance criteria
5. API + DB areas to touch
6. UI states required
7. automation/n8n needs
8. test plan
9. rollback note
10. next owner
Then update CHANGELOG.md, CURRENT_STATE.md, HANDOFFS.md, proidea-agent-team.md, and proidea-agents.md.
```

## 2) Codex execution prompt

```text
Read AGENTS.md, proidea-agents.md, memory/shared/CURRENT_STATE.md, sector.config.json, and the approved Claude wave output.
Act as Codex-Auto Repair.
Implement only the approved Wave 1 slice for Auto Repair.
Requirements:
- protect tenant boundaries
- keep scope narrow
- add tests for happy path, validation, permission failure, and tenant isolation
- do not redesign architecture
Return:
- changed files
- commands run
- tests run
- open risks
- rollback note
- exact ledger row values including duration and tokens
Before finishing, update CHANGELOG.md, proidea-agent-team.md, and proidea-agents.md.
```

## 3) Antigravity UI prompt

```text
Read AGENTS.md, proidea-agents.md, sector.config.json, docs/sector/BUSINESS-MODEL.md, and docs/sector/REAL-MARKET-SCENARIOS.md.
Act as Antigravity Design Lead for Auto Repair.
Design a premium but realistic UI for the first operator workflow and the public-facing landing page.
Requirements:
- Arabic-friendly hierarchy
- clear CTA tied to vehicle intake, work orders, approvals, parts status, and WhatsApp updates in one control plane
- loading, empty, success, error, and permission-denied states
- motion only where it improves comprehension
- no backend contract changes
Return the components and pages changed plus any frontend tasks that still need Codex.
Then update CHANGELOG.md, proidea-agent-team.md, and proidea-agents.md.
```

## 4) Claude release gate prompt

```text
Read CURRENT_STATE.md, CHANGELOG.md, HANDOFFS.md, QA outputs, security outputs, performance outputs, and the latest diff summary.
Act as Release Manager.
Decide go / no-go for staging.
Return blockers, mitigation, rollback path, migration risk, and next exact command sequence.
Update RELEASE_STATUS.md and both ledgers.
```
