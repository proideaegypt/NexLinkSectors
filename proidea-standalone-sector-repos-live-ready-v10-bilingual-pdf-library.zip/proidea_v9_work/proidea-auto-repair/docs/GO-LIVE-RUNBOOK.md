# Auto Repair Go-Live Runbook

1. Work in this repo only.
2. Configure env for this sector tenant.
3. Run `bash scripts/go-live-check.sh`.
4. Run `bash scripts/certify-full.sh`.
5. Deploy from this repo using `bash scripts/deploy-prod.sh`.
6. Run post-deploy health and smoke checks for this sector only.

## Guardrail
No Auto Repair release should depend on another sector repo being deployed at the same time.
