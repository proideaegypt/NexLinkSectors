# Auto Repair Testing Runbook

## Independent test layers
- unit/typecheck via app package scripts
- sector certification via `bash scripts/certify-sector.sh`
- API smoke via `bash scripts/api-smoke.sh`
- browser e2e via `pnpm test:e2e`

## Environment variables for live browser checks
- `SITE_BASE_URL`
- `WEB_BASE_URL`
- `ADMIN_BASE_URL`
- optional: `SMOKE_BEARER_TOKEN`, `SMOKE_TENANT_ID`

The purpose is to keep Auto Repair testable by itself, without coupling to other sectors.
