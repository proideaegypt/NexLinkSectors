# Next steps

Start one sector at a time on your VPS, go live, then move to the next sector.
