# Database

This database is specific to the Aesthetics sector. Apply migrations in order.
