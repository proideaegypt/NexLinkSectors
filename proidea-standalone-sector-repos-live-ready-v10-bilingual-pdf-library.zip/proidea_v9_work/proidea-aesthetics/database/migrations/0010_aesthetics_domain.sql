-- Aesthetics domain

create table if not exists clients (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_clients_tenant_status on clients(tenant_id, status, created_at desc);

create table if not exists consultations (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_consultations_tenant_status on consultations(tenant_id, status, created_at desc);

create table if not exists sessions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_sessions_tenant_status on sessions(tenant_id, status, created_at desc);

create table if not exists treatment_plans (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references tenants(id) on delete cascade,
  code text,
  title text not null,
  status text not null default 'active',
  summary text,
  phone text,
  email text,
  scheduled_at timestamptz,
  amount numeric(12,2),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  created_by uuid references staff_profiles(id),
  updated_by uuid references staff_profiles(id)
);
create index if not exists idx_treatment_plans_tenant_status on treatment_plans(tenant_id, status, created_at desc);

