alter table tenants enable row level security;

alter table clients enable row level security;
drop policy if exists clients_tenant_select on clients;
create policy clients_tenant_select on clients
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists clients_tenant_write on clients;
create policy clients_tenant_write on clients
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

alter table consultations enable row level security;
drop policy if exists consultations_tenant_select on consultations;
create policy consultations_tenant_select on consultations
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists consultations_tenant_write on consultations;
create policy consultations_tenant_write on consultations
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

alter table sessions enable row level security;
drop policy if exists sessions_tenant_select on sessions;
create policy sessions_tenant_select on sessions
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists sessions_tenant_write on sessions;
create policy sessions_tenant_write on sessions
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

alter table treatment_plans enable row level security;
drop policy if exists treatment_plans_tenant_select on treatment_plans;
create policy treatment_plans_tenant_select on treatment_plans
  for select using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));
drop policy if exists treatment_plans_tenant_write on treatment_plans;
create policy treatment_plans_tenant_write on treatment_plans
  for all using (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''))
  with check (tenant_id::text = coalesce(auth.jwt() ->> 'tenant_id', ''));

