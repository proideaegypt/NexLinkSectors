# ERD

```
tenants -> staff_profiles -> staff_tenant_memberships
tenants -> clients
tenants -> consultations
tenants -> sessions
tenants -> treatment_plans
```
