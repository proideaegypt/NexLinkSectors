# Schema overview

Platform core tables + sector domain tables.
