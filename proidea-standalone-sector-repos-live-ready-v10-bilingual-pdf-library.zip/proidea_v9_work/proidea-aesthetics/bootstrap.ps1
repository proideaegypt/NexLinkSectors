$ErrorActionPreference = 'Stop'
corepack enable
corepack prepare pnpm@10.33.0 --activate
pnpm install
pnpm run check:env
pnpm typecheck
pnpm test
Write-Host "Bootstrap complete!" -ForegroundColor Green
