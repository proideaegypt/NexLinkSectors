#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[[ -f "$REPO_ROOT/.env.example" ]] || { echo "ERROR: .env.example missing" >&2; exit 1; }
[[ -f "$REPO_ROOT/.env.schema" ]] || { echo "ERROR: .env.schema missing" >&2; exit 1; }
echo "✓ All env contract files present."
