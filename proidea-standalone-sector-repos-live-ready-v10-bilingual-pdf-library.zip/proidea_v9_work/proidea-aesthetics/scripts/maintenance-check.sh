#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"
echo "==> Independent maintenance check for $(basename "$REPO_ROOT")"
bash scripts/check-env-sync.sh
bash scripts/migrate.sh --dry-run
if command -v pnpm >/dev/null 2>&1; then
  bash scripts/test-security.sh
else
  echo "~ Skipping dependency audit because pnpm is not installed in this shell yet."
fi
echo "✓ $(basename "$REPO_ROOT") maintenance can be performed without touching any other sector repo."
