#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REMOTE_DIR="${SERVER_APP_DIR:-$(basename "$REPO_ROOT")}"
echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Deploying to production..."
ssh "${SERVER_USER:-root}@$SERVER_HOST" << ENDSSH
  cd "$REMOTE_DIR"
  git pull
  pnpm install --ignore-scripts
  bash scripts/certify-sector.sh
  docker compose -f infra/docker-compose.yml down && docker compose -f infra/docker-compose.yml up -d --build
ENDSSH
bash "$REPO_ROOT/scripts/qa-smoke.sh"
