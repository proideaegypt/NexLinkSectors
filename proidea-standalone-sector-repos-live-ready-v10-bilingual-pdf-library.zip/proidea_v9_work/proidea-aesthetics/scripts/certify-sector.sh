#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PUBLIC_NPMRC="${PUBLIC_NPMRC:-/tmp/public.npmrc}"
[[ -f "$PUBLIC_NPMRC" ]] || printf 'registry=https://registry.npmjs.org/\n' > "$PUBLIC_NPMRC"
INCLUDE_TESTS="${CERTIFY_INCLUDE_TESTS:-false}"

run_app() {
  local app_dir="$1"
  shift
  (cd "$app_dir" && "$@")
}

run_app "$REPO_ROOT/apps/api" npm install --no-audit --no-fund
run_app "$REPO_ROOT/apps/api" npm run build
run_app "$REPO_ROOT/apps/api" npm run typecheck
if [[ "$INCLUDE_TESTS" == "true" ]]; then
  run_app "$REPO_ROOT/apps/api" npm test
fi

run_app "$REPO_ROOT/apps/web" npm install --no-audit --no-fund
run_app "$REPO_ROOT/apps/web" npm run build
run_app "$REPO_ROOT/apps/web" npm run typecheck
if [[ "$INCLUDE_TESTS" == "true" ]]; then
  run_app "$REPO_ROOT/apps/web" npm test
fi

rm -rf "$REPO_ROOT/apps/admin/node_modules"
cp -a "$REPO_ROOT/apps/web/node_modules" "$REPO_ROOT/apps/admin/node_modules"
cp "$REPO_ROOT/apps/web/package-lock.json" "$REPO_ROOT/apps/admin/package-lock.json"
run_app "$REPO_ROOT/apps/admin" npm run build
run_app "$REPO_ROOT/apps/admin" npm run typecheck
if [[ "$INCLUDE_TESTS" == "true" ]]; then
  run_app "$REPO_ROOT/apps/admin" npm test
fi

run_app "$REPO_ROOT/apps/site" npm install --userconfig="$PUBLIC_NPMRC" --ignore-scripts --omit=optional --no-audit --no-fund
run_app "$REPO_ROOT/apps/site" npm run typecheck

echo "Site production build remains sandbox-sensitive because Next may try to fetch SWC binaries from the registry during build."
echo "Mobile dependency-backed certification remains sandbox-sensitive because Expo/React Native install and runtime are not stable in this environment."
