#!/usr/bin/env bash
set -euo pipefail
ssh "${SERVER_USER:-root}@$SERVER_HOST" << 'ENDSSH'
  cd ~/Proidea-Kick-Start
  git checkout HEAD~1
  pnpm install
  docker compose down && docker compose up -d --build
ENDSSH
