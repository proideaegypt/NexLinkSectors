#!/usr/bin/env node
import fs from 'node:fs/promises'
import path from 'node:path'

const repoRoot = path.resolve(new URL('..', import.meta.url).pathname)
const fixturePath = path.join(repoRoot, 'tests', 'fixtures', 'sector-smoke.json')
const fixture = JSON.parse(await fs.readFile(fixturePath, 'utf8'))
const apiBase = (process.env.API_BASE_URL || 'http://127.0.0.1:4000').replace(/\/$/, '')
const token = process.env.SMOKE_BEARER_TOKEN || ''
const tenantId = process.env.SMOKE_TENANT_ID || ''

async function runCheck(check, authed = false) {
  const url = new URL(apiBase + check.path)
  if (check.query?.tenantIdEnv && tenantId) url.searchParams.set('tenantId', tenantId)
  const res = await fetch(url, { headers: authed && token ? { Authorization: 'Bearer ' + token } : {} })
  const body = await res.text()
  if (res.status !== check.status && !authed) throw new Error(check.path + ' expected ' + check.status + ' got ' + res.status)
  if (!authed && check.contains && !body.includes(check.contains)) throw new Error(check.path + ' missing text ' + check.contains)
  console.log('✓', authed ? 'authed' : 'public', check.path, 'status=' + res.status)
}

for (const check of fixture.publicChecks) { await runCheck(check, false) }
if (!token || !tenantId) {
  console.log('~ Skipping authed smoke checks. Set SMOKE_BEARER_TOKEN and SMOKE_TENANT_ID to enable them.')
  process.exit(0)
}
for (const check of fixture.optionalAuthedChecks) {
  try {
    await runCheck({ ...check, status: 200 }, true)
  } catch (error) {
    console.error('✗', check.path, error instanceof Error ? error.message : String(error))
    process.exitCode = 1
  }
}
