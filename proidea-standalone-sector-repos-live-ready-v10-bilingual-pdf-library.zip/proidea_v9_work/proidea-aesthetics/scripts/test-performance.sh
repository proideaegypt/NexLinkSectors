#!/usr/bin/env bash
BASE="${API_BASE_URL:-http://localhost:4000}"
for i in $(seq 1 100); do curl -s -o /dev/null -w "%{time_total}
" "$BASE/health"; done | awk '{s+=$1;n++} END {printf "avg=%.3fs n=%d
",s/n,n}'
