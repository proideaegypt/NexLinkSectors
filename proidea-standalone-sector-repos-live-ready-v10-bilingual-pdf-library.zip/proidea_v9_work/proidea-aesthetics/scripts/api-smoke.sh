#!/usr/bin/env bash
set -euo pipefail
node scripts/api-smoke.mjs
