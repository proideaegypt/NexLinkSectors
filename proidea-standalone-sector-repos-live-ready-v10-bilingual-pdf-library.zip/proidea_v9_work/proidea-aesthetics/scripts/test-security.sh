#!/usr/bin/env bash
set -euo pipefail
pnpm audit --audit-level=high
grep -r --include="*.ts" "sk_live\|sk_test\|secret_" apps/ packages/ 2>/dev/null | grep -v ".env" && exit 1 || true
