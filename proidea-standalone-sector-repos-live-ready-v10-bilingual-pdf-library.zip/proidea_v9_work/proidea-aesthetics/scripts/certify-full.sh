#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"
echo "==> Sector certify: proidea-aesthetics"
bash scripts/certify-sector.sh
echo "==> API smoke"
bash scripts/api-smoke.sh
if [[ -n "${SITE_BASE_URL:-}" || -n "${WEB_BASE_URL:-}" || -n "${ADMIN_BASE_URL:-}" ]]; then
  echo "==> Playwright e2e"
  pnpm test:e2e
else
  echo "~ Skipping Playwright e2e. Set SITE_BASE_URL and/or WEB_BASE_URL and/or ADMIN_BASE_URL."
fi
