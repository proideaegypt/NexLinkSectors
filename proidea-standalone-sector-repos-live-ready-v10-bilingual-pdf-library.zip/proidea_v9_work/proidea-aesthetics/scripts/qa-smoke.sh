#!/usr/bin/env bash
set -euo pipefail
BASE="${API_BASE_URL:-http://localhost:4000}"
STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/health")
[[ "$STATUS" == "200" ]] || { echo "❌ /health returned $STATUS"; exit 1; }
BODY=$(curl -s "$BASE/health")
echo "✅ /health OK"
echo "$BODY" | grep -q 'ok' || { echo "❌ /health body missing ok"; exit 1; }
echo "✅ /health body OK"
