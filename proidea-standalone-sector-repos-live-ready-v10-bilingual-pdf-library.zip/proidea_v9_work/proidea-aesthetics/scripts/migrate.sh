#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DRY_RUN=false
[[ "${1:-}" == "--dry-run" ]] && DRY_RUN=true
echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Starting migrations (dry-run=$DRY_RUN)"
for f in "$REPO_ROOT"/database/migrations/*.sql; do
  [[ "$f" == *.gitkeep ]] && continue
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $($DRY_RUN && echo 'DRY-RUN' || echo 'Applying') $f"
  if ! $DRY_RUN; then psql "$SUPABASE_DB_URL" -f "$f"; fi
done
