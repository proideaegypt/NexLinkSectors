#!/usr/bin/env node
import fs from 'node:fs/promises'
import path from 'node:path'

const args = process.argv.slice(2)
const get = (flag, fallback = '') => {
  const index = args.indexOf(flag)
  return index >= 0 ? (args[index + 1] ?? fallback) : fallback
}

const cwd = process.cwd()
const sector = get('--sector', path.basename(cwd).replace(/^proidea-/, ''))
const date = get('--date', new Date().toISOString().slice(0, 10))
const started = get('--started', new Date().toISOString())
const ended = get('--ended', new Date().toISOString())
const duration = get('--duration', '')
const tokensIn = get('--tokens-in', '')
const tokensOut = get('--tokens-out', '')
const tokensTotal = get('--tokens-total', String((Number(tokensIn || 0) + Number(tokensOut || 0)) || ''))
const row = `| ${date} | ${sector} | ${get('--task', 'task')} | ${get('--agent', 'agent')} | ${get('--model', 'model')} | ${started} | ${ended} | ${duration} | ${tokensIn} | ${tokensOut} | ${tokensTotal} | ${get('--result', 'completed')} | ${get('--status', 'done')} | ${get('--files', '-')} | ${get('--next-owner', '-')} | ${get('--next-step', '-')} | ${get('--notes', '-')} |\n`

for (const file of ['proidea-agent-team.md', 'proidea-agents.md']) {
  const target = path.join(cwd, file)
  let current = await fs.readFile(target, 'utf8')
  current += current.endsWith('\n') ? row : `\n${row}`
  await fs.writeFile(target, current)
}
