# RBAC matrix

- owner: dashboard.read, records.read, records.write, automation.manage
- admin: dashboard.read, records.read, records.write, automation.manage
- practitioner: dashboard.read, records.read, records.write, automation.manage
- front-desk: dashboard.read, records.read, records.write, automation.manage
- viewer: dashboard.read, records.read, records.write, automation.manage
