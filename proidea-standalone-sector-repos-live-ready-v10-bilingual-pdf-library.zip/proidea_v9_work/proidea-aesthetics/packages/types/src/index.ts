export type AppEnv = 'development' | 'staging' | 'production'
export interface Tenant { id: string; slug: string; name: string; plan: 'free' | 'pro' | 'enterprise'; createdAt: string }
export interface User { id: string; tenantId: string; email: string; role: 'owner' | 'admin' | 'member'; createdAt: string }
export interface ApiResponse<T> { ok: boolean; data?: T; error?: string }
