export const ENV = process.env.APP_ENV || 'development'
export const IS_PROD = ENV === 'production'
