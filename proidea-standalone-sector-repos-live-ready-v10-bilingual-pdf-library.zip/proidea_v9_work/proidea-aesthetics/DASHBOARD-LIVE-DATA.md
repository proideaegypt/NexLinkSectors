# Dashboard live data

The web, admin, and mobile shells read from `/api/dashboard/summary` using live database counts.
