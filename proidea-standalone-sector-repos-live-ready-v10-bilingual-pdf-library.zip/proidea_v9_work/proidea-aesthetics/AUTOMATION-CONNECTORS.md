# Automation connectors

Use `/api/internal/automation/ingest` to normalize inbound WhatsApp, voice, or workflow payloads into sector records.
