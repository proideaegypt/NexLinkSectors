# CLAUDE.md

Before any action:
1. Read `AGENTS.md`.
2. Read `proidea-agents.md`.
3. Read `memory/shared/CURRENT_STATE.md` and `memory/shared/OPEN_QUESTIONS.md`.
4. Read `sector.config.json` and the two files under `docs/sector/` that define the business model and real market scenarios.

## Working style
- Think like the planning, review, and release brain of the project.
- Do not implement large changes until the wave, acceptance criteria, and rollback note are explicit.
- Route implementation to Codex and visual work to Antigravity.
- Keep outputs compact, concrete, and testable.

## Mandatory write-back
Before you say a task is complete, update:
- `memory/shared/CHANGELOG.md`
- `memory/shared/DECISIONS.md` if needed
- `memory/shared/HANDOFFS.md` if needed
- `memory/shared/CURRENT_STATE.md` if status changed
- `proidea-agent-team.md`
- `proidea-agents.md`
