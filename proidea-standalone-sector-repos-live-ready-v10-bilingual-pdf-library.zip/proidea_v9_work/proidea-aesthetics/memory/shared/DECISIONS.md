# Decisions

- Keep the monorepo starter structure across API, web, admin, site, and mobile so teams can ship in parallel.
- Use shared memory files as the source of truth for state, blockers, and handoffs.
- Gate production-critical changes behind review, QA, security, and rollback readiness.
- Use Spec Kit for specs/plans/tasks and GSD-style wave execution for implementation.

Context: Large SaaS project with many modules needs both strong specifications and high-throughput execution.
Decision: Use Spec Kit for specs/plans/tasks and GSD-style wave execution for implementation.
Consequences: Every major feature starts with spec first, then execution is delegated to specialized agents.


- Sector repo locked to `aesthetics` with its own database model, routes, dashboard, mobile shell, and marketing site.
