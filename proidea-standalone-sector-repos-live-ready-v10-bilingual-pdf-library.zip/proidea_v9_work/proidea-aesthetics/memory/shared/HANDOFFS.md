# Handoffs

- Initialize from current phase and record next owner after every task.
