# Changelog

2026-04-08T03:15 API health-check verified
- pnpm dev:api started successfully on port 4000
- Encountered EADDRINUSE from stale tsx process pid 3859588 and killed it
- Fix: kill $(lsof -ti 4000) before restart, no code change required
- GET /health returned 200 with ok true and service api

2026-04-08 Full repo regeneration with all fixes
- TS2582/TS2304 fixed by adding vitest/globals and @testing-library/jest-dom to tsconfig types
- pnpm bumped to 10.33.0
- next upgraded from 15.1.6 to 15.3.0
- mobile react aligned from 19 to 18.3.1 with @types/react ^18
- pnpm.onlyBuiltDependencies added for esbuild, sharp, unrs-resolver
- check-env-sync.sh fixed to use BASH_SOURCE for repo root detection
