# Persistence adapters

This repo uses Supabase/Postgres as the live persistence adapter for Aesthetics.
