# AGENTS.md - Proidea SaaS Agent Team Contract

## Prime rules
1. Read `AGENTS.md`, `proidea-agents.md`, `memory/shared/CURRENT_STATE.md`, and `sector.config.json` before starting any task.
2. Read the role file that matches your task in `.agents/` or `.claude/agents/` before doing work.
3. No implementation starts before scope, acceptance criteria, tests, and rollback path are clear.
4. Spec Kit is the source of truth. GSD is the execution layer.
5. Claude owns planning, architecture, review, QA, security review, release gates, and decisions.
6. Codex owns backend, database, mobile, n8n, automation code, deployment, and focused implementation.
7. Antigravity owns public site, app shell UI, motion, onboarding, design system, and visual polish.
8. After every meaningful task, update shared memory and the agent ledgers before declaring completion.
9. Stop immediately on tenant-isolation, billing, security, data-loss, or compliance risk.
10. Never hardcode secrets or bypass env contracts.

## Mandatory read order
1. `AGENTS.md`
2. `proidea-agents.md`
3. `memory/shared/CURRENT_STATE.md`
4. `memory/shared/OPEN_QUESTIONS.md`
5. `sector.config.json`
6. `docs/sector/BUSINESS-MODEL.md`
7. `docs/sector/REAL-MARKET-SCENARIOS.md`
8. `docs/sector/SECTOR-FIRST-PROMPTS.md`

## Tool ownership

| Situation | Owner |
|---|---|
| PRD, scope, architecture, sequencing, code review, QA strategy, security review, release decision | Claude |
| Routes, services, migrations, tests, mobile, n8n, deploy scripts, focused fixes | Codex |
| Site, UI system, motion, onboarding, app shell visuals, sales pages | Antigravity |

## Agent roster

| Agent | Primary owner | Scope |
|---|---|---|
| orchestrator | Claude | phase control, handoffs, final decision |
| architect | Claude | auth, tenancy, billing, system boundaries |
| product-manager | Claude | PRD, stories, acceptance criteria |
| feature-planner | Claude | wave design, dependencies, task slicing |
| backend-builder | Codex | API, middleware, services, workers |
| db-implementer | Codex | migrations, indexes, data repair |
| automation-builder | Codex | n8n, webhooks, integrations |
| mobile-builder | Codex | Expo/React Native implementation |
| deploy-builder | Codex | Docker, CI/CD, VPS, rollback |
| frontend-builder | Codex | dashboard/app feature implementation |
| design-lead | Antigravity | design system, visual language |
| ui-ux-designer | Antigravity | journeys, flows, empty states |
| marketing-site-designer | Antigravity | landing pages, conversion sections |
| qa-lead | Claude | test strategy, release verification |
| unit-tester | Codex | unit and integration tests |
| e2e-tester | Antigravity | visual flows, screenshots, Playwright |
| security-reviewer | Claude | auth, tenant isolation, secrets, uploads, webhooks |
| security-fixer | Codex | patch findings and add regression tests |
| code-reviewer | Claude | diff review, maintainability, consistency |
| performance-reviewer | Claude | Lighthouse, bundle, query, latency review |
| performance-fixer | Codex | optimization and retesting |
| release-manager | Claude | go/no-go, rollback path |
| growth-strategist | Claude | activation, conversion, retention |
| billing-strategist | Claude | pricing, usage, entitlements |
| analytics-planner | Claude | events, dashboards, KPIs |
| docs-writer | Claude | README, runbooks, manuals |
| compliance-planner | Claude | audit trail, privacy, retention |

## Memory contract
Shared memory files:
- `memory/shared/CURRENT_STATE.md`
- `memory/shared/CHANGELOG.md`
- `memory/shared/DECISIONS.md`
- `memory/shared/HANDOFFS.md`
- `memory/shared/OPEN_QUESTIONS.md`
- `memory/shared/RELEASE_STATUS.md`

Every meaningful task must append to:
- `memory/shared/CHANGELOG.md`
- `proidea-agent-team.md`
- `proidea-agents.md` task ledger

Update `DECISIONS.md` for non-obvious decisions and `HANDOFFS.md` when ownership changes.
