# Aesthetics Feature Delivery Runbook

1. Start from this repo and this repo only.
2. Create an isolated branch with `bash scripts/start-feature.sh \"feature name\"`.
3. Read `memory/shared/CURRENT_STATE.md`, `sector.config.json`, and `docs/SECTOR-INDEPENDENCE.md`.
4. Ship the feature behind sector-local flags or config when needed.
5. Update `proidea-agent-team.md` and `proidea-agents.md` after each meaningful task.

This keeps Aesthetics feature velocity independent from the rest of the portfolio.
