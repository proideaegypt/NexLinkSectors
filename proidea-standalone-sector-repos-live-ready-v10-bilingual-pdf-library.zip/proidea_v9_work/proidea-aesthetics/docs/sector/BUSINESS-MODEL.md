# Aesthetics business model

Headline: Coordinate consultations, treatment plans, sessions, and aftercare follow-ups in one aesthetic operations stack.

## Primary buyer
multi-practitioner aesthetics clinic

## Primary entities
- Client (`clients`)
- Consultation (`consultations`)
- Session (`sessions`)
- Treatment Plan (`treatment_plans`)

## Primary roles
- owner
- admin
- practitioner
- front-desk
- viewer

## Commercial promise
consultation-to-session operations with treatment plans, before/after workflow, deposits, and aftercare reminders
