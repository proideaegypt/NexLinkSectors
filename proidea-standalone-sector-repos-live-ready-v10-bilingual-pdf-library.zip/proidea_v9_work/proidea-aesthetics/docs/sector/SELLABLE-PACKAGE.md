# Aesthetics - Sellable Package Blueprint

## Who buys
- Business owner or operations manager in multi-practitioner aesthetics clinic

## What they buy first
- A first live workflow that feels operational in less than 30 days
- A dashboard for owners and operators
- A channel layer for inbound leads, bookings, or service requests
- Shared memory and agent-led implementation discipline

## Sales promise
"We make aesthetics operations easier to run, easier to track, and easier to grow without needing a giant ERP."

## Delivery milestones
1. Discovery + process map
2. First live workflow
3. Dashboard + operator training
4. Automation and reporting
5. Add-on upsell

## Upsell direction
- AI receptionist for consult qualification
- VIP package upsell engine
- aftercare automation
