# Fixes Log

## Applied fixes
- Fixed `apps/admin` TypeScript test errors `TS2582` and `TS2304` by adding `vitest/globals` and `@testing-library/jest-dom` to tsconfig types and enabling `globals: true` in Vitest.
- Fixed `scripts/check-env-sync.sh` to use `BASH_SOURCE` so repo root resolves correctly when the script is run from any directory.
- Upgraded `apps/site` from deprecated `next@15.1.6` to `15.3.0`.
- Fixed Expo/RN peer mismatch by pinning `react` to `18.3.1` and `@types/react` to `^18` in `apps/mobile`.
- Upgraded workspace package manager from `pnpm@10.0.0` to `pnpm@10.33.0`.
- Added `pnpm.onlyBuiltDependencies` for `esbuild`, `sharp`, and `unrs-resolver`.
- Fixed stale API process issue after `EADDRINUSE` by documenting `kill $(lsof -ti 4000)` before restart.
