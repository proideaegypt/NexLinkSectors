# READY-TO-SELL-ACTION-PLAN

## What makes a sector repo sellable
1. It solves one painful workflow end-to-end.
2. It has a clear buyer, operator, and daily user.
3. It has a measurable KPI improvement.
4. It has pricing, onboarding, and proof points.
5. It passes security, QA, and performance gates.

## Required go-to-market layers
- Core workflow: one daily operational loop that the buyer immediately feels.
- Control plane: tenant auth, roles, billing, dashboard.
- Channel layer: WhatsApp / voice / forms / web leads where relevant.
- Review mesh: QA, security, performance, release gate.
- Sales story: buyer pain, ROI, fast implementation, low-risk rollout.

## Wave order
### Now
- Freeze the first live buyer workflow.
- Ship the first vertical slice end-to-end.
- Add onboarding, dashboard proof, and task logging.

### Next
- Add the add-on that directly improves retention or ARPU.
- Add automation and reporting.
- Add better analytics and operator alerts.

### Later
- Expand to deeper intelligence, AI copilots, and advanced role packs.
- Add partner channels, integrations, and package upgrades.

## Quality gates
- Security: auth, RBAC, secrets, uploads, webhooks, tenant isolation.
- Performance: bundle size, route latency, N+1 prevention, index review.
- QA: happy path, validation, permissions, cross-tenant leakage, rollback.
- Product: PRD alignment, ICP fit, pricing fit, onboarding clarity.
