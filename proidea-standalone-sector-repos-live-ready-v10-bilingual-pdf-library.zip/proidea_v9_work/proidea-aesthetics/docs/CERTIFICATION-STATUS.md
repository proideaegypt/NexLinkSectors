# Certification Status

This repo was upgraded with a repeatable certification harness for API, web, admin, and site typecheck. Mobile remains sandbox-blocked when React Native tarballs require registry auth in this environment.

## Commands

```bash
bash scripts/certify-sector.sh
```

## Common fixes applied

- API test now closes Fastify cleanly after injection.
- Web and admin Vitest configs now use jsdom.
- Docker compose now points to `apps/api`.
- API Dockerfile added.
- Migration script now reads `database/migrations`.
- Deployment script no longer hardcodes `~/Proidea-Kick-Start`.

## v9 separation hardening

This repo now includes:
- Playwright e2e harness
- seeded API smoke fixture contract
- one-command full certification script
- go-live, maintenance, and feature-isolation runbooks

The goal is not to couple sectors more tightly. It is the opposite: every sector can now be shipped, tested, maintained, and extended independently.
