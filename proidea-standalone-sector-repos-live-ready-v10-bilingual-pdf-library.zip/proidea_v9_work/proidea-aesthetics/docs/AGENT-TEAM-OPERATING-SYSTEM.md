# Proidea SaaS Agent Team Operating System

## Direct answer
This is the updated operating model for a professional SaaS agent team using **Claude**, **Codex**, and **Antigravity** with shared memory, explicit handoffs, and prompt sets for planning, building, testing, reviewing, securing, releasing, and selling the product.[file:312][file:315]

## Core model
The recommended split is: **Claude** owns orchestration, architecture, product, review, release gates, and high-risk decisions; **Codex** owns implementation across backend, frontend app logic, mobile, automation, database execution, and fixes; **Antigravity** owns visual system, UI/UX, marketing site, onboarding, and interface polish.[file:295][file:315] This structure matches the existing repo pattern where Claude handles specs and reviews, Codex executes approved tasks, and Antigravity controls design without touching auth, tenant logic, or infra boundaries.[file:295][file:305]

## Agent teams

### Leadership and planning

| Agent | Owner | Main scope |
|---|---|---|
| Orchestrator | Claude | Phase control, wave routing, handoffs, escalation |
| Architect | Claude | System design, tenancy, auth, billing, integration boundaries |
| Product Manager | Claude | PRD, scope, acceptance criteria, priorities |
| Feature Planner | Claude | Break features into waves, tasks, deliverables |
| Release Manager | Claude | Go/no-go, release checklist, rollback decision |
| Docs Writer | Claude | README, runbooks, setup, API docs |

These roles align with the repo’s existing idea that Claude should own specs, planning, repair strategy, and architecture decisions before Codex executes the approved wave.[file:295][file:305]

### Build and delivery

| Agent | Owner | Main scope |
|---|---|---|
| Backend Builder | Codex | API, services, workers, queues, auth routes |
| Frontend Builder | Codex | Dashboard logic, hooks, forms, state, tables |
| Mobile Builder | Codex | Expo React Native implementation |
| Automation Builder | Codex | n8n workflows, webhooks, jobs, integrations |
| DB Implementer | Codex | SQL migrations, repositories, seeds, query fixes |
| Ops / Deploy | Codex | Docker, CI/CD, VPS, Portainer, rollback scripts |
| Performance Fixer | Codex | Query tuning, caching, rendering fixes |
| Security Fixer | Codex | Patch findings and add regression tests |
| Unit Tester | Codex | Unit and integration tests, mocks, fixtures |

This follows the earlier operating rule that Codex owns backend, database, mobile, n8n, deployment, and infra execution, and should implement only from approved tasks or GSD waves.[file:295][file:315]

### Design, UX, and growth

| Agent | Owner | Main scope |
|---|---|---|
| Design Lead | Antigravity | Design system, visual language, landing direction |
| UI/UX Designer | Antigravity | Flows, wireframes, states, friction reduction |
| Marketing Site Designer | Antigravity | Public site, conversion sections, onboarding visuals |
| Onboarding Designer | Antigravity | Activation path, first-run UX, empty states |
| E2E Visual Tester | Antigravity | Playwright-assisted visual review, screenshots, UI regressions |
| Growth / PLG Strategist | Claude | Activation, conversion loops, WhatsApp lifecycle, trial-to-paid |
| Analytics Planner | Claude | Events taxonomy, dashboards, retention instrumentation |
| Billing Strategist | Claude | Plans, usage rules, dunning, plan enforcement |
| Customer Success Planner | Claude | Help docs, issue triage, churn rescue flows |
| Compliance Planner | Claude | Retention, consent, audit trail, policy readiness |

Antigravity already fits the repo design as the owner of front page, app shell UI, design system, motion, and onboarding visuals, while avoiding auth logic and infra changes.[file:295][file:305]

### Verification mesh

| Agent | Owner | Main scope |
|---|---|---|
| QA Lead | Claude | Test strategy, release checklist, acceptance verification |
| E2E Tester | Codex or Antigravity | Playwright user journeys, smoke coverage |
| Security Reviewer | Claude | Auth, tenant isolation, secrets, webhook and upload review |
| Code Reviewer | Claude | Diff review, maintainability, consistency, risk notes |
| Performance Reviewer | Claude | Lighthouse, bundle, API latency, bottleneck review |
| DB Architect | Claude | Schema design, RLS, indexes, migration strategy |

The repo’s review mesh already includes QA verifier, security reviewer, performance reviewer, and release manager as explicit gates before merge or release.[file:295][file:315]

## Recommended folder additions
Create or keep these files and folders to make agent spawning deterministic:[file:295][file:315]

```text
.agents/
  orchestrator.md
  architect.md
  product-manager.md
  feature-planner.md
  backend-builder.md
  frontend-builder.md
  mobile-builder.md
  automation-builder.md
  db-implementer.md
  design-lead.md
  ui-ux-designer.md
  qa-lead.md
  e2e-tester.md
  security-reviewer.md
  security-fixer.md
  code-reviewer.md
  performance-reviewer.md
  performance-fixer.md
  release-manager.md
  growth-strategist.md
  analytics-planner.md
  billing-strategist.md
  customer-success-planner.md
  compliance-planner.md
  docs-writer.md

memory/
  shared/
    CURRENT_STATE.md
    CHANGELOG.md
    DECISIONS.md
    HANDOFFS.md
    OPEN_QUESTIONS.md
    RELEASE_STATUS.md
  claude/
    MEMORY.md
    LAST_SESSION.md
  codex/
    MEMORY.md
    LAST_SESSION.md
  antigravity/
    MEMORY.md
    LAST_SESSION.md

docs/
  PROMPTS-GUIDE.md
  workflows/
    AGENT-WORKFLOWS.md
  qa/
    TEST-PLAN.md
  release/
    RELEASE-CHECKLIST.md
  product/
    PRD-TEMPLATE.md
```

The shared-memory pattern with `CURRENT_STATE.md`, `CHANGELOG.md`, `DECISIONS.md`, `HANDOFFS.md`, and local `LAST_SESSION.md` files was already defined as the coordination bus between Claude, Codex, and Antigravity.[file:295][file:315]

## Spawn rules
Use these rules for spawning agents:[file:295][file:315]

1. Orchestrator reads `AGENTS.md` and `memory/shared/CURRENT_STATE.md` first.[file:312][file:315]
2. Product Manager or Feature Planner writes the wave, scope, dependencies, acceptance criteria, and done definition before any build agent starts.[file:295]
3. Architect must approve work that touches auth, billing, tenant boundaries, RLS, or deployment topology.[file:295][file:305]
4. Codex builders only execute approved tasks and must return changed files, tests, risks, and rollback notes.[file:295]
5. Antigravity may change UI and UX flows, but must not alter auth, tenant logic, API contracts, or infra files.[file:295][file:305]
6. Every meaningful task must append updates to shared memory before completion.[file:295][file:315]
7. Security Reviewer, Code Reviewer, QA Lead, and Release Manager form the final gate before merge or production deployment.[file:295]

## Prompt guide update
`docs/PROMPTS-GUIDE.md` should be extended from phase prompts only into two layers: phase prompts and role prompts.[file:312][file:315]

### Keep the phase prompts
Retain the existing phase progression such as bootstrap, auth, RBAC, core vertical, integrations, admin UI, QA, security, and deploy.[file:312][file:315]

### Add role prompts
Add these role prompt families to the guide:

| Prompt ID | Agent | Purpose |
|---|---|---|
| PM-01 | Product Manager | Write feature brief, problem, user story, acceptance criteria |
| PLAN-01 | Feature Planner | Break feature into waves, owners, dependencies, outputs |
| ARCH-01 | Architect | Review architecture impact, contracts, schema, risk |
| DB-01 | DB Architect | Design schema, RLS, indexes, migrations |
| BE-01 | Backend Builder | Implement API/service/task from approved wave |
| FE-01 | Frontend Builder | Implement dashboard/app feature from approved wave |
| AUTO-01 | Automation Builder | Build n8n workflow and webhook contracts |
| UX-01 | UI/UX Designer | Reduce onboarding friction, map states, improve flow |
| DESIGN-01 | Design Lead | Build or refine design system and visual direction |
| TEST-01 | Unit Tester | Add unit/integration tests and edge-case coverage |
| QA-01 | QA Lead | Build test matrix and release checklist |
| E2E-01 | E2E Tester | Write Playwright smoke and critical flows |
| SEC-01 | Security Reviewer | Run auth, tenant isolation, upload, webhook, secret audit |
| SECFIX-01 | Security Fixer | Patch findings and add regression tests |
| REV-01 | Code Reviewer | Review changed files, list must-fix/should-fix |
| PERF-01 | Performance Reviewer | Review bundle, LCP, API latency, N+1/query risk |
| RELEASE-01 | Release Manager | Decide go/no-go with blockers and rollback plan |
| GROWTH-01 | Growth Strategist | Improve activation, conversion, retention loops |
| BILLING-01 | Billing Strategist | Define plans, usage metering, access enforcement |
| ANALYTICS-01 | Analytics Planner | Define event taxonomy and dashboards |
| DOCS-01 | Docs Writer | Update README, setup docs, runbooks, onboarding |

This approach matches the existing repo intent that prompts should cover phases, agent ownership, QA/security/review workflows, and technical fixes in one reusable base system.[file:312][file:315]

## Example prompt templates

### PM-01
```md
Read AGENTS.md and memory/shared/CURRENT_STATE.md first.
Act as Product Manager.
Prepare a feature brief for: <feature-name>.
Output only:
1. user problem
2. target persona
3. scope in / out of scope
4. acceptance criteria
5. risks
6. dependencies
7. suggested next owner
Then append a short note to memory/shared/DECISIONS.md and memory/shared/HANDOFFS.md.
```

### PLAN-01
```md
Read AGENTS.md, memory/shared/CURRENT_STATE.md, and the latest feature brief.
Act as Feature Planner.
Break <feature-name> into execution waves.
For each wave return: goal, owners, changed areas, test expectations, security checks, rollback note.
Do not write code.
Append summary to memory/shared/CHANGELOG.md and update CURRENT_STATE.md.
```

### SEC-01
```md
Read AGENTS.md, CURRENT_STATE.md, and the changed files diff.
Act as Security Reviewer.
Audit auth, RBAC, tenant isolation, secrets, file uploads, webhooks, and n8n credential boundaries.
Return:
- must-fix
- should-fix
- safe areas
- regression tests required
Update HANDOFFS.md with next owner.
```

### REV-01
```md
Read AGENTS.md, CURRENT_STATE.md, and the diff.
Act as Code Reviewer.
Review for maintainability, consistency, type safety, duplicate logic, missing tests, and rollout risk.
Return:
- approve / reject
- must-fix
- should-fix
- touched files
- next owner
Append review result to CHANGELOG.md.
```

### RELEASE-01
```md
Read CURRENT_STATE.md, CHANGELOG.md, HANDOFFS.md, QA results, security review, and performance review.
Act as Release Manager.
Decide go / no-go for staging or production.
Return blockers, mitigations, rollback path, migration risk, and exact next command sequence.
Update RELEASE_STATUS.md.
```

## What makes it sellable
To go from “working SaaS” to “ready to sell,” add these operational streams in parallel with feature delivery:[file:295]

- Billing readiness: plans, entitlements, invoices, dunning, cancellation, seat or usage enforcement.[file:295]
- Activation readiness: onboarding, empty states, first-value path, lifecycle nudges, WhatsApp-first follow-ups.[file:295]
- Analytics readiness: event map, activation dashboard, retention/cohort visibility, error funnel visibility.[file:295]
- Support readiness: docs, canned replies, issue severity rules, customer success handoff.[file:295]
- Compliance readiness: audit trail, privacy/data retention rules, secrets handling, access reviews.[file:295]
- Release readiness: rollback docs, smoke plan, security gate, performance budget, deploy checklist.[file:295][file:315]

## Suggested rollout order
Use this order instead of enabling every agent at once:[file:295][file:315]

1. Orchestrator, Architect, Product Manager, Feature Planner.
2. Backend Builder, Frontend Builder, DB Implementer, Automation Builder.
3. Design Lead and UI/UX Designer.
4. Unit Tester, QA Lead, Security Reviewer, Code Reviewer.
5. Release Manager and Ops / Deploy.
6. Growth, Billing, Analytics, Customer Success, Compliance.

This keeps the team lean at first while preserving the review mesh needed for a production SaaS workflow.[file:295]

## Immediate next update for the repo
Update the repo so that `docs/PROMPTS-GUIDE.md` contains both **phase prompts** and **agent-team prompts**, and add agent definitions under `.agents/` for product, planning, QA, testing, security, review, performance, docs, growth, billing, and compliance.[file:312][file:315] Also keep the shared-memory rule mandatory so no agent finishes a task without updating `CHANGELOG`, `CURRENT_STATE`, and `HANDOFFS` as required.[file:295][file:315]
