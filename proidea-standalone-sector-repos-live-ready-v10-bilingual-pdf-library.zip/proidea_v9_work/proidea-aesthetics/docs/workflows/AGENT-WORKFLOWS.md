# AGENT-WORKFLOWS

## Standard feature workflow
1. Product Manager writes the feature brief.
2. Feature Planner breaks the work into waves.
3. Architect reviews boundaries if auth, billing, tenancy, or infra are touched.
4. Codex builders implement approved waves.
5. Design / UX roles refine user-facing flows if needed.
6. Unit Tester adds coverage.
7. QA Lead reviews acceptance and gaps.
8. Security Reviewer and Code Reviewer run gates.
9. Performance Reviewer checks bottlenecks if relevant.
10. Release Manager decides go / no-go.

## Security bug workflow
1. Security Reviewer identifies issue.
2. Security Fixer patches it.
3. Unit Tester adds regression coverage.
4. Security Reviewer rechecks.
5. Release Manager updates release status.

## Deploy workflow
1. Verify current state and changelog.
2. Run bootstrap / typecheck / tests / smoke.
3. Run security and performance checks.
4. Validate env completeness.
5. Deploy to staging or production.
6. Run smoke tests.
7. Log handoff and release status.

## Compact handoff rule
Every finished task must leave:
- what changed
- what remains
- blockers
- next owner
- exact next command or prompt
