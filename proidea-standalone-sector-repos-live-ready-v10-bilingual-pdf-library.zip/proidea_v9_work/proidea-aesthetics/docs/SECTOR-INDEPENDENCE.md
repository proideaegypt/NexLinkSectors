# Aesthetics Sector Independence

This repository is a standalone delivery unit for **Aesthetics**.

## Rules
- Go live from this repo only.
- Run tests from this repo only.
- Perform maintenance from this repo only.
- Add new features inside this repo only.
- Do not wait for any other sector to be production-ready before shipping Aesthetics.

## What stays isolated
- Database migrations and seeds
- Env files and secrets
- Playwright e2e suite
- API smoke fixtures
- Deployment commands
- Maintenance checks
- Feature branches and agent ledgers

## What can still be shared conceptually
- Architecture patterns
- Agent prompts
- Quality gates
- Sector-factory improvements in `proidea-sector-base`

Isolation here matches the direction already established in the uploaded planning notes: each sector is a standalone repo with its own database model and sector-specific workflows, not just a single shared schema with renamed screens.
