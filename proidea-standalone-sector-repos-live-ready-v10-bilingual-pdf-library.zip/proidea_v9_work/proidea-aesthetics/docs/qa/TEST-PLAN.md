# Test Plan — Proidea SaaS

## Strategy
- Unit tests: vitest for business logic and routes
- Integration tests: vitest for multi-step flows
- E2E tests: Playwright for critical user journeys
- Security tests: pnpm audit + manual OWASP review

## Coverage Targets
| Layer | Target |
|---|---|
| packages/db | 90% |
| apps/api routes | 85% |
| apps/api middleware | 100% |
| apps/web critical flows | 80% |
| apps/admin critical flows | 80% |
| E2E P0 flows | 100% |

## P0 Flows
1. Register → Login → Dashboard visible
2. Create booking → appears in list
3. Cancel booking → status = cancelled
4. Tenant isolation: user A cannot see tenant B data
