# QUALITY-GATES

## Release gate checklist
- [ ] Scope matches PRD and current wave.
- [ ] Happy path tested.
- [ ] Failure path tested.
- [ ] Permission checks tested.
- [ ] Tenant isolation tested.
- [ ] Security reviewer signed off.
- [ ] Performance reviewer signed off.
- [ ] Rollback path written.
- [ ] Shared memory updated.
- [ ] proidea-agent-team.md updated.
- [ ] proidea-agents.md updated.
