# Aesthetics Certification Dashboard

| Lane | Status | Command |
| --- | --- | --- |
| Standalone go-live guardrail | ready | `bash scripts/go-live-check.sh` |
| Dependency-backed build gate | ready | `bash scripts/certify-sector.sh` |
| API smoke fixture lane | ready | `bash scripts/api-smoke.sh` |
| Browser e2e lane | ready when URLs are provided | `pnpm test:e2e` |
| Maintenance gate | ready | `bash scripts/maintenance-check.sh` |
| Feature isolation lane | ready | `bash scripts/start-feature.sh` |

This dashboard exists to keep Aesthetics production readiness independent from other sectors.
