# PROMPTS-GUIDE

## Read-first rule
Every prompt starts by reading:
- `AGENTS.md`
- `proidea-agents.md`
- `memory/shared/CURRENT_STATE.md`
- `sector.config.json`
- `docs/sector/BUSINESS-MODEL.md`
- `docs/sector/REAL-MARKET-SCENARIOS.md`

## Tool labels
- Claude = planning, architecture, product, QA, security, review, release
- Codex = backend, DB, mobile, n8n, deploy, focused implementation
- Antigravity = site, UI/UX, motion, design polish

## Phase prompts
### P0 - baseline verification (Claude)
Review current repo state, blockers, env gaps, and first production-risk areas. Do not code.

### P1 - first live workflow plan (Claude)
Plan the smallest sellable workflow for this sector. Output buyer, user, scope, KPI, acceptance criteria, tests, rollback, next owner.

### P2 - implementation wave (Codex)
Implement only the approved wave. Return changed files, tests, open risks, rollback note.

### P3 - UI and onboarding polish (Antigravity)
Build or refine the public-facing page and operator UI states using the approved contracts only.

### P4 - review mesh (Claude)
Run QA, security, performance, and release review on the diff and test outputs.

## Role prompts
### PM-01
Act as Product Manager. Write the feature brief for <feature-name> with: problem, persona, scope, KPI, risks, dependencies, next owner.

### PLAN-01
Act as Feature Planner. Break <feature-name> into waves with owners, changed areas, required tests, security checks, rollback.

### ARCH-01
Act as Architect. Review data model, contracts, auth boundaries, infra impact, and rollout risk.

### BE-01
Act as Backend Builder. Implement the approved slice only. Include tests and rollback note.

### AUTO-01
Act as Automation Builder. Implement n8n/webhook work with retries, failure handling, and tenant mapping.

### FE-01
Act as Frontend Builder. Implement the approved dashboard or app slice with loading, empty, success, and error states.

### DESIGN-01
Act as Design Lead. Improve the design system, visual hierarchy, and conversion path without changing backend contracts.

### QA-01
Act as QA Lead. Build a release-grade test matrix for the selected slice.

### SEC-01
Act as Security Reviewer. Audit auth, tenant isolation, secrets, uploads, webhooks, and rate limits.

### PERF-01
Act as Performance Reviewer. Review route latency, bundle size, query plans, and rendering bottlenecks.

### RELEASE-01
Act as Release Manager. Decide go / no-go using current state, changelog, QA, security, and performance outputs.
