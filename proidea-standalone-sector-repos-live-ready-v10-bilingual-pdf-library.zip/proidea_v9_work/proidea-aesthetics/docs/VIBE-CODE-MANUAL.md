# VIBE-CODE-MANUAL

This repo is designed for a three-tool operating model:
- Claude = planning, architecture, security review, QA review, release gates
- Codex = backend, DB, mobile, n8n, deploy, focused implementation
- Antigravity = marketing site, app shell UI, motion, design polish

## Step-by-step way to use the repo
### 1. Prepare the repo
```bash
corepack enable
corepack prepare pnpm@10.33.0 --activate
pnpm install
bash bootstrap.sh
bash scripts/check-env-sync.sh
```

### 2. Read the operating files in this order
1. `AGENTS.md`
2. `proidea-agents.md`
3. `memory/shared/CURRENT_STATE.md`
4. `sector.config.json`
5. `docs/sector/BUSINESS-MODEL.md`
6. `docs/sector/REAL-MARKET-SCENARIOS.md`
7. `docs/sector/SECTOR-FIRST-PROMPTS.md`

### 3. Start the wave in Claude
Paste the Sector Kickoff prompt from `docs/sector/SECTOR-FIRST-PROMPTS.md` into Claude Code.
Expected result:
- clear business outcome
- wave scope
- acceptance criteria
- tests
- rollback note
- next owner

### 4. Execute the approved slice in Codex
Use the Codex execution prompt from `docs/sector/SECTOR-FIRST-PROMPTS.md`.
Keep the task narrow. One wave. One outcome. No side quests.

### 5. Build or polish UI in Antigravity
Use the Antigravity prompt from `docs/sector/SECTOR-FIRST-PROMPTS.md` when the backend contract is clear.
Ask for real states: loading, empty, success, failure, permission denied, stale data.

### 6. Run verification locally
```bash
pnpm test
pnpm typecheck
bash scripts/qa-smoke.sh
bash scripts/test-security.sh
bash scripts/test-performance.sh
```

### 7. Ask Claude for the release gate
Run the release prompt after implementation and tests.
Claude should decide: go / no-go.

### 8. Update memory and ledgers after every meaningful task
Required updates:
- `memory/shared/CHANGELOG.md`
- `memory/shared/DECISIONS.md` when needed
- `memory/shared/HANDOFFS.md` when owner changes
- `memory/shared/CURRENT_STATE.md` when status changes
- `proidea-agent-team.md`
- `proidea-agents.md`

## Command cheatsheet
```bash
pnpm dev:api
pnpm dev:web
pnpm dev:admin
pnpm dev:site
pnpm test
pnpm typecheck
bash scripts/review-local.sh
bash scripts/test-security.sh
bash scripts/test-performance.sh
bash scripts/deploy-staging.sh
bash scripts/deploy-prod.sh
bash scripts/rollback.sh
node scripts/update-agent-ledger.mjs --task "wave-name" --agent "Codex-Backend" --model "codex" --result "implemented and tested" --status done --duration 28 --tokens-in 12000 --tokens-out 3800 --files "apps/api/src/*"
```

## Non-negotiables
- Arabic-first and multi-tenant safe.
- No public medical or sensitive artifacts.
- No direct production deploy without a rollback path.
- No feature is considered sellable until onboarding, support, security, QA, and pricing impact are clear.
