# Aesthetics Maintenance Runbook

## Routine checks
- `bash scripts/maintenance-check.sh`
- rotate secrets for this sector env
- review database migrations in this repo only
- review automation failures for this repo only
- update agent ledger and shared memory after each fix

## Maintenance principle
Maintenance stays sector-scoped. A Aesthetics hotfix should not require changing unrelated sector repos.
