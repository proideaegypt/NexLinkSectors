import { test, expect } from '@playwright/test'

const baseURL = process.env.WEB_BASE_URL

test('web dashboard shell renders for Aesthetics', async ({ page }) => {
  test.skip(!baseURL, 'Set WEB_BASE_URL to run sector web e2e.')
  await page.goto(baseURL!)
  await expect(page.locator('h1')).toContainText('Proidea Aesthetics')
})
