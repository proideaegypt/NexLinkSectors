# Proidea Aesthetics

Standalone sector repo generated from `proidea-sector-base` and prepared for vibe coding.

## Stack
- Site: Next.js
- Web/Admin: Vite React
- API: Fastify
- Mobile: Expo React Native
- Database: Supabase / Postgres
- Deploy: VPS Docker + Portainer

## Sector model
- Archetype: `care-appointment`
- Resource base: `aesthetics`
- Roles: owner, admin, practitioner, front-desk, viewer

## Quick start
```bash
corepack enable
corepack prepare pnpm@10.33.0 --activate
pnpm install
bash bootstrap.sh
```

## What is already included
- live Supabase/Postgres adapter scaffolds
- staff auth + tenant RBAC scaffolds
- live dashboard summary route
- mobile dashboard shell
- animated marketing site scaffold
- automation webhook connector scaffold

## First implementation slice
See `SECTOR-START-HERE.md` and `docs/sector/FIRST-IMPLEMENTATION-SLICE.md`.

## Sector isolation contract

This repo is operated as a standalone Aesthetics product unit for go-live, testing, maintenance, and feature delivery. Use the commands below from this repo only:

- `bash scripts/go-live-check.sh`
- `bash scripts/certify-full.sh`
- `bash scripts/maintenance-check.sh`
- `bash scripts/start-feature.sh \"your feature\"`
