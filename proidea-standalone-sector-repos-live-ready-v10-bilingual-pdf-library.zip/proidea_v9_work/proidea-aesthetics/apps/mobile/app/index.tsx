import React, { useState } from 'react'
import { SafeAreaView, ScrollView, Text, TextInput, TouchableOpacity, View } from 'react-native'

type SummaryCard = { table: string; label: string; count: number }
type SummaryPayload = { counts?: SummaryCard[] }

export default function Index() {
  const [apiUrl, setApiUrl] = useState('http://localhost:4000')
  const [tenantId, setTenantId] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [token, setToken] = useState('')
  const [summary, setSummary] = useState<SummaryPayload | null>(null)
  const [error, setError] = useState('')

  const login = async () => {
    setError('')
    const res = await fetch(apiUrl + '/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, tenantId }),
    })
    const data = (await res.json()) as { error?: string; accessToken?: string }
    if (!res.ok) {
      setError(data.error || 'Login failed')
      return
    }
    setToken(data.accessToken || '')
  }

  const loadDashboard = async () => {
    setError('')
    const res = await fetch(apiUrl + '/api/dashboard/summary?tenantId=' + encodeURIComponent(tenantId), {
      headers: token ? { Authorization: 'Bearer ' + token } : {},
    })
    const data = (await res.json()) as { error?: string; summary?: SummaryPayload }
    if (!res.ok) {
      setError(data.error || 'Dashboard load failed')
      return
    }
    setSummary(data.summary || null)
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#08101d' }}>
      <ScrollView contentContainerStyle={{ padding: 20, gap: 14 }}>
        <Text style={{ color: 'white', fontSize: 28, fontWeight: '700' }}>Proidea Aesthetics</Text>
        <Text style={{ color: '#a9b4d0' }}>Coordinate consultations, treatment plans, sessions, and aftercare follow-ups in one aesthetic operations stack.</Text>
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="API URL" placeholderTextColor="#8a97b8" value={apiUrl} onChangeText={setApiUrl} />
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="Tenant ID" placeholderTextColor="#8a97b8" value={tenantId} onChangeText={setTenantId} />
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="Email" placeholderTextColor="#8a97b8" value={email} onChangeText={setEmail} />
        <TextInput style={{ backgroundColor: '#111a2b', color: 'white', padding: 12, borderRadius: 12 }} placeholder="Password" secureTextEntry placeholderTextColor="#8a97b8" value={password} onChangeText={setPassword} />
        <TouchableOpacity style={{ backgroundColor: '#3b82f6', padding: 14, borderRadius: 12 }} onPress={login}><Text style={{ color: 'white', textAlign: 'center', fontWeight: '700' }}>Login</Text></TouchableOpacity>
        <TouchableOpacity style={{ backgroundColor: '#10b981', padding: 14, borderRadius: 12 }} onPress={loadDashboard}><Text style={{ color: 'white', textAlign: 'center', fontWeight: '700' }}>Load dashboard</Text></TouchableOpacity>
        {error ? <Text style={{ color: '#fda4af' }}>{error}</Text> : null}
        {summary?.counts?.map((card) => (
          <View key={card.table} style={{ backgroundColor: '#111a2b', padding: 16, borderRadius: 14 }}>
            <Text style={{ color: 'white', fontWeight: '700' }}>{card.label}</Text>
            <Text style={{ color: '#93c5fd', fontSize: 24, marginTop: 6 }}>{card.count}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  )
}
