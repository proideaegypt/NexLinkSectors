export default function HomePage() {
  return (
    <main className="hero">
      <div className="hero-inner">
        <section>
          <div className="eyebrow">Proidea Aesthetics</div>
          <h1 className="headline">Coordinate consultations, treatment plans, sessions, and aftercare follow-ups in one aesthetic operations stack.</h1>
          <p className="copy">
            Launch a tenant-aware aesthetics platform with live dashboards, role-based access, mobile control,
            automation connectors, and a database designed specifically for this business model.
          </p>
          <div className="cta-row">
            <a className="btn btn-primary" href="#get-started">Go live this week</a>
            <a className="btn btn-secondary" href="/docs">Read the implementation plan</a>
          </div>
        </section>
        <section className="stage" aria-label="3D marketing showcase">
          <div className="glow" />
          <div className="orbital">
            <div className="card3d"><strong>Client</strong><p style={{color:'#dce7ff'}}>Live operations</p></div>\n            <div className="card3d"><strong>Consultation</strong><p style={{color:'#dce7ff'}}>Live operations</p></div>\n            <div className="card3d"><strong>Session</strong><p style={{color:'#dce7ff'}}>Live operations</p></div>
          </div>
        </section>
      </div>
    </main>
  )
}
