import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useMemo, useState } from 'react';
export default function App() {
    const [apiUrl, setApiUrl] = useState('http://localhost:4000');
    const [tenantId, setTenantId] = useState('');
    const [token, setToken] = useState('');
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const cards = useMemo(() => result?.summary?.counts ?? [], [result]);
    const load = async () => {
        setLoading(true);
        const res = await fetch(apiUrl + '/api/dashboard/summary?tenantId=' + encodeURIComponent(tenantId), {
            headers: token ? { Authorization: 'Bearer ' + token } : {},
        });
        const data = (await res.json());
        setResult(data);
        setLoading(false);
    };
    return (_jsxs("div", { style: { fontFamily: 'Inter, sans-serif', padding: 32, color: '#fff', background: '#0b1020', minHeight: '100vh' }, children: [_jsx("h1", { children: "Proidea Aesthetics Dashboard" }), _jsx("p", { children: "Coordinate consultations, treatment plans, sessions, and aftercare follow-ups in one aesthetic operations stack." }), _jsxs("div", { style: { display: 'grid', gap: 12, maxWidth: 680, marginBottom: 24 }, children: [_jsx("input", { placeholder: "API URL", value: apiUrl, onChange: (event) => setApiUrl(event.target.value) }), _jsx("input", { placeholder: "Tenant ID", value: tenantId, onChange: (event) => setTenantId(event.target.value) }), _jsx("input", { placeholder: "Bearer token", value: token, onChange: (event) => setToken(event.target.value) }), _jsx("button", { onClick: load, disabled: loading, children: loading ? 'Loading…' : 'Load live dashboard' })] }), _jsx("div", { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16 }, children: cards.map((card) => (_jsxs("div", { style: { background: '#121a33', border: '1px solid #253155', borderRadius: 16, padding: 16 }, children: [_jsx("strong", { children: card.label }), _jsx("div", { style: { fontSize: 30, marginTop: 10 }, children: card.count })] }, card.table))) }), result?.error ? _jsx("p", { style: { color: '#ff8080' }, children: result.error }) : null] }));
}
