import type { FastifyReply } from 'fastify'

export function ok(reply: FastifyReply, payload: unknown) {
  return reply.code(200).send({ ok: true, ...((payload ?? {}) as Record<string, unknown>) })
}

export function fail(reply: FastifyReply, status: number, error: string, code?: string) {
  return reply.code(status).send({ ok: false, error, code: code ?? 'request_failed' })
}
