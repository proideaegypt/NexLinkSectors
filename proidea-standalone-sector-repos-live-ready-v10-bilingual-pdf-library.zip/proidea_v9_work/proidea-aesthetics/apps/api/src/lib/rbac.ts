export function hasCapability(input: { role: string; capabilities: string[] | unknown; required: string }) {
  if (input.role === 'owner' || input.role === 'admin') return true
  const caps = Array.isArray(input.capabilities) ? input.capabilities.map(String) : []
  return caps.includes(input.required)
}
