import type { FastifyRequest } from 'fastify'
import { supabaseAdmin, supabaseAuth } from './supabase.js'

export async function loginWithPassword(email: string, password: string) {
  const { data, error } = await supabaseAuth.auth.signInWithPassword({ email, password })
  if (error || !data.session) {
    throw new Error(error?.message || 'Login failed')
  }
  return data.session
}

export async function requireUser(request: FastifyRequest) {
  const authHeader = request.headers.authorization || ''
  if (!authHeader.toLowerCase().startsWith('bearer ')) {
    throw new Error('Missing bearer token')
  }
  const token = authHeader.slice(7).trim()
  const { data, error } = await supabaseAuth.auth.getUser(token)
  if (error || !data.user) {
    throw new Error(error?.message || 'Invalid session token')
  }
  return { token, user: data.user }
}

export async function resolveMembership(userId: string, tenantId?: string | null) {
  const { data: profile, error: profileError } = await supabaseAdmin
    .from('staff_profiles')
    .select('id, user_id, email, full_name, is_active')
    .eq('user_id', userId)
    .maybeSingle()
  if (profileError || !profile || profile.is_active === false) {
    throw new Error('Staff profile missing or inactive')
  }

  let query = supabaseAdmin
    .from('staff_tenant_memberships')
    .select('id, tenant_id, role, capabilities, is_active')
    .eq('staff_profile_id', profile.id)
    .eq('is_active', true)
    .limit(1)
  if (tenantId) query = query.eq('tenant_id', tenantId)
  const { data: membership, error: membershipError } = await query.maybeSingle()
  if (membershipError || !membership) {
    throw new Error('Staff membership missing for this tenant')
  }

  const { data: tenant, error: tenantError } = await supabaseAdmin
    .from('tenants')
    .select('id, slug, name, plan_code, locale, status')
    .eq('id', membership.tenant_id)
    .maybeSingle()
  if (tenantError || !tenant) {
    throw new Error('Tenant record missing')
  }

  return { profile, membership, tenant }
}
