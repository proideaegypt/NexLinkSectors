import { describe, expect, it } from 'vitest'
import { buildApp } from './app.js'

describe('api', () => {
  it('builds the app', async () => {
    const app = buildApp()
    try {
      const response = await app.inject({ method: 'GET', url: '/health' })
      expect(response.statusCode).toBe(200)
    } finally {
      await app.close()
    }
  })
})
