import type { FastifyInstance } from 'fastify'
import { requireUser, resolveMembership, loginWithPassword } from '../../lib/auth.js'
import { fail, ok } from '../../lib/http.js'
import { hasCapability } from '../../lib/rbac.js'
import { changeEntityStatus, createEntityRecord, getDashboardSummary, getEntityList } from './service.js'
import { ingestAutomationEvent } from './automation.js'
import { sector } from '../../sector.js'

export async function registerSectorRoutes(app: FastifyInstance) {
  app.post('/auth/login', async (request, reply) => {
    try {
      const body = (request.body ?? {}) as Record<string, unknown>
      const email = typeof body.email === 'string' ? body.email : ''
      const password = typeof body.password === 'string' ? body.password : ''
      const session = await loginWithPassword(email, password)
      const membership = await resolveMembership(session.user.id, typeof body.tenantId === 'string' ? body.tenantId : null)
      return ok(reply, {
        accessToken: session.access_token,
        refreshToken: session.refresh_token,
        user: membership.profile,
        membership: membership.membership,
        tenant: membership.tenant,
      })
    } catch (error) {
      return fail(reply, 401, error instanceof Error ? error.message : 'Login failed', 'login_failed')
    }
  })

  app.get('/auth/me', async (request, reply) => {
    try {
      const { user } = await requireUser(request)
      const query = (request.query ?? {}) as Record<string, unknown>
      const membership = await resolveMembership(user.id, typeof query.tenantId === 'string' ? query.tenantId : null)
      return ok(reply, { user: membership.profile, membership: membership.membership, tenant: membership.tenant })
    } catch (error) {
      return fail(reply, 401, error instanceof Error ? error.message : 'Unauthorized', 'unauthorized')
    }
  })

  app.get('/api/dashboard/summary', async (request, reply) => {
    try {
      const { user } = await requireUser(request)
      const query = (request.query ?? {}) as Record<string, unknown>
      const context = await resolveMembership(user.id, typeof query.tenantId === 'string' ? query.tenantId : null)
      if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'dashboard.read' })) {
        return fail(reply, 403, 'Permission denied', 'rbac_denied')
      }
      const summary = await getDashboardSummary(context.tenant.id)
      return ok(reply, { summary, tenant: context.tenant, user: context.profile })
    } catch (error) {
      return fail(reply, 500, error instanceof Error ? error.message : 'Dashboard summary failed')
    }
  })

  app.post('/api/internal/automation/ingest', async (request, reply) => {
    try {
      const body = (request.body ?? {}) as Record<string, unknown>
      const tenantId = typeof body.tenantId === 'string' ? body.tenantId : ''
      if (!tenantId) return fail(reply, 400, 'tenantId is required', 'tenant_required')
      const result = await ingestAutomationEvent(tenantId, body)
      return ok(reply, { result })
    } catch (error) {
      return fail(reply, 500, error instanceof Error ? error.message : 'Automation ingest failed')
    }
  })

  for (const entity of sector.entities) {
    app.get('/api/' + sector.resourceBase + '/' + entity.table, async (request, reply) => {
      try {
        const { user } = await requireUser(request)
        const query = (request.query ?? {}) as Record<string, unknown>
        const context = await resolveMembership(user.id, typeof query.tenantId === 'string' ? query.tenantId : null)
        if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'records.read' })) {
          return fail(reply, 403, 'Permission denied', 'rbac_denied')
        }
        const items = await getEntityList(entity.table, context.tenant.id)
        return ok(reply, { items, tenant: context.tenant })
      } catch (error) {
        return fail(reply, 500, error instanceof Error ? error.message : 'Request failed')
      }
    })

    app.post('/api/' + sector.resourceBase + '/' + entity.table, async (request, reply) => {
      try {
        const { user } = await requireUser(request)
        const body = (request.body ?? {}) as Record<string, unknown>
        const context = await resolveMembership(user.id, typeof body.tenantId === 'string' ? body.tenantId : null)
        if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'records.write' })) {
          return fail(reply, 403, 'Permission denied', 'rbac_denied')
        }
        const record = await createEntityRecord(entity.table, context.tenant.id, body, context.profile.id)
        return ok(reply, { record, tenant: context.tenant })
      } catch (error) {
        return fail(reply, 500, error instanceof Error ? error.message : 'Create failed')
      }
    })

    app.patch('/api/' + sector.resourceBase + '/' + entity.table + '/:id/status', async (request, reply) => {
      try {
        const { user } = await requireUser(request)
        const body = (request.body ?? {}) as Record<string, unknown>
        const params = request.params as { id: string }
        const context = await resolveMembership(user.id, typeof body.tenantId === 'string' ? body.tenantId : null)
        if (!hasCapability({ role: context.membership.role, capabilities: context.membership.capabilities, required: 'records.write' })) {
          return fail(reply, 403, 'Permission denied', 'rbac_denied')
        }
        const record = await changeEntityStatus(entity.table, context.tenant.id, params.id, String(body.status ?? 'active'), context.profile.id)
        return ok(reply, { record, tenant: context.tenant })
      } catch (error) {
        return fail(reply, 500, error instanceof Error ? error.message : 'Status update failed')
      }
    })
  }
}
