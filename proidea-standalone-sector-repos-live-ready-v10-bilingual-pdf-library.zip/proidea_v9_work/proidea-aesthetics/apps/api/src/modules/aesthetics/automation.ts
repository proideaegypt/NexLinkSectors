import { createEntityRecord } from './service.js'

export async function ingestAutomationEvent(tenantId: string, payload: Record<string, unknown>, actorId?: string | null) {
  return createEntityRecord('clients', tenantId, {
    title: String(payload.title ?? payload.message ?? payload.summary ?? 'Automation event'),
    status: String(payload.status ?? 'active'),
    summary: String(payload.summary ?? payload.message ?? ''),
    phone: typeof payload.phone === 'string' ? payload.phone : null,
    email: typeof payload.email === 'string' ? payload.email : null,
    metadata: payload,
  }, actorId)
}
