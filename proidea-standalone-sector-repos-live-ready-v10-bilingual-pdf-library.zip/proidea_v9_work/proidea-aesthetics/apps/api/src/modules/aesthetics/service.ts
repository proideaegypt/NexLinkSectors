import { createEntity, dashboardSummary, listEntity, listScopedTable, updateEntityStatus } from './repository.js'
import { sector } from '../../sector.js'

export async function getDashboardSummary(tenantId: string) {
  return dashboardSummary(tenantId)
}

export async function getEntityList(entityKey: string, tenantId: string) {
  const entity = sector.entities.find((item) => item.table === entityKey)
  if (!entity) throw new Error(`Unknown entity: ${entityKey}`)
  return listEntity(entity.table, tenantId)
}

export async function createEntityRecord(entityKey: string, tenantId: string, payload: Record<string, unknown>, actorId?: string | null) {
  const entity = sector.entities.find((item) => item.table === entityKey)
  if (!entity) throw new Error(`Unknown entity: ${entityKey}`)
  return createEntity(entity.table, tenantId, payload, actorId)
}

export async function changeEntityStatus(entityKey: string, tenantId: string, id: string, status: string, actorId?: string | null) {
  const entity = sector.entities.find((item) => item.table === entityKey)
  if (!entity) throw new Error(`Unknown entity: ${entityKey}`)
  return updateEntityStatus(entity.table, tenantId, id, status, actorId)
}
