import { describe, expect, it } from 'vitest'
import { sector } from '../../sector.js'

describe('Aesthetics sector config', () => {
  it('has four primary entities', () => {
    expect(sector.entities).toHaveLength(4)
  })
})
