import { buildApp } from './app.js'
import { apiConfig } from './config.js'

const app = buildApp()
app.listen({ port: apiConfig.PORT, host: apiConfig.HOST }, (err) => {
  if (err) {
    app.log.error(err)
    process.exit(1)
  }
})
