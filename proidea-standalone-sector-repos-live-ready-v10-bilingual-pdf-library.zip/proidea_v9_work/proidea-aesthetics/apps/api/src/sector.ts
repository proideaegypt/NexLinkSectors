export const sector = {
  "slug": "aesthetics",
  "displayName": "Aesthetics",
  "resourceBase": "aesthetics",
  "headline": "Coordinate consultations, treatment plans, sessions, and aftercare follow-ups in one aesthetic operations stack.",
  "roles": [
    "owner",
    "admin",
    "practitioner",
    "front-desk",
    "viewer"
  ],
  "entities": [
    {
      "table": "clients",
      "label": "Client",
      "labelAr": "العملاء"
    },
    {
      "table": "consultations",
      "label": "Consultation",
      "labelAr": "الاستشارات"
    },
    {
      "table": "sessions",
      "label": "Session",
      "labelAr": "الجلسات"
    },
    {
      "table": "treatment_plans",
      "label": "Treatment Plan",
      "labelAr": "خطط العلاج"
    }
  ],
  "capabilities": [
    "dashboard.read",
    "records.read",
    "records.write",
    "automation.manage"
  ]
} as const
