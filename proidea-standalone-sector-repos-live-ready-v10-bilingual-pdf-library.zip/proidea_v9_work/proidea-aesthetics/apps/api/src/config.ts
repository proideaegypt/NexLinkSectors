export const apiConfig = { PORT: Number(process.env.PORT) || 4000, HOST: process.env.HOST || '0.0.0.0', APP_ENV: process.env.APP_ENV || 'development' }
