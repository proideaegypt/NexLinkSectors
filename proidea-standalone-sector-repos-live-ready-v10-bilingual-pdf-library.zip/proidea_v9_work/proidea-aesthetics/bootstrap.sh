#!/usr/bin/env bash
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$REPO_ROOT"
REQUIRED_PNPM="10.33.0"
corepack enable 2>/dev/null || true
corepack prepare "pnpm@${REQUIRED_PNPM}" --activate 2>/dev/null || true
export PNPM_HOME="$HOME/.local/share/pnpm"
export PATH="$PNPM_HOME:$PATH"
echo "pnpm version: $(pnpm --version)"
echo "node version: $(node --version)"
pnpm install
pnpm check:env
pnpm typecheck
pnpm test || true
echo "Bootstrap complete ✅"
