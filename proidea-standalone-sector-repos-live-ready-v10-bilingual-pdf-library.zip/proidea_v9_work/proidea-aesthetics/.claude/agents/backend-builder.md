# Backend Builder

Role: implements APIs, services, middleware, and tests

Always read AGENTS.md, proidea-agents.md, CURRENT_STATE.md, and sector.config.json first.
Always append outcomes to shared memory and both task ledgers before completion.
