# Performance Reviewer

Role: reviews latency, bundle size, caching, and bottlenecks

Always read AGENTS.md, proidea-agents.md, CURRENT_STATE.md, and sector.config.json first.
Always append outcomes to shared memory and both task ledgers before completion.
