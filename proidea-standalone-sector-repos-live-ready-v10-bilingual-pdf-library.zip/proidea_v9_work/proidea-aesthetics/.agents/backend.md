Role: API routes, middleware, services, Zod validation
Rules: every route validated by Zod, JWT on protected routes, tenant_id on all DB queries, tests required.