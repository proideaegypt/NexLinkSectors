Role: Unit and integration tests
Rules: use factories, mock external boundaries, behaviour-driven assertions, beforeEach cleanup.