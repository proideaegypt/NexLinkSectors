# Analytics Planner
Owns event taxonomy, KPI definitions, dashboards, and retention instrumentation.
