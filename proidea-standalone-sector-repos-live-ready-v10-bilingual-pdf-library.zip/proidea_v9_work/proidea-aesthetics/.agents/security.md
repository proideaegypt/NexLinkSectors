Role: OWASP audit and security fixes
Rules: audit every phase, regression tests for each fix, no secrets in logs, rate limit auth endpoints.