Role: README, API docs, architecture docs, runbooks
Rules: update docs after each phase, ADR for major decisions, keep quick start accurate.