Role: Playwright E2E tests
Rules: Page Object Model, data-testid selectors only, screenshots on failure.