Role: Shell, Docker, CI/CD, deploy, scaffold
Rules: set -euo pipefail, no secrets in scripts, rollback script for every deploy script.