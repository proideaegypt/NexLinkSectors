Role: Profiling and optimisation
Rules: API p95 < 200ms, EXPLAIN ANALYZE before/after, paginate list endpoints.