# Release Manager
Owns go/no-go decisions, release readiness, rollback coordination, and release-status updates.
