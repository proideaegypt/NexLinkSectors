Role: PRD, stories, acceptance criteria
Rules: no feature without user story, define MVP vs v2 boundary, persona-driven scope.