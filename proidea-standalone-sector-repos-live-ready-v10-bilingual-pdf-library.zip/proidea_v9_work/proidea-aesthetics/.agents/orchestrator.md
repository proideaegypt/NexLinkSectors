Role: Architecture, context reading, phase planning, cross-file analysis
Rules: never implement directly; plan first; verify typecheck+tests before closing.