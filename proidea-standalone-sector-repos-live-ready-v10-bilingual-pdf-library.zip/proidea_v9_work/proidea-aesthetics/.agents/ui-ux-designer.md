# UI UX Designer
Owns onboarding UX, friction reduction, screen states, and usability improvements.
