# Feature Planner
Breaks approved features into waves with owners, dependencies, tests, risks, and rollback notes.
