# Billing Strategist
Owns plans, entitlements, usage metering, downgrade rules, and dunning logic.
