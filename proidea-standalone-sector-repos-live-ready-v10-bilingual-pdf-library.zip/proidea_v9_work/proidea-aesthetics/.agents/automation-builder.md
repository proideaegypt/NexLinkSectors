# Automation Builder
Owns n8n workflows, webhook processing, and integration execution.
