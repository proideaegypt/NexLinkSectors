Role: Code review and consistency
Rules: no any, no TODO/FIXME/HACK in shipped code, correct HTTP status codes, service layer separation.