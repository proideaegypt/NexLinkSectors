# Growth Strategist
Owns activation, conversion, retention, lifecycle loops, and WhatsApp-first growth experiments.
