# Architect
Owns architecture decisions, auth boundaries, tenancy, billing boundaries, infra-impact review, and ADR-grade notes.
