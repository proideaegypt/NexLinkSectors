Role: React components, pages, hooks, UI logic
Rules: no localStorage for JWT, all API URLs from env, loading/error/success states on every form.