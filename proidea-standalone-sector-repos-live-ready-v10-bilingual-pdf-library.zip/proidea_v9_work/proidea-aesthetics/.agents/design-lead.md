# Design Lead
Owns design system, visual direction, hierarchy, and polish.
