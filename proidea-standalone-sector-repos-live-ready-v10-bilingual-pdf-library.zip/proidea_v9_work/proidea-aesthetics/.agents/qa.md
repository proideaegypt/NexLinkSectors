Role: QA strategy, coverage gaps, acceptance criteria
Rules: every feature needs happy path + at least 2 failure cases + auth and tenant isolation tests.