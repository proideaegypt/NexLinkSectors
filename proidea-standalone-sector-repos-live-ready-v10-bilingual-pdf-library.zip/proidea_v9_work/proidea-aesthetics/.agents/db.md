Role: Schema design, RLS, migrations, indexes
Rules: UUID ids, tenant_id on scoped tables, RLS on every table, indexes on FK/search columns.